<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!-- ══ BOTTOM NAVIGATION BAR ══ -->
<style>
.bottom-nav {
    position: fixed;
    bottom: 0; left: 0; right: 0;
    z-index: 1040;
    background: #ffffff;
    border-top: 1.5px solid rgba(5,150,105,0.12);
    box-shadow: 0 -4px 24px rgba(0,0,0,0.08);
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: 65px;
    padding: 0 8px;
    max-width: 480px;
    margin: 0 auto;
}

/* ফোনের পুরো width জুড়ে দেখানোর জন্য */
.bottom-nav-wrap {
    position: fixed;
    bottom: 0; left: 0; right: 0;
    z-index: 1040;
    background: #ffffff;
    border-top: 1.5px solid rgba(5,150,105,0.12);
    box-shadow: 0 -4px 24px rgba(0,0,0,0.08);
}

.bn-inner {
    max-width: 480px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-around;
    height: 65px;
    padding: 0 8px;
}

.bn-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    color: #94a3b8;
    font-size: 10px;
    font-weight: 600;
    padding: 8px 14px;
    border-radius: 14px;
    transition: all .2s;
    position: relative;
    flex: 1;
}

.bn-item i {
    font-size: 20px;
    transition: all .2s;
}

.bn-item:hover {
    color: #059669;
    background: rgba(5,150,105,0.06);
}

.bn-item.active {
    color: #059669;
}

.bn-item.active i {
    color: #059669;
}

/* Home button — মাঝখানে বড় */
.bn-home {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    text-decoration: none;
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    flex: 1;
}

.bn-home-ico {
    width: 54px;
    height: 54px;
    border-radius: 50%;
    background: linear-gradient(135deg, #047857 0%, #0284c7 50%, #7c3aed 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    color: #fff;
    box-shadow: 0 6px 20px rgba(5,150,105,0.40);
    margin-top: -20px;
    border: 3px solid #fff;
    transition: all .2s;
}

.bn-home:hover .bn-home-ico {
    transform: scale(1.08);
    box-shadow: 0 8px 26px rgba(5,150,105,0.50);
}

.bn-home span {
    color: #059669;
    font-weight: 700;
}
</style>

<div class="bottom-nav-wrap">
    <div class="bn-inner">

        <!-- Support -->
        <a href="support.php" class="bn-item <?= $current_page == 'support.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-headset"></i>
            <span>Help</span>
        </a>

        <!-- Wallet -->
        <a href="withdraw.php" class="bn-item <?= $current_page == 'withdraw.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-wallet"></i>
            <span>Wallet</span>
        </a>

        <!-- Home (মাঝখানে) -->
        <a href="dashboard.php" class="bn-home">
            <div class="bn-home-ico">
                <i class="fa-solid fa-house"></i>
            </div>
            <span>HOME</span>
        </a>

        <!-- Team -->
        <a href="referral_users.php" class="bn-item <?= $current_page == 'my_team.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-users"></i>
            <span>Team</span>
        </a>

        <!-- Profile -->
        <a href="settings.php" class="bn-item <?= $current_page == 'profile.php' ? 'active' : '' ?>">
            <i class="fa-solid fa-user"></i>
            <span>Profile</span>
        </a>

    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
