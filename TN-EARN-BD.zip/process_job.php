<?php
include "config.php"; // আপনার কানেকশন ফাইল
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $job_id = (int)$_POST['job_id'];

    // আগে চেক করা ইউজার কি এটা আগে করেছে?
    $check = $conn->query("SELECT id FROM user_job_logs WHERE user_id='$user_id' AND job_id='$job_id'");
    
    if ($check->num_rows == 0) {
        $job = $conn->query("SELECT reward FROM visiting_jobs WHERE id='$job_id'")->fetch_assoc();
        $reward = $job['reward'];

        // ১. ইউজারের ব্যালেন্স বাড়ানো
        $conn->query("UPDATE users SET balance = balance + $reward WHERE id = '$user_id'");
        
        // ২. লগ এ এন্ট্রি করা যাতে জবটি ভ্যানিশ হয়ে যায়
        $conn->query("INSERT INTO user_job_logs (user_id, job_id) VALUES ('$user_id', '$job_id')");

        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Already completed!']);
    }
}