<?php
session_start();
include "config.php";

if (!isset($_SESSION['fullname'])) {
  header("Location: login.php");
  exit();
}

$user = $_SESSION['fullname'];
$getUser = $conn->query("SELECT * FROM users WHERE fullname='$user'")->fetch_assoc();
$data = $conn->query("SELECT * FROM typing_job_settings WHERE id=1")->fetch_assoc();

$total_lines = $data['total_lines'];
$rate = $data['rate_per_line'];
$user_id = $getUser['id'];

// ইউজারের আজকের কাজ গণনা
$today = date('Y-m-d');
$check = $conn->query("SELECT COUNT(*) AS done FROM user_tasks WHERE user_id='$user_id' AND DATE(submitted_at)='$today'");
$done = $check->fetch_assoc()['done'];
?>
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Typing Job - Money Express</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{font-family:Poppins;background:linear-gradient(135deg,#090024,#1c004a);color:white;text-align:center;min-height:100vh;}
.box{max-width:600px;margin:50px auto;background:rgba(255,255,255,0.08);border-radius:15px;padding:25px;}
textarea{width:100%;height:200px;border:none;border-radius:10px;padding:10px;background:rgba(0,0,0,0.3);color:#fff;font-family:monospace;font-size:15px;}
button{background:linear-gradient(90deg,#00eaff,#ff00ff);border:none;padding:10px 25px;border-radius:10px;color:white;font-weight:600;margin-top:10px;}
.success{color:#00ff99;font-weight:600;margin-top:15px;}
</style>
</head>
<body>
<div class="box">
  <h3>💼 Money Express Typing Job</h3>
  <p>কাজ সম্পন্ন: <b id="lineCount"><?= $done ?></b> / <?= $total_lines ?></p>
  <textarea id="typingBox" readonly placeholder="Auto typing will start here..."></textarea><br>
  <button id="startBtn" onclick="startTyping()" <?= ($done >= $total_lines) ? 'disabled' : '' ?>>Auto Type</button>
  <button id="sellBtn" onclick="sellPage()" disabled>Sell The Page</button>
  <div id="msg" class="success"></div>
</div>

<script>
let limit = <?= $total_lines ?>;
let done = <?= $done ?>;
let rate = <?= $rate ?>;
let textBox = document.getElementById("typingBox");
let count = 0;
let typingData = [
  "Money Express Job is a fast typing opportunity.",
  "Type each line carefully and accurately.",
  "Every line you complete adds value to your balance.",
  "Work smart and earn more through typing tasks.",
  "Thank you for working with Money Express Team."
];

function startTyping(){
  if(done >= limit){
    document.getElementById("msg").innerHTML = "⚠️ আজকের লিমিট শেষ!";
    return;
  }
  let btn = document.getElementById("startBtn");
  btn.disabled = true;
  let sellBtn = document.getElementById("sellBtn");
  textBox.value = "";
  count = 0;
  let i = 0;

  let typing = setInterval(()=>{
    if(i < typingData.length && done + count < limit){
      textBox.value += typingData[i] + "\n";
      count++;
      document.getElementById("lineCount").innerText = done + count;
      i++;
    } else {
      clearInterval(typing);
      sellBtn.disabled = false;
      document.getElementById("msg").innerHTML = "✅ Typing Completed!";
    }
  }, 1000);
}

function sellPage(){
  fetch("typing_sell.php", {method:"POST"})
  .then(res => res.text())
  .then(data => {
    document.getElementById("msg").innerHTML = data;
    setTimeout(()=>location.reload(),1500);
  });
}
</script>
</body>
</html>