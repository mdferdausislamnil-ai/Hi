<?php
include "header.php"; 
include "sidebar.php";

// টাস্ক আইডি চেক
if(!isset($_GET['id'])){
    echo "<script>window.location.href = 'tasks.php';</script>";
    exit;
}

$task_id = intval($_GET['id']);
$user_id = $u['id'];

// টাস্কের বিস্তারিত তথ্য আনা
$task_query = $conn->query("SELECT * FROM tasks WHERE id='$task_id'");
$task = $task_query->fetch_assoc();

if(!$task){
    echo "<script>window.location.href = 'tasks.php';</script>";
    exit;
}

$success = $error = "";

// টাস্ক সাবমিশন হ্যান্ডলার
if(isset($_POST['submit_task'])){
    if(!empty($_FILES['photo1']['name']) && !empty($_FILES['photo2']['name'])){
        
        $targetDir = "uploads/tasks/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $ext1 = pathinfo($_FILES['photo1']['name'], PATHINFO_EXTENSION);
        $ext2 = pathinfo($_FILES['photo2']['name'], PATHINFO_EXTENSION);
        
        $file1 = "task_".$task_id."_u".$user_id."_1_".time().".".$ext1;
        $file2 = "task_".$task_id."_u".$user_id."_2_".time().".".$ext2;

        if(move_uploaded_file($_FILES['photo1']['tmp_name'], $targetDir.$file1) && 
           move_uploaded_file($_FILES['photo2']['tmp_name'], $targetDir.$file2)){
            
            $conn->query("INSERT INTO user_tasks (user_id, task_id, photo1, photo2, status) 
                          VALUES ('$user_id','$task_id','$file1','$file2','pending')");
            
            $success = "আপনার টাস্ক সফলভাবে জমা হয়েছে!";
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'সফলভাবে জমা হয়েছে!',
                    text: 'এডমিন শীঘ্রই এটি চেক করবেন।',
                    timer: 2500,
                    showConfirmButton: false,
                    background: '#0f172a',
                    color: '#fff',
                    iconColor: '#10b981'
                }).then(() => { window.location.href = 'tasks.php'; });
            </script>";
        } else {
            $error = "ফাইল আপলোড ব্যর্থ হয়েছে!";
        }
    } else {
        $error = "দয়া করে দুটি স্ক্রিনশটই আপলোড করুন।";
    }
}

// ✅ ডায়নামিক ছবির পাথ
$img_file = !empty($task['image']) ? $task['image'] : '';
$img_path = "uploads/tasks/" . $img_file;
$has_image = (!empty($img_file) && file_exists($img_path));
?>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 800px;
        margin: 0 auto;
    }

    .job-hero-card {
        background: white;
        border-radius: 32px;
        overflow: hidden;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        margin-top: 20px;
        transition: all 0.25s ease;
    }
    .job-hero-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    .job-img-wrapper {
        width: 100%;
        height: 250px;
        position: relative;
        overflow: hidden;
    }
    /* ছবি থাকলে */
    .job-img-wrapper img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    /* ছবি না থাকলে placeholder */
    .job-img-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #e0e7ff, #ede9fe);
        color: #6366f1;
    }
    .job-img-placeholder i { font-size: 64px; opacity: 0.4; }
    .job-img-placeholder span {
        font-size: 14px; margin-top: 12px;
        opacity: 0.6; font-weight: 600;
    }

    .reward-floating {
        position: absolute;
        bottom: 20px;
        right: 20px;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        padding: 10px 28px;
        border-radius: 50px;
        font-weight: 800;
        font-size: 22px;
        letter-spacing: 0.5px;
        box-shadow: 0 10px 20px -5px #10b98180;
        border: 1px solid rgba(255,255,255,0.3);
        backdrop-filter: blur(4px);
    }

    .detail-body { padding: 30px 28px; }

    .job-badge {
        background: #eef2ff;
        color: #4f46e5;
        padding: 5px 18px;
        border-radius: 40px;
        font-size: 12px;
        font-weight: 700;
        display: inline-block;
        margin-bottom: 12px;
    }

    .btn-open-link {
        background: white;
        color: #1e293b;
        border: 2px solid #e2e8f0;
        padding: 14px 20px;
        border-radius: 60px;
        width: 100%;
        font-weight: 700;
        margin-bottom: 25px;
        transition: 0.2s;
        display: block;
        text-align: center;
        text-decoration: none;
        font-size: 15px;
    }
    .btn-open-link:hover {
        background: #f8fafc;
        border-color: #3b82f6;
        color: #0b253c;
    }

    .instruction-card {
        background: #f8fafc;
        border-radius: 28px;
        padding: 24px;
        border: 1px solid #eef2f6;
        margin: 20px 0 25px;
    }
    .instruction-card h6 {
        font-weight: 800;
        color: #0b253c;
        margin-bottom: 20px;
        font-size: 16px;
    }
    .step-list { list-style: none; padding: 0; margin: 0; }
    .step-list li {
        display: flex;
        gap: 15px;
        margin-bottom: 18px;
        font-size: 14px;
        color: #334155;
        align-items: center;
    }
    .step-icon {
        width: 32px; height: 32px;
        background: linear-gradient(145deg, #4f46e5, #7c3aed);
        color: white;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-weight: 800; flex-shrink: 0;
        font-size: 14px;
        box-shadow: 0 5px 10px #4f46e580;
    }

    .upload-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 18px;
        margin-bottom: 25px;
    }
    .upload-trigger {
        border: 2px dashed #cbd5e1;
        border-radius: 24px;
        padding: 25px 10px;
        text-align: center;
        cursor: pointer;
        transition: 0.2s;
        background: white;
    }
    .upload-trigger:hover { border-color: #4f46e5; background: #f8fafc; }
    .upload-trigger i { font-size: 28px; color: #94a3b8; margin-bottom: 8px; }
    .upload-trigger div { font-size: 13px; font-weight: 600; color: #475569; }
    .selected-active { border-color: #10b981 !important; background: #f0fdf4 !important; }
    .selected-active i { color: #10b981 !important; }

    .btn-job-action {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        border: none;
        color: white;
        font-weight: 800;
        padding: 16px 20px;
        border-radius: 60px;
        width: 100%;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 12px 22px -8px #7c3aed80;
        transition: 0.15s;
        border: 1px solid #ffffff40;
    }
    .btn-job-action:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        transform: scale(1.02);
        color: white;
    }

    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 20px;
    }
    .back-link:hover { background: #f1f5f9; color: #0b253c; border-color: #3b82f6; }

    .alert-custom {
        background: #fee2e2;
        color: #b91c1c;
        border-radius: 60px;
        padding: 12px 20px;
        font-size: 14px;
        font-weight: 500;
        border: 1px solid #fecaca;
        margin-bottom: 20px;
    }
</style>

<div class="container-custom">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="job-hero-card animate-fade-up">

                <!-- ✅ ডায়নামিক ছবি সেকশন -->
                <div class="job-img-wrapper">
                    <?php if ($has_image): ?>
                        <img src="<?= $img_path ?>" alt="<?= htmlspecialchars($task['title']) ?>">
                    <?php else: ?>
                        <div class="job-img-placeholder">
                            <i class="fa-solid fa-briefcase"></i>
                            <span>Task Image</span>
                        </div>
                    <?php endif; ?>

                    <div class="reward-floating">৳ <?= number_format($task['reward'], 2) ?></div>
                </div>

                <div class="detail-body">
                    <span class="job-badge"><i class="fa-solid fa-bolt me-1"></i> মাইক্রো জব</span>
                    <h4 class="fw-bold text-dark mb-4" style="font-size: 22px;">
                        <?= htmlspecialchars($task['title']) ?>
                    </h4>

                    <!-- লিঙ্ক বাটন -->
                    <?php if (!empty($task['link'])): ?>
                    <a href="<?= htmlspecialchars($task['link']) ?>" target="_blank" class="btn-open-link">
                        <i class="fa-solid fa-up-right-from-square me-2" style="color: #3b82f6;"></i> ওপেন জব লিংক
                    </a>
                    <?php endif; ?>

                    <!-- নির্দেশনা -->
                    <div class="instruction-card">
                        <h6><i class="fa-regular fa-circle-check me-2" style="color: #4f46e5;"></i> কীভাবে কাজটি করবেন?</h6>
                        <ul class="step-list">
                            <li><span class="step-icon">১</span> লিঙ্কটি ওপেন করে নির্দেশিত কাজটি সম্পন্ন করুন।</li>
                            <li><span class="step-icon">২</span> কাজ শুরু করার পর একটি এবং শেষ করার পর একটি স্ক্রিনশট নিন।</li>
                            <li><span class="step-icon">৩</span> নিচের বক্সে স্ক্রিনশট দুটি আপলোড করে সাবমিট করুন।</li>
                        </ul>
                    </div>

                    <!-- এরর মেসেজ -->
                    <?php if($error): ?>
                        <div class="alert-custom">
                            <i class="fa-solid fa-circle-exclamation me-2"></i> <?= $error ?>
                        </div>
                    <?php endif; ?>

                    <!-- আপলোড ফর্ম -->
                    <form method="POST" enctype="multipart/form-data">
                        <div class="upload-grid">
                            <div class="upload-trigger" id="box1" onclick="document.getElementById('p1').click()">
                                <i class="fa-solid fa-cloud-arrow-up"></i>
                                <div id="txt1">আপলোড ধাপ ১</div>
                                <input type="file" name="photo1" id="p1" hidden required
                                    onchange="handleFile(this, 'box1', 'txt1')">
                            </div>
                            <div class="upload-trigger" id="box2" onclick="document.getElementById('p2').click()">
                                <i class="fa-solid fa-cloud-arrow-up"></i>
                                <div id="txt2">আপলোড ধাপ ২</div>
                                <input type="file" name="photo2" id="p2" hidden required
                                    onchange="handleFile(this, 'box2', 'txt2')">
                            </div>
                        </div>

                        <button type="submit" name="submit_task" class="btn-job-action">
                            সাবমিট প্রুফ <i class="fa-solid fa-paper-plane ms-2"></i>
                        </button>
                    </form>

                    <div class="text-center">
                        <a href="tasks.php" class="back-link">
                            <i class="fa-solid fa-arrow-left"></i> সব কাজে ফিরুন
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function handleFile(input, boxId, textId) {
        if (input.files && input.files[0]) {
            document.getElementById(boxId).classList.add('selected-active');
            document.getElementById(textId).innerText = "সিলেক্ট হয়েছে ✅";
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.job-hero-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.6s ease-out';
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
    });
</script>

<?php include "footer.php"; ?>
