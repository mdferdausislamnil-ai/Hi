<?php
include "config.php";

// ডাটাবেস কানেকশন চেক
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sqls = [
    // users টেবিলে প্রয়োজনীয় কলাম যোগ করা (যদি না থাকে)
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS plan_id INT DEFAULT 0",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS plan_expire_date DATETIME NULL",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_task_count INT DEFAULT 0",
    "ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'inactive'",
    
    // orders টেবিল তৈরি করা (যদি না থাকে)
    "CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        plan_id INT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_status VARCHAR(20) DEFAULT 'pending',
        trx_id VARCHAR(100) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )"
];

echo "<h3>Database Repair Status:</h3><ul>";
foreach ($sqls as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "<li style='color:green'>Success: Table/Column checked.</li>";
    } else {
        // ডুপ্লিকেট কলাম এরর ইগনোর করা হবে
        echo "<li style='color:orange'>Check: " . $conn->error . "</li>";
    }
}
echo "</ul>";
echo "<a href='dashboard.php'>Go Back Dashboard</a>";
?>