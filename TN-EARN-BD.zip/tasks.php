<?php
include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 400px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 10px;"></div>
                <h4 class="fw-bold text-danger">Account Not Active!</h4>
                <p class="text-muted small px-3">You need to activate your account first to earn by completing tasks.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-key me-2"></i>Activate Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit(); 
}
// --- [END] INACTIVE ACCOUNT CHECK ---

$user_id = $u['id'];

// Check if task section is enabled by admin
$task_status = $s['task_microjob_status'] ?? 'active';

if($task_status == 'inactive'){
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Sorry!',
            text: 'This section is currently closed.',
            confirmButtonText: 'OK',
            background: '#0f172a',
            color: '#fff',
            iconColor: '#ef4444'
        }).then(() => { window.location.href = 'dashboard.php'; });
    </script>";
    exit;
}

// Fetch tasks that the user hasn't done or were rejected
$tasks = $conn->query("
    SELECT t.*
    FROM tasks t
    LEFT JOIN user_tasks ut ON t.id = ut.task_id AND ut.user_id = '$user_id'
    WHERE ut.id IS NULL OR ut.status = 'rejected'
    ORDER BY t.id DESC
");
?>

<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 1280px;
        margin: 0 auto;
    }

    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin-bottom: 20px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i { color: #3b82f6; font-size: 24px; }

    .task-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
        gap: 24px;
        margin-top: 10px;
    }

    .task-card {
        background: white;
        border-radius: 32px;
        overflow: hidden;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        transition: all 0.25s ease;
        position: relative;
        display: flex;
        flex-direction: column;
    }
    .task-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.2);
        border-color: #3b82f6;
    }

    .task-img-box {
        height: 170px;
        background: linear-gradient(135deg, #e0e7ff, #f0f4ff);
        position: relative;
        overflow: hidden;
    }
    .task-img-box img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    /* ছবি না থাকলে placeholder */
    .task-img-placeholder {
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        background: linear-gradient(135deg, #e0e7ff, #ede9fe);
        color: #6366f1;
    }
    .task-img-placeholder i { font-size: 48px; opacity: 0.5; }
    .task-img-placeholder span { font-size: 12px; margin-top: 8px; opacity: 0.6; font-weight: 600; }

    .reward-badge {
        position: absolute;
        top: 15px;
        right: 15px;
        background: linear-gradient(135deg, #f59e0b, #b45309);
        color: white;
        padding: 6px 18px;
        border-radius: 40px;
        font-weight: 700;
        font-size: 14px;
        letter-spacing: 0.4px;
        box-shadow: 0 8px 18px -4px #f59e0b80;
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255,255,255,0.3);
    }

    .task-content {
        padding: 20px 18px 22px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    .task-title {
        font-weight: 800;
        font-size: 18px;
        color: #0b1e33;
        margin-bottom: 12px;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
        min-height: 52px;
    }

    .task-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: auto;
        padding-top: 16px;
        border-top: 1px dashed #e2e8f0;
    }
    .task-type {
        font-size: 13px;
        font-weight: 600;
        color: #64748b;
        background: #f1f5f9;
        padding: 4px 12px;
        border-radius: 40px;
    }

    .btn-work {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        border: none;
        color: white;
        font-weight: 700;
        padding: 12px 22px;
        border-radius: 50px;
        font-size: 14px;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        box-shadow: 0 12px 22px -8px #7c3aed80;
        transition: 0.15s;
        border: 1px solid #ffffff40;
        text-decoration: none;
    }
    .btn-work:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #5b21b6;
        color: white;
    }

    .empty-state {
        background: white;
        border-radius: 32px;
        padding: 50px 20px;
        text-align: center;
        box-shadow: 0 20px 40px -10px rgba(0,40,80,0.08);
        border: 1px solid #eef2f6;
        max-width: 500px;
        margin: 40px auto;
    }
    .empty-state img { width: 100px; margin-bottom: 20px; opacity: 0.7; }
    .empty-state h5 { font-weight: 800; color: #0b253c; }
    .empty-state .btn-outline-primary {
        border-radius: 50px; padding: 10px 30px;
        font-weight: 600; border-width: 2px;
    }

    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0%   { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70%  { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }
</style>

<div class="container-custom pb-5">
    <div class="section-title mt-4">
        <i class="fa-solid fa-briefcase"></i> AVAILABLE TASKS
        <span class="badge bg-primary rounded-pill ms-2 px-3 py-1" style="font-size: 14px;">
            <?= $tasks->num_rows ?>
        </span>
    </div>

    <?php if($tasks->num_rows > 0): ?>
        <div class="task-grid">
            <?php while($task = $tasks->fetch_assoc()): ?>
                <div class="task-card animate-fade-up">
                    <div class="task-img-box">

                        <?php
                        // ✅ ডায়নামিক ছবি — অ্যাডমিন যেটা আপলোড করেছে সেটা দেখাবে
                        $img_file = !empty($task['image']) ? $task['image'] : '';
                        $img_path = "uploads/tasks/" . $img_file;

                        if (!empty($img_file) && file_exists($img_path)):
                        ?>
                            <img src="<?= $img_path ?>" alt="<?= htmlspecialchars($task['title']) ?>">
                        <?php else: ?>
                            <!-- ছবি না থাকলে সুন্দর placeholder -->
                            <div class="task-img-placeholder">
                                <i class="fa-solid fa-briefcase"></i>
                                <span>Task</span>
                            </div>
                        <?php endif; ?>

                        <div class="reward-badge">৳ <?= number_format($task['reward'], 2) ?></div>
                    </div>

                    <div class="task-content">
                        <div class="task-title"><?= htmlspecialchars($task['title']) ?></div>

                        <div class="task-info">
                            <span class="task-type">
                                <i class="fa-solid fa-bolt text-warning me-1"></i> Instant
                            </span>
                            <a href="task_details.php?id=<?= $task['id'] ?>" class="btn-work">
                                Details <i class="fa-solid fa-arrow-right ms-1" style="font-size: 11px;"></i>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

    <?php else: ?>
        <div class="empty-state">
            <img src="https://cdn-icons-png.flaticon.com/512/7486/7486744.png" alt="No tasks">
            <h5 class="fw-bold">No tasks left!</h5>
            <p class="text-muted small">You have completed all available tasks. Check back later for new tasks.</p>
            <a href="dashboard.php" class="btn btn-outline-primary rounded-pill px-5 mt-3">Back to Home</a>
        </div>
    <?php endif; ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const cards = document.querySelectorAll('.task-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.5s ease';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 100);
        });
    });
</script>

<?php include "footer.php"; ?>
