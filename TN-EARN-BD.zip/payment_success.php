<?php
session_start();
require_once "config.php";

// লগ ফাইল
function paymentLog($msg){
    file_put_contents(
        "payment_logs.txt",
        "[" . date("Y-m-d H:i:s") . "] " . $msg . PHP_EOL,
        FILE_APPEND
    );
}

// GET Data লগ
paymentLog("GET DATA: " . json_encode($_GET));

// URL থেকে status
$status = strtolower($_GET['status'] ?? '');

// Transaction ID
$transaction_id = $_GET['transactionId'] ?? '';

paymentLog("Transaction ID: " . $transaction_id);
paymentLog("Payment Status: " . $status);

// Session থেকে user id
$user_id = $_SESSION['user_id'] ?? $_SESSION['id'] ?? 0;

if (!$user_id) {
    paymentLog("User ID Missing");
    die("Login Required");
}

// payment success check
if ($status == "completed") {

    // Account active
    $update = $conn->query("UPDATE users SET status='active' WHERE id='$user_id'");

    if ($update) {

        paymentLog("SUCCESS: User Activated ID = " . $user_id);

        echo "
        <script>
        alert('Payment Successful! Account Activated');
        window.location.href='dashboard.php';
        </script>
        ";
        exit();

    } else {

        paymentLog("Database Update Failed");

        echo "
        <script>
        alert('Database Error');
        window.location.href='activate_account.php';
        </script>
        ";
        exit();
    }

} else {

    paymentLog("Payment Failed");

    echo "
    <script>
    alert('Payment Verification Failed');
    window.location.href='activate_account.php';
    </script>
    ";
}
?>