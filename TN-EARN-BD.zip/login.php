<?php
session_start();
include "config.php";

// --- Fetch admin settings ---
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM admin_settings WHERE setting_key IN ('site_title', 'site_logo', 'site_favicon')");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$site_title = $settings['site_title'] ?? 'Unique Earn BD';
// Fix logo path (admin uses ../uploads, here just uploads)
$site_logo = !empty($settings['site_logo']) ? str_replace("../", "", $settings['site_logo']) : 'image/logo.png';
$site_favicon = !empty($settings['site_favicon']) ? str_replace("../", "", $settings['site_favicon']) : 'image/logo.png';

// Redirect to dashboard if already logged in
if (isset($_SESSION['fullname'])) {
    header("Location: dashboard.php");
    exit();
}

$msg = "";

// --- Login logic ---
if (isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, fullname, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['fullname'] = $row['fullname'];
            $_SESSION['user_id'] = $row['id'];
            
            // Set admin session if role is admin
            if($row['role'] === 'admin'){
                 $_SESSION['admin_logged_in'] = true;
                 $_SESSION['admin_name'] = $row['fullname'];
                 $_SESSION['admin_id'] = $row['id'];
            }
            
            header("Location: dashboard.php");
            exit();
        } else {
            $msg = '<div class="error-message"><i class="fa-solid fa-circle-exclamation"></i> Wrong password!</div>';
        }
    } else {
        $msg = '<div class="error-message"><i class="fa-solid fa-circle-exclamation"></i> Account not found!</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | <?= htmlspecialchars($site_title) ?></title>
    <link rel="icon" href="<?= htmlspecialchars($site_favicon) ?>">
    <!-- Google Fonts & Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f4f7fc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        /* main container */
        .login-wrapper {
            width: 100%;
            max-width: 460px;
            margin: 0 auto;
        }

        /* tab switcher */
        .tab-switcher {
            display: flex;
            background: white;
            padding: 0.5rem;
            border-radius: 60px;
            width: 100%;
            max-width: 300px;
            margin: 0 auto 2rem auto;
            box-shadow: 0 10px 20px -8px rgba(0,50,100,0.1);
            border: 1px solid #eef2f6;
        }
        .tab-switcher a, .tab-switcher button {
            flex: 1;
            padding: 0.75rem 1rem;
            font-weight: 700;
            font-size: 0.95rem;
            text-align: center;
            border-radius: 50px;
            transition: all 0.2s ease;
            text-decoration: none;
            background: transparent;
            border: none;
            cursor: pointer;
        }
        .tab-switcher a {
            color: #64748b;
        }
        .tab-switcher .active-tab {
            background: linear-gradient(90deg, #3b82f6, #2563eb);
            color: white;
            box-shadow: 0 10px 18px -6px #3b82f680;
        }
        .tab-switcher a:hover {
            background: #f1f5f9;
        }

        /* main card */
        .login-card {
            background: white;
            border-radius: 32px;
            padding: 2rem 1.8rem;
            box-shadow: 0 20px 40px -12px rgba(0,50,100,0.15);
            border: 1px solid #f0f4fa;
            width: 100%;
            transition: all 0.25s ease;
        }

        /* logo area */
        .logo-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        .logo-area img {
            height: 70px;
            width: auto;
            object-fit: contain;
        }
        .logo-area .logo-fallback {
            width: 70px;
            height: 70px;
            background: #eef2ff;
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #3b82f6;
            font-size: 32px;
        }
        .logo-area h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: #0b253c;
            letter-spacing: -0.5px;
        }
        .logo-area p {
            color: #64748b;
            font-size: 0.9rem;
        }

        /* error message */
        .error-message {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 0.9rem 1.2rem;
            border-radius: 60px;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .error-message i {
            font-size: 1.1rem;
        }

        /* form groups */
        .form-group {
            position: relative;
            margin-bottom: 1.2rem;
        }
        .form-group input {
            width: 100%;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 60px;
            padding: 1rem 1.5rem 1rem 3rem;
            font-size: 0.95rem;
            color: #1e293b;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .form-group input:focus {
            outline: 2px solid #3b82f6;
            background: white;
            border-color: transparent;
        }
        .form-group i.input-icon {
            position: absolute;
            left: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 1.1rem;
            transition: color 0.2s;
        }
        .form-group:focus-within i.input-icon {
            color: #3b82f6;
        }
        .form-group .toggle-password {
            position: absolute;
            right: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1.1rem;
        }
        .form-group .toggle-password:hover {
            color: #3b82f6;
        }

        /* remember me & forgot password */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 0.5rem 0 1.5rem;
            font-size: 0.9rem;
        }
        .remember-me {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #64748b;
            font-weight: 500;
            cursor: pointer;
        }
        .remember-me input[type="checkbox"] {
            width: 1rem;
            height: 1rem;
            accent-color: #3b82f6;
            border-radius: 4px;
        }
        .forgot-link {
            color: #3b82f6;
            font-weight: 600;
            text-decoration: none;
        }
        .forgot-link:hover {
            text-decoration: underline;
        }

        /* login button */
        .btn-login {
            background: linear-gradient(90deg, #3b82f6, #2563eb);
            border: none;
            color: white;
            font-weight: 800;
            padding: 1.1rem 1.5rem;
            border-radius: 60px;
            width: 100%;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            box-shadow: 0 15px 25px -8px #3b82f680;
            transition: all 0.2s ease;
            border: 1px solid rgba(255,255,255,0.2);
            margin-top: 0.5rem;
            cursor: pointer;
        }
        .btn-login:hover {
            background: linear-gradient(90deg, #2563eb, #1d4ed8);
            transform: scale(1.02);
            box-shadow: 0 18px 30px -6px #1d4ed8;
        }

        /* register link */
        .register-link {
            text-align: center;
            margin-top: 1.8rem;
            color: #64748b;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .register-link a {
            color: #3b82f6;
            font-weight: 700;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }

        /* bottom indicator */
        .bottom-indicator {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
        }
        .bottom-indicator span {
            width: 80px;
            height: 5px;
            background: #cbd5e1;
            border-radius: 10px;
        }

        /* entrance animation */
        .animate-fade-up {
            animation: fadeUp 0.6s ease-out forwards;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <!-- tab switcher -->
        <div class="tab-switcher animate-fade-up">
            <button class="active-tab">Login</button>
            <a href="register.php">Register</a>
        </div>

        <!-- main card -->
        <div class="login-card animate-fade-up" style="animation-delay: 0.1s;">
            <!-- logo area -->
            <div class="logo-area">
                <?php if(file_exists($site_logo) && !empty($site_logo)): ?>
                    <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo">
                <?php else: ?>
                    <div class="logo-fallback">
                        <i class="fas fa-user-circle"></i>
                    </div>
                <?php endif; ?>
                <h1>Welcome</h1>
                <p>Login to <?= htmlspecialchars($site_title) ?></p>
            </div>

            <!-- error message -->
            <?= $msg ?>

            <!-- login form -->
            <form method="post" id="loginForm">
                <div class="form-group">
                    <i class="far fa-envelope input-icon"></i>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>

                <div class="form-group">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" name="password" id="password" placeholder="Password" required>
                    <button type="button" class="toggle-password" id="togglePassword" tabindex="-1">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>

                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember"> Remember me
                    </label>
                    <a href="#" class="forgot-link">Forgot password?</a>
                </div>

                <button type="submit" name="login" class="btn-login">
                    <span>Login</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <!-- register link -->
            <div class="register-link">
                Don't have an account? <a href="register.php">Register</a>
            </div>
        </div>

        <!-- bottom indicator -->
        <div class="bottom-indicator">
            <span></span>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Password toggle
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');
            
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash" style="color:#3b82f6;"></i>';
            });
        });
    </script>
</body>
</html>