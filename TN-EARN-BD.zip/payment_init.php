<?php
session_start();
require_once "config.php";

// Login check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// User info
$stmt = $conn->prepare("SELECT fullname, email FROM users WHERE id=?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// User Data
$fullname = $user['fullname'] ?? 'User';
$email = $user['email'] ?? 'user@email.com';

// Your RupantorPay API Key
$api_key = "3AOCNLR6mIrHPWgzPkvf8BnQJzNaXfq65kXHVkcMp4ze17S7Fl";

// Payment Amount
$amount = "10";

// Payment Data
$postData = [
    "amount" => $amount,
    "customer_name" => $fullname,
    "customer_email" => $email,

    "success_url" => "https://earningbdshop.bdlive24.top/payment_success.php",

    "cancel_url" => "https://earningbdshop.bdlive24.top/activate_account.php?error=failed",

    "metadata" => [
        "user_id" => (string)$user_id,
        "type" => "activation"
    ]
];

// cURL Start
$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://payment.rupantorpay.com/api/payment/create",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($postData),
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "X-API-KEY: $api_key",
        "X-CLIENT: " . $_SERVER['HTTP_HOST']
    ],
    CURLOPT_SSL_VERIFYPEER => false
]);

$response = curl_exec($curl);

curl_close($curl);

$result = json_decode($response, true);

// Redirect to Payment Page
if (isset($result['payment_url'])) {
    header("Location: " . $result['payment_url']);
    exit();
}

// Error Show
echo "<pre>";
print_r($result);
?>