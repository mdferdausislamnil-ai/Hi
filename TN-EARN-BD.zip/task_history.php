<?php
include "header.php"; 
include "sidebar.php";

// ইউজার আইডি
$user_id = $u['id'];

// ইউজারের করা সব কাজ আনবে
$history = $conn->query("
    SELECT ut.*, t.title, t.reward
    FROM user_tasks ut
    JOIN tasks t ON ut.task_id = t.id
    WHERE ut.user_id = '$user_id'
    ORDER BY ut.id DESC
");
?>

<style>
    body { background: #f8fafc; }

    .history-card {
        background: #fff;
        border-radius: 20px;
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid #e2e8f0;
        transition: 0.3s;
    }

    .history-card:hover {
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        transform: translateY(-3px);
    }

    .status-badge {
        padding: 5px 15px;
        border-radius: 50px;
        font-size: 12px;
        font-weight: 700;
    }

    .pending { background: #fef3c7; color: #d97706; }
    .approved { background: #d1fae5; color: #059669; }
    .rejected { background: #fee2e2; color: #dc2626; }

    .empty-box {
        background: #fff;
        border-radius: 20px;
        padding: 50px 20px;
        text-align: center;
        margin-top: 40px;
    }
</style>

<div class="container pb-5">

    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mt-4 mb-3">
        <div>
            <h4 class="fw-bold m-0">Task History</h4>
            <p class="text-muted small">আপনার করা কাজগুলোর তালিকা</p>
        </div>
        <span class="badge bg-dark rounded-pill px-3">
            Total: <?= $history->num_rows ?>
        </span>
    </div>

    <?php if($history->num_rows > 0): ?>

        <?php while($row = $history->fetch_assoc()): ?>
            <div class="history-card">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="fw-bold mb-1">
                            <?= htmlspecialchars($row['title']) ?>
                        </h6>
                        <small class="text-muted">
                            Reward: ৳ <?= number_format($row['reward'], 2) ?>
                        </small>
                    </div>

                    <div class="text-end">
                        <?php if($row['status'] == 'pending'): ?>
                            <span class="status-badge pending">
                                <i class="fa-solid fa-clock me-1"></i> Pending
                            </span>
                        <?php elseif($row['status'] == 'approved'): ?>
                            <span class="status-badge approved">
                                <i class="fa-solid fa-circle-check me-1"></i> Approved
                            </span>
                        <?php else: ?>
                            <span class="status-badge rejected">
                                <i class="fa-solid fa-circle-xmark me-1"></i> Rejected
                            </span>
                        <?php endif; ?>

                        <div class="mt-2">
                            <small class="text-muted">
                                <?= date("d M Y, h:i A", strtotime($row['created_at'])) ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>

    <?php else: ?>

        <div class="empty-box">
            <img src="https://cdn-icons-png.flaticon.com/512/4076/4076549.png" width="90" class="mb-3 opacity-50">
            <h5 class="fw-bold">কোনো হিস্টোরি নেই</h5>
            <p class="text-muted small">আপনি এখনো কোনো কাজ সম্পন্ন করেননি।</p>
            <a href="tasks.php" class="btn btn-primary rounded-pill px-4 mt-2">
                কাজ শুরু করুন
            </a>
        </div>

    <?php endif; ?>

</div>

<?php include "footer.php"; ?>