<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@600;700;800;900&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════════
   SIDEBAR — ULTRA PREMIUM 2025
══════════════════════════════ */
.offcanvas{
  border-radius:0 28px 28px 0;
  max-width:305px;
  background:#f0fdf9;
  background-image:
    radial-gradient(ellipse 120% 50% at -5% 0%,rgba(5,150,105,0.09) 0%,transparent 55%),
    radial-gradient(ellipse 80% 60% at 110% 10%,rgba(59,130,246,0.07) 0%,transparent 50%),
    linear-gradient(175deg,#f0fdf4 0%,#eff6ff 55%,#fdf4ff 100%);
  box-shadow:6px 0 40px rgba(0,0,0,0.14);
  border-right:none;
}

/* ── OFFCANVAS HEADER ── */
.offcanvas-header{
  background:transparent;
  border-bottom:1.5px solid rgba(124,58,237,0.10);
  padding:14px 18px;
}
.offcanvas-title{
  font-family:'Sora',sans-serif;
  font-size:16px;font-weight:900;
  background:linear-gradient(135deg,#047857,#0284c7,#7c3aed);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  letter-spacing:.3px;
}

/* ── PROFILE HEADER ── */
.profile-header{
  background:linear-gradient(145deg,#047857 0%,#0284c7 40%,#4338ca 72%,#7c3aed 100%);
  padding:26px 18px 18px;
  position:relative;overflow:hidden;
  text-align:center;
}
.ph-orb1{position:absolute;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,0.07);bottom:-65px;right:-45px;pointer-events:none;}
.ph-orb2{position:absolute;width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,0.05);top:8px;right:22px;pointer-events:none;}
.ph-orb3{position:absolute;width:50px;height:50px;border-radius:50%;background:rgba(255,255,255,0.05);top:35%;left:10px;pointer-events:none;}

.avatar-container{
  width:82px;height:82px;
  margin:0 auto 12px;
  border-radius:50%;
  padding:3px;
  background:conic-gradient(from 0deg,#fbbf24,#a855f7,#3b82f6,#10b981,#fbbf24);
  box-shadow:0 8px 28px rgba(0,0,0,0.30),0 0 0 4px rgba(255,255,255,0.12);
  position:relative;z-index:2;
  animation:spinring 5s linear infinite;
}
@keyframes spinring{from{filter:hue-rotate(0deg);}to{filter:hue-rotate(360deg);}}
.avatar-container img{
  width:100%;height:100%;
  border-radius:50%;object-fit:cover;
  border:3px solid #fff;
  display:block;
}

.profile-info h2{
  font-family:'Sora',sans-serif;
  font-size:15px;font-weight:900;
  color:#fff;text-align:center;
  text-transform:uppercase;letter-spacing:.6px;
  margin-bottom:9px;
  text-shadow:0 2px 10px rgba(0,0,0,0.25);
  position:relative;z-index:2;
}
.status-row{
  display:flex;justify-content:center;
  gap:7px;margin-bottom:14px;
  position:relative;z-index:2;
}
.id-badge{
  background:rgba(255,255,255,0.18);
  border:1px solid rgba(255,255,255,0.28);
  color:#fff;padding:4px 11px;
  border-radius:30px;font-size:10px;font-weight:700;
  backdrop-filter:blur(8px);
}
.active-badge{
  background:#dcfce7;color:#166534;
  border:1px solid #86efac;
  padding:4px 11px;border-radius:30px;
  font-size:10px;font-weight:700;
}
.inactive-badge{
  background:#fee2e2;color:#991b1b;
  border:1px solid #fca5a5;
  padding:4px 11px;border-radius:30px;
  font-size:10px;font-weight:700;
}

.stats-container{
  display:flex;
  background:rgba(255,255,255,0.16);
  border:1px solid rgba(255,255,255,0.24);
  border-radius:16px;padding:12px 8px;
  position:relative;z-index:2;
  backdrop-filter:blur(12px);
}
.stat-box{flex:1;text-align:center;}
.stat-box+.stat-box{border-left:1px solid rgba(255,255,255,0.18);}
.stat-label{font-size:9px;color:rgba(255,255,255,0.70);font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px;}
.stat-value{font-size:15px;font-weight:800;color:#fff;margin:0;font-family:'Sora',sans-serif;}

/* ── MENU BODY ── */
.content-body{
  padding:12px 12px 28px;
  background:transparent;
}

/* ── SECTION TITLE ── */
.section-title{
  font-size:9px;font-weight:800;
  background:linear-gradient(135deg,#7c3aed,#0284c7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;
  background-clip:text;
  text-transform:uppercase;letter-spacing:.8px;
  margin:16px 0 8px 3px;
  display:flex;align-items:center;gap:6px;
}
.section-title::after{
  content:'';flex:1;height:1.5px;
  background:linear-gradient(90deg,rgba(124,58,237,0.20),transparent);
  -webkit-background-clip:unset;
  background-clip:unset;
}

/* ── BASE MENU ITEM ── */
.menu-item{
  display:flex;align-items:center;
  gap:0;margin-bottom:7px;
  border-radius:18px;
  text-decoration:none;cursor:pointer;
  overflow:hidden;width:100%;
  font-family:'Space Grotesk',sans-serif;
  border:1.5px solid transparent;
  transition:transform .18s cubic-bezier(.4,0,.2,1),box-shadow .18s;
  position:relative;
}
.menu-item::after{
  content:'';
  position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(255,255,255,0.55),rgba(255,255,255,0.10));
  pointer-events:none;
  border-radius:18px;
}
.menu-item:hover{
  transform:translateX(6px) scale(1.01);
}
.menu-item:active{transform:scale(.96);}

/* Icon box */
.mi-icon{
  width:50px;height:50px;
  display:flex;align-items:center;
  justify-content:center;
  font-size:19px;flex-shrink:0;color:#fff;
  position:relative;z-index:1;
  border-radius:0 14px 14px 0;
}
/* Text */
.mi-body{
  flex:1;padding:0 8px 0 10px;
  position:relative;z-index:1;
}
.mi-title{
  font-size:12.5px;font-weight:700;
  display:block;line-height:1.3;
}
.mi-sub{
  font-size:9.5px;font-weight:600;
  opacity:.60;display:block;margin-top:1px;
}
.mi-arr{
  font-size:13px;margin-right:13px;
  opacity:.35;flex-shrink:0;
  position:relative;z-index:1;
  font-weight:700;
}

/* ══ EACH BUTTON — UNIQUE PREMIUM STYLE ══ */

/* Dashboard — Emerald */
.m-dashboard{background:linear-gradient(135deg,#ecfdf5 60%,#d1fae5 100%);border-color:rgba(5,150,105,0.22);box-shadow:0 3px 12px rgba(5,150,105,0.10);}
.m-dashboard .mi-icon{background:linear-gradient(135deg,#047857,#10b981);}
.m-dashboard .mi-title{color:#064e3b;}
.m-dashboard .mi-sub{color:#059669;}
.m-dashboard:hover{box-shadow:0 6px 20px rgba(5,150,105,0.18);}

/* Leaderboard — Amber/Gold */
.m-leader{background:linear-gradient(135deg,#fffbeb 60%,#fef3c7 100%);border-color:rgba(217,119,6,0.22);box-shadow:0 3px 12px rgba(217,119,6,0.10);}
.m-leader .mi-icon{background:linear-gradient(135deg,#b45309,#f59e0b);}
.m-leader .mi-title{color:#78350f;}
.m-leader .mi-sub{color:#d97706;}
.m-leader:hover{box-shadow:0 6px 20px rgba(217,119,6,0.18);}

/* Profile — Cyan */
.m-profile{background:linear-gradient(135deg,#ecfeff 60%,#cffafe 100%);border-color:rgba(6,182,212,0.22);box-shadow:0 3px 12px rgba(6,182,212,0.10);}
.m-profile .mi-icon{background:linear-gradient(135deg,#0891b2,#22d3ee);}
.m-profile .mi-title{color:#164e63;}
.m-profile .mi-sub{color:#0891b2;}
.m-profile:hover{box-shadow:0 6px 20px rgba(6,182,212,0.18);}

/* Upgrade — Purple ✨ premium shine */
.m-upgrade{
  background:linear-gradient(135deg,#fdf4ff 60%,#ede9fe 100%);
  border-color:rgba(124,58,237,0.28);
  box-shadow:0 3px 16px rgba(124,58,237,0.15);
}
.m-upgrade .mi-icon{background:linear-gradient(135deg,#6d28d9,#a78bfa);}
.m-upgrade .mi-title{color:#4c1d95;font-weight:800;}
.m-upgrade .mi-sub{color:#7c3aed;}
.m-upgrade:hover{box-shadow:0 6px 24px rgba(124,58,237,0.25);}

/* Premium Jobs — Gold Crown */
.m-premium{background:linear-gradient(135deg,#fefce8 60%,#fef9c3 100%);border-color:rgba(180,83,9,0.22);box-shadow:0 3px 12px rgba(180,83,9,0.10);}
.m-premium .mi-icon{background:linear-gradient(135deg,#92400e,#d97706);}
.m-premium .mi-title{color:#713f12;}
.m-premium .mi-sub{color:#b45309;}
.m-premium:hover{box-shadow:0 6px 20px rgba(180,83,9,0.18);}

/* My Job — Blue */
.m-job{background:linear-gradient(135deg,#eff6ff 60%,#dbeafe 100%);border-color:rgba(37,99,235,0.20);box-shadow:0 3px 12px rgba(37,99,235,0.08);}
.m-job .mi-icon{background:linear-gradient(135deg,#1d4ed8,#60a5fa);}
.m-job .mi-title{color:#1e3a8a;}
.m-job .mi-sub{color:#2563eb;}
.m-job:hover{box-shadow:0 6px 20px rgba(37,99,235,0.16);}

/* Visiting Job — Teal */
.m-visit{background:linear-gradient(135deg,#f0fdfa 60%,#ccfbf1 100%);border-color:rgba(13,148,136,0.20);box-shadow:0 3px 12px rgba(13,148,136,0.08);}
.m-visit .mi-icon{background:linear-gradient(135deg,#0d9488,#2dd4bf);}
.m-visit .mi-title{color:#134e4a;}
.m-visit .mi-sub{color:#0d9488;}
.m-visit:hover{box-shadow:0 6px 20px rgba(13,148,136,0.16);}

/* Job History — Sky Blue */
.m-jhist{background:linear-gradient(135deg,#f0f9ff 60%,#e0f2fe 100%);border-color:rgba(2,132,199,0.20);box-shadow:0 3px 12px rgba(2,132,199,0.08);}
.m-jhist .mi-icon{background:linear-gradient(135deg,#075985,#38bdf8);}
.m-jhist .mi-title{color:#0c4a6e;}
.m-jhist .mi-sub{color:#0369a1;}
.m-jhist:hover{box-shadow:0 6px 20px rgba(2,132,199,0.16);}

/* Gift — Hot Pink */
.m-gift{background:linear-gradient(135deg,#fdf2f8 60%,#fce7f3 100%);border-color:rgba(219,39,119,0.20);box-shadow:0 3px 12px rgba(219,39,119,0.08);}
.m-gift .mi-icon{background:linear-gradient(135deg,#9d174d,#f472b6);}
.m-gift .mi-title{color:#831843;}
.m-gift .mi-sub{color:#db2777;}
.m-gift:hover{box-shadow:0 6px 20px rgba(219,39,119,0.16);}

/* Facebook — FB Blue */
.m-fb{background:linear-gradient(135deg,#eff6ff 60%,#dbeafe 100%);border-color:rgba(24,119,242,0.24);box-shadow:0 3px 12px rgba(24,119,242,0.10);}
.m-fb .mi-icon{background:linear-gradient(135deg,#1251aa,#1877f2);}
.m-fb .mi-title{color:#1e3a8a;}
.m-fb .mi-sub{color:#1877f2;}
.m-fb:hover{box-shadow:0 6px 20px rgba(24,119,242,0.18);}

/* Gmail — Red/Orange */
.m-gmail{background:linear-gradient(135deg,#fef2f2 60%,#fee2e2 100%);border-color:rgba(234,67,53,0.22);box-shadow:0 3px 12px rgba(234,67,53,0.08);}
.m-gmail .mi-icon{background:linear-gradient(135deg,#b91c1c,#f87171);}
.m-gmail .mi-title{color:#7f1d1d;}
.m-gmail .mi-sub{color:#dc2626;}
.m-gmail:hover{box-shadow:0 6px 20px rgba(234,67,53,0.16);}

/* Instagram — Gradient Purple/Pink */
.m-insta{background:linear-gradient(135deg,#fdf4ff 60%,#fce7f3 100%);border-color:rgba(168,85,247,0.22);box-shadow:0 3px 12px rgba(168,85,247,0.10);}
.m-insta .mi-icon{background:linear-gradient(135deg,#7c3aed,#ec4899,#f97316);}
.m-insta .mi-title{color:#581c87;}
.m-insta .mi-sub{color:#a855f7;}
.m-insta:hover{box-shadow:0 6px 20px rgba(168,85,247,0.18);}

/* Coins — Gold Shine */
.m-coins{background:linear-gradient(135deg,#fffbeb 60%,#fef3c7 100%);border-color:rgba(245,158,11,0.22);box-shadow:0 3px 12px rgba(245,158,11,0.10);}
.m-coins .mi-icon{background:linear-gradient(135deg,#78350f,#fbbf24);}
.m-coins .mi-title{color:#78350f;}
.m-coins .mi-sub{color:#d97706;}
.m-coins:hover{box-shadow:0 6px 20px rgba(245,158,11,0.18);}

/* Payment History — Green */
.m-payhist{background:linear-gradient(135deg,#ecfdf5 60%,#d1fae5 100%);border-color:rgba(4,120,87,0.20);box-shadow:0 3px 12px rgba(4,120,87,0.08);}
.m-payhist .mi-icon{background:linear-gradient(135deg,#065f46,#059669);}
.m-payhist .mi-title{color:#064e3b;}
.m-payhist .mi-sub{color:#047857;}
.m-payhist:hover{box-shadow:0 6px 20px rgba(4,120,87,0.16);}

/* Withdraw — Red */
.m-withdraw{background:linear-gradient(135deg,#fff1f2 60%,#ffe4e6 100%);border-color:rgba(190,18,60,0.22);box-shadow:0 3px 12px rgba(190,18,60,0.10);}
.m-withdraw .mi-icon{background:linear-gradient(135deg,#9f1239,#fb7185);}
.m-withdraw .mi-title{color:#881337;}
.m-withdraw .mi-sub{color:#be123c;}
.m-withdraw:hover{box-shadow:0 6px 20px rgba(190,18,60,0.18);}

/* Team — Indigo */
.m-team{background:linear-gradient(135deg,#eef2ff 60%,#e0e7ff 100%);border-color:rgba(67,56,202,0.20);box-shadow:0 3px 12px rgba(67,56,202,0.08);}
.m-team .mi-icon{background:linear-gradient(135deg,#3730a3,#818cf8);}
.m-team .mi-title{color:#1e1b4b;}
.m-team .mi-sub{color:#4338ca;}
.m-team:hover{box-shadow:0 6px 20px rgba(67,56,202,0.16);}

/* Support — Telegram Blue */
.m-support{background:linear-gradient(135deg,#f0f9ff 60%,#e0f2fe 100%);border-color:rgba(3,105,161,0.20);box-shadow:0 3px 12px rgba(3,105,161,0.08);}
.m-support .mi-icon{background:linear-gradient(135deg,#0c4a6e,#0ea5e9);}
.m-support .mi-title{color:#0c4a6e;}
.m-support .mi-sub{color:#0369a1;}
.m-support:hover{box-shadow:0 6px 20px rgba(3,105,161,0.16);}

/* Logout — Danger Red/Orange */
.m-logout{
  background:linear-gradient(135deg,#fff1f2 60%,#ffedd5 100%);
  border-color:rgba(239,68,68,0.24);
  box-shadow:0 3px 14px rgba(239,68,68,0.12);
}
.m-logout .mi-icon{background:linear-gradient(135deg,#dc2626,#f97316);}
.m-logout .mi-title{color:#7f1d1d;font-weight:800;}
.m-logout .mi-sub{color:#ef4444;}
.m-logout:hover{box-shadow:0 6px 22px rgba(239,68,68,0.22);}

/* Disabled */
.menu-item.disabled{
  opacity:.38;cursor:not-allowed;
  filter:grayscale(40%);
}
.menu-item.disabled:hover{transform:none;box-shadow:none;}
</style>

<!-- ══ SIDEBAR ══ -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="sideMenu">

  <div class="offcanvas-header">
    <h5 class="offcanvas-title">⚡ EARNINGS HUB</h5>
    <button type="button" class="btn-close" data-bs-dismiss="offcanvas"></button>
  </div>

  <div class="offcanvas-body p-0">

    <!-- Profile -->
    <div class="profile-header">
      <div class="ph-orb1"></div>
      <div class="ph-orb2"></div>
      <div class="ph-orb3"></div>
      <div class="avatar-container">
        <img src="<?= htmlspecialchars($u['profile_pic'] ?: 'image/profile.png') ?>" alt="Profile">
      </div>
      <div class="profile-info">
        <h2><?= htmlspecialchars($u['fullname']) ?></h2>
        <div class="status-row">
          <div class="id-badge">🪪 ID: <?= $u['id'] ?></div>
          <?php if($u['status'] == 'active'): ?>
            <div class="active-badge">✅ ACTIVE</div>
          <?php else: ?>
            <div class="inactive-badge">❌ INACTIVE</div>
          <?php endif; ?>
        </div>
      </div>
      <div class="stats-container">
        <div class="stat-box">
          <p class="stat-label">💰 BALANCE</p>
          <p class="stat-value">৳ <?= number_format($u['balance'], 2) ?></p>
        </div>
        <div class="stat-box">
          <p class="stat-label">📅 JOINED</p>
          <p class="stat-value"><?= date('d M, y', strtotime($u['created_at'])) ?></p>
        </div>
      </div>
    </div>

    <!-- ══ MENU ══ -->
    <div class="content-body">

      <p class="section-title">🏠 HOME</p>

      <a href="dashboard.php" class="menu-item m-dashboard" data-menu-key="dashboard">
        <div class="mi-icon"><i class="fa-solid fa-house"></i></div>
        <div class="mi-body">
          <span class="mi-title">Dashboard</span>
          <span class="mi-sub">হোম পেজ দেখুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="leaderboard.php" class="menu-item m-leader" data-menu-key="leaderboard">
        <div class="mi-icon"><i class="fa-solid fa-trophy"></i></div>
        <div class="mi-body">
          <span class="mi-title">Top Leaderboard</span>
          <span class="mi-sub">সেরা আয়কারীদের তালিকা</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="settings.php" class="menu-item m-profile" data-menu-key="settings">
        <div class="mi-icon"><i class="fa-solid fa-user-pen"></i></div>
        <div class="mi-body">
          <span class="mi-title">Profile Update</span>
          <span class="mi-sub">প্রোফাইল আপডেট করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">💎 PREMIUM ZONE</p>

      <a href="upgrade.php" class="menu-item m-upgrade" data-menu-key="upgrade">
        <div class="mi-icon"><i class="fa-solid fa-gem"></i></div>
        <div class="mi-body">
          <span class="mi-title">Upgrade Membership</span>
          <span class="mi-sub">প্রিমিয়াম সদস্য হন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="premium_jobs.php" class="menu-item m-premium" data-menu-key="premium_jobs">
        <div class="mi-icon"><i class="fa-solid fa-crown"></i></div>
        <div class="mi-body">
          <span class="mi-title">Premium Jobs</span>
          <span class="mi-sub">এক্সক্লুসিভ কাজ করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">⚡ WORKING</p>

      <a href="tasks.php" class="menu-item m-job" data-menu-key="tasks">
        <div class="mi-icon"><i class="fa-solid fa-briefcase"></i></div>
        <div class="mi-body">
          <span class="mi-title">My Job (Regular)</span>
          <span class="mi-sub">নিয়মিত কাজ করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="visiting_job.php" class="menu-item m-visit" data-menu-key="visiting_job">
        <div class="mi-icon"><i class="fa-solid fa-location-dot"></i></div>
        <div class="mi-body">
          <span class="mi-title">Visiting Job</span>
          <span class="mi-sub">ভিজিটিং জব করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="task_history.php" class="menu-item m-jhist" data-menu-key="task_history">
        <div class="mi-icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
        <div class="mi-body">
          <span class="mi-title">My Job History</span>
          <span class="mi-sub">কাজের সম্পূর্ণ ইতিহাস</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="gift_code.php" class="menu-item m-gift" data-menu-key="gift_code">
        <div class="mi-icon"><i class="fa-solid fa-gift"></i></div>
        <div class="mi-body">
          <span class="mi-title">Gift Code</span>
          <span class="mi-sub">গিফট কোড রিডিম করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">🛍️ SELL SERVICE</p>

      <a href="facebook.php" class="menu-item m-fb" data-menu-key="facebook">
        <div class="mi-icon"><i class="fa-brands fa-facebook-f"></i></div>
        <div class="mi-body">
          <span class="mi-title">Facebook ID Sell</span>
          <span class="mi-sub">ফেসবুক আইডি বিক্রি করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="gmail.php" class="menu-item m-gmail" data-menu-key="gmail">
        <div class="mi-icon"><i class="fa-solid fa-envelope"></i></div>
        <div class="mi-body">
          <span class="mi-title">Gmail Sell</span>
          <span class="mi-sub">জিমেইল বিক্রি করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="instagram.php" class="menu-item m-insta" data-menu-key="instagram">
        <div class="mi-icon"><i class="fa-brands fa-instagram"></i></div>
        <div class="mi-body">
          <span class="mi-title">Instagram ID Sell</span>
          <span class="mi-sub">ইনস্টাগ্রাম আইডি বিক্রি</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="coins_sell.php" class="menu-item m-coins" data-menu-key="coins_sell">
        <div class="mi-icon"><i class="fa-solid fa-coins"></i></div>
        <div class="mi-body">
          <span class="mi-title">Coins Sell</span>
          <span class="mi-sub">কয়েন বিক্রি করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">💳 FINANCE</p>

      <a href="withdraw_history.php" class="menu-item m-payhist" data-menu-key="payment_history">
        <div class="mi-icon"><i class="fa-solid fa-receipt"></i></div>
        <div class="mi-body">
          <span class="mi-title">Payment History</span>
          <span class="mi-sub">পেমেন্টের সম্পূর্ণ ইতিহাস</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="withdraw.php" class="menu-item m-withdraw" data-menu-key="withdraw">
        <div class="mi-icon"><i class="fa-solid fa-money-bill-transfer"></i></div>
        <div class="mi-body">
          <span class="mi-title">Withdraw</span>
          <span class="mi-sub">টাকা উত্তোলন করুন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">🤝 TEAM & SUPPORT</p>

      <a href="referral_users.php" class="menu-item m-team" data-menu-key="referral_users">
        <div class="mi-icon"><i class="fa-solid fa-users"></i></div>
        <div class="mi-body">
          <span class="mi-title">My Team</span>
          <span class="mi-sub">আমার রেফারেল টিম</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <a href="support.php" class="menu-item m-support" data-menu-key="support">
        <div class="mi-icon"><i class="fa-brands fa-telegram"></i></div>
        <div class="mi-body">
          <span class="mi-title">Helpline / Support</span>
          <span class="mi-sub">সাপোর্ট সেন্টারে যোগাযোগ</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

      <p class="section-title">🔐 ACCOUNT</p>

      <a href="logout.php" class="menu-item m-logout">
        <div class="mi-icon"><i class="fa-solid fa-right-from-bracket"></i></div>
        <div class="mi-body">
          <span class="mi-title">Log Out</span>
          <span class="mi-sub">অ্যাকাউন্ট থেকে বের হন</span>
        </div>
        <span class="mi-arr">›</span>
      </a>

    </div>
  </div>
</div>

<script>
const menuStatus = {
  "dashboard":      "active",
  "leaderboard":    "active",
  "settings":       "active",
  "upgrade":        "active",
  "premium_jobs":   "active",
  "tasks":          "<?= isset($s['task_microjob_status'])  ? $s['task_microjob_status']  : 'active' ?>",
  "visiting_job":   "<?= isset($s['task_visiting_status'])  ? $s['task_visiting_status']  : 'active' ?>",
  "task_history":   "active",
  "gift_code":      "active",
  "facebook":       "<?= isset($s['task_facebook_status'])  ? $s['task_facebook_status']  : 'active' ?>",
  "gmail":          "<?= isset($s['task_gmail_status'])     ? $s['task_gmail_status']     : 'active' ?>",
  "instagram":      "<?= isset($s['task_instagram_status']) ? $s['task_instagram_status'] : 'active' ?>",
  "payment_history":"active",
  "withdraw":       "active",
  "referral_users": "active",
  "coins_sell":     "active",
  "support":        "active"
};

document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('.menu-item[data-menu-key]').forEach(item => {
    const key = item.getAttribute('data-menu-key');
    if (menuStatus[key] === 'inactive') {
      item.classList.add('disabled');
      item.addEventListener('click', e => {
        e.preventDefault(); e.stopPropagation();
        Swal.fire({
          icon: 'warning',
          title: 'সাময়িক বন্ধ',
          text: 'এই ফিচারটি বর্তমানে বন্ধ আছে।',
          confirmButtonText: 'ঠিক আছে',
          confirmButtonColor: '#7c3aed',
          background: '#fff',
          color: '#0a1628'
        });
      });
    }
  });
});
</script>
