<?php
include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">সাপোর্ট অ্যাক্সেস নেই!</h4>
                <p class="text-muted small px-3">সাপোর্ট পৃষ্ঠা দেখতে আপনার অ্যাকাউন্ট অ্যাক্টিভ থাকা আবশ্যক।</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>একাউন্ট অ্যাক্টিভ করুন
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

// সোশ্যাল লিঙ্ক ফেচ
$fb = $s['support_fb'] ?? '#';
$yt = $s['support_yt'] ?? '#';
$tg_ch = $s['support_tg_ch'] ?? '#';
$tg_gp = $s['support_tg_gp'] ?? '#';

// সব ভিডিও ফেচ করা
$videos = $conn->query("SELECT * FROM support_videos ORDER BY id DESC");
?>

<!-- ====== SUPPORT PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 1280px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* main card */
    .support-card {
        background: white;
        border-radius: 32px;
        padding: 28px 24px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        transition: all 0.25s ease;
        height: 100%;
    }
    .support-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* card header */
    .card-header-custom {
        font-weight: 800;
        font-size: 18px;
        color: #0b253c;
        padding-bottom: 16px;
        margin-bottom: 20px;
        border-bottom: 2px solid #f1f5f9;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .card-header-custom i {
        font-size: 20px;
    }

    /* social link items */
    .social-link-item {
        display: flex;
        align-items: center;
        padding: 16px 18px;
        border-radius: 24px;
        text-decoration: none;
        margin-bottom: 12px;
        transition: all 0.2s ease;
        border: 1px solid #eef2f6;
        background: white;
    }
    .social-link-item:hover {
        transform: translateX(6px);
        background: #f8fafc;
        border-color: #cbd5e1;
        box-shadow: 0 8px 16px -6px rgba(0,0,0,0.04);
    }

    /* icon box */
    .icon-box {
        width: 52px;
        height: 52px;
        border-radius: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: white;
        margin-right: 18px;
        flex-shrink: 0;
        box-shadow: 0 8px 16px -4px rgba(0,0,0,0.1);
    }

    /* brand colors */
    .bg-fb { background: linear-gradient(145deg, #1877F2, #0e5a9c); }
    .bg-yt { background: linear-gradient(145deg, #FF0000, #cc0000); }
    .bg-tg-ch { background: linear-gradient(145deg, #229ED9, #1a7ab3); }
    .bg-tg-gp { background: linear-gradient(145deg, #0088cc, #006994); }

    /* link text */
    .link-text {
        flex-grow: 1;
    }
    .link-text .title {
        font-weight: 700;
        color: #0b253c;
        font-size: 15px;
        margin-bottom: 2px;
    }
    .link-text .sub {
        font-size: 12px;
        color: #64748b;
    }

    /* video items */
    .video-item-wrapper {
        margin-bottom: 30px;
        border-bottom: 1px solid #f1f5f9;
        padding-bottom: 25px;
    }
    .video-item-wrapper:last-child {
        border-bottom: none;
        margin-bottom: 0;
        padding-bottom: 0;
    }

    .video-container {
        position: relative;
        padding-bottom: 56.25%;
        height: 0;
        overflow: hidden;
        border-radius: 24px;
        box-shadow: 0 15px 25px -8px rgba(0,0,0,0.1);
        border: 1px solid #eef2f6;
    }
    .video-container iframe {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: none;
    }
    .vid-title {
        font-weight: 700;
        color: #0b253c;
        margin-top: 12px;
        font-size: 15px;
        padding-left: 6px;
    }

    /* empty state */
    .empty-state {
        background: #f8fafc;
        border-radius: 24px;
        padding: 40px 20px;
        text-align: center;
        color: #94a3b8;
        border: 1px dashed #cbd5e1;
    }
    .empty-state i {
        color: #cbd5e1;
        margin-bottom: 10px;
    }

    /* pulse animation for inactive card */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* back link (optional) */
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 25px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #3b82f6;
    }
</style>

<div class="container-custom pb-5">
    <!-- header -->
    <div class="section-title mt-4">
        <i class="fa-solid fa-headset" style="color: #4f46e5;"></i> কাস্টমার সাপোর্ট
    </div>

    <div class="row g-4">
        <!-- সোশ্যাল লিঙ্ক সেকশন (বাম পাশে) -->
        <div class="col-md-5">
            <div class="support-card animate-fade-up">
                <div class="card-header-custom">
                    <i class="fa-solid fa-link" style="color: #4f46e5;"></i> সাপোর্ট চ্যানেল
                </div>

                <a href="<?= htmlspecialchars($fb) ?>" target="_blank" class="social-link-item">
                    <div class="icon-box bg-fb"><i class="fa-brands fa-facebook"></i></div>
                    <div class="link-text">
                        <div class="title">Facebook Page</div>
                        <div class="sub">Like & Follow us</div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-muted"></i>
                </a>

                <a href="<?= htmlspecialchars($tg_ch) ?>" target="_blank" class="social-link-item">
                    <div class="icon-box bg-tg-ch"><i class="fa-brands fa-telegram"></i></div>
                    <div class="link-text">
                        <div class="title">Telegram Channel</div>
                        <div class="sub">Get all updates</div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-muted"></i>
                </a>

                <a href="<?= htmlspecialchars($tg_gp) ?>" target="_blank" class="social-link-item">
                    <div class="icon-box bg-tg-gp"><i class="fa-solid fa-users"></i></div>
                    <div class="link-text">
                        <div class="title">Support Group</div>
                        <div class="sub">Chat with members</div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-muted"></i>
                </a>

                <a href="<?= htmlspecialchars($yt) ?>" target="_blank" class="social-link-item">
                    <div class="icon-box bg-yt"><i class="fa-brands fa-youtube"></i></div>
                    <div class="link-text">
                        <div class="title">YouTube Channel</div>
                        <div class="sub">Official Videos</div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-muted"></i>
                </a>
            </div>
        </div>

        <!-- ভিডিও সেকশন (ডান পাশে) -->
        <div class="col-md-7">
            <div class="support-card animate-fade-up">
                <div class="card-header-custom">
                    <i class="fa-solid fa-play-circle" style="color: #ef4444;"></i> ট্রেনিং টিউটোরিয়াল
                </div>

                <?php if($videos && $videos->num_rows > 0): while($v = $videos->fetch_assoc()): ?>
                    <div class="video-item-wrapper">
                        <div class="video-container">
                            <iframe src="https://www.youtube.com/embed/<?= htmlspecialchars($v['video_id']) ?>" allowfullscreen></iframe>
                        </div>
                        <div class="vid-title"><?= htmlspecialchars($v['video_title']) ?></div>
                    </div>
                <?php endwhile; else: ?>
                    <div class="empty-state">
                        <i class="fa-solid fa-video-slash fa-3x mb-2"></i>
                        <p class="small">ভিডিও টিউটোরিয়াল শীঘ্রই আসছে...</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- optional back to dashboard (though not in original, can be added for consistency) -->
    <div class="text-center mt-5">
        <a href="dashboard.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> ড্যাশবোর্ডে ফিরুন
        </a>
    </div>
</div>

<!-- entrance animation -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const cards = document.querySelectorAll('.support-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'all 0.6s ease';
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, index * 150);
        });
    });
</script>

<?php include "footer.php"; ?>