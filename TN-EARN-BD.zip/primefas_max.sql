/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.17-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: primefas_max
-- ------------------------------------------------------
-- Server version	10.11.17-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activation_requests`
--

DROP TABLE IF EXISTS `activation_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activation_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `sender_number` varchar(20) NOT NULL,
  `trx_id` varchar(50) NOT NULL,
  `amount` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activation_requests`
--

LOCK TABLES `activation_requests` WRITE;
/*!40000 ALTER TABLE `activation_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `activation_requests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_settings`
--

DROP TABLE IF EXISTS `admin_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `referral_bonus` decimal(10,2) DEFAULT 10.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=923 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_settings`
--

LOCK TABLES `admin_settings` WRITE;
/*!40000 ALTER TABLE `admin_settings` DISABLE KEYS */;
INSERT INTO `admin_settings` (`id`, `setting_key`, `setting_value`, `referral_bonus`) VALUES (1,'referral_bonus_amount','2.00',10.00),
(3,'site_title','INCOME OFFICIAL JOB à¦ à¦¸à§à¦¬à¦¾à¦—à¦¤à¦®',10.00),
(4,'site_name','INCOME OFFICIAL JOB',10.00),
(5,'meta_keywords','',10.00),
(6,'site_logo','../uploads/1780313873_logo.jpg',10.00),
(7,'site_favicon','',10.00),
(8,'task_microjob_status','active',10.00),
(9,'task_facebook_status','active',10.00),
(10,'task_gmail_status','active',10.00),
(11,'task_instagram_status','active',10.00),
(12,'task_typing_status','active',10.00),
(13,'limit_facebook','10',10.00),
(14,'limit_gmail','5',10.00),
(15,'limit_instagram','10',10.00),
(16,'referral_bonus','10',10.00),
(17,'salary_bonus','0.00',10.00),
(18,'activation_fee','15',10.00),
(19,'min_withdraw','25',10.00),
(20,'max_withdraw','550',10.00),
(21,'sahabi_pay_status','active',10.00),
(22,'sahabi_pay_url','https://sahabipay.com/api',10.00),
(23,'sahabi_pay_api_key','',10.00),
(24,'site_start_date','2025-12-20T11:09',10.00),
(25,'telegram_group_link','https://t.me/atik_dev_hub',10.00),
(26,'telegram_channel_link','https://t.me/money_job_site',10.00),
(46,'notice_text','à¦†à¦¸à¦¸à¦¾à¦²à¦¾à¦®à§ à¦†à¦²à¦¾à¦‡à¦•à§à¦® à¦†à¦®à¦¾à¦¦à§‡à¦° à¦…à¦«à¦¿à¦¸à¦¿à§Ÿà¦¾à¦² à¦šà§à¦¯à¦¾à¦¨à§‡à¦²à§‡ à¦°à¦¾à¦¤ â° 09:30 PM à¦ à§§à§¦à§¦à§¦ à¦Ÿà¦¾à¦•à¦¾à¦° à¦—à¦¿à¦­à¦“à§Ÿà§‡ à¦¹à¦¬à§‡à¥¤ ðŸ¤‘',10.00),
(47,'bkash_number','01811514009',10.00),
(48,'nagad_number','01402946189',10.00),
(56,'niva_username','sha13161',10.00),
(57,'top_username','',10.00),
(58,'riva_username','',10.00),
(59,'ns_username','',10.00),
(60,'niva_status','active',10.00),
(61,'top_status','active',10.00),
(62,'riva_status','active',10.00),
(63,'ns_status','active',10.00),
(84,'gmail_sell_pass','moneyjobsite@002',10.00),
(85,'fb_sell_pass','moneyjobsite@02',10.00),
(86,'insta_sell_pass','moneyjobsite@020',10.00),
(99,'task_coins_status','active',10.00),
(122,'gmail_rate','15',10.00),
(123,'fb_rate','5',10.00),
(124,'insta_rate','3',10.00),
(125,'niva_rate','3.50',10.00),
(126,'top_rate','0',10.00),
(127,'riva_rate','0',10.00),
(128,'ns_rate','0',10.00),
(149,'support_fb','https://www.effectivegatecpm.com/nwac4z6k?key=dd60e1febf17a286704660df1a97286b',10.00),
(150,'support_yt','https://www.effectivegatecpm.com/g6yxz3px?key=e8ab26465429d85d47f61279c01990b1',10.00),
(151,'support_tg_ch','https://t.me/incameofficialjob',10.00),
(152,'support_tg_gp','https://t.me/incameofficialjob',10.00),
(407,'sahabipay_api_key','wRmkoF1of4Gn55yPZoNSyE6u6myry5xeYYVIpBi46beM2fKZVa',10.00);
/*!40000 ALTER TABLE `admin_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin_sales`
--

DROP TABLE IF EXISTS `coin_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `coin_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `coin_type` varchar(50) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `sender_username` varchar(100) NOT NULL,
  `screenshot` varchar(255) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `rate` decimal(10,2) DEFAULT 0.00,
  `taka_amount` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin_sales`
--

LOCK TABLES `coin_sales` WRITE;
/*!40000 ALTER TABLE `coin_sales` DISABLE KEYS */;
INSERT INTO `coin_sales` (`id`, `user_id`, `coin_type`, `amount`, `sender_username`, `screenshot`, `status`, `created_at`, `rate`, `taka_amount`) VALUES (1,556,'NIVA',18818.00,'Robin@','coin_1780372975_IMG_20260601_191810_220.jpg','rejected','2026-06-02 04:02:55',0.00,0.00),
(2,556,'NIVA',18818.00,'Robin@','coin_1780373029_IMG_20260601_191810_220.jpg','pending','2026-06-02 04:03:49',0.00,0.00),
(3,556,'NIVA',1000.00,'Robin@','coin_1780373053_Screenshot_2026-06-02-07-19-19-91.jpg','approved','2026-06-02 04:04:13',3.50,3.50),
(4,556,'NIVA',1000.00,'Robin@','coin_1780373146_Screenshot_2026-06-02-10-05-30-74.jpg','approved','2026-06-02 04:05:46',3.50,3.50),
(5,556,'NIVA',10000.00,'Robin@','coin_1780373801_Screenshot_2026-06-02-10-12-45-82.jpg','approved','2026-06-02 04:16:41',3.50,35.00);
/*!40000 ALTER TABLE `coin_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facebook_sales`
--

DROP TABLE IF EXISTS `facebook_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `facebook_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `uid` varchar(100) DEFAULT NULL,
  `gmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `two_fa` text DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected','processing') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facebook_sales`
--

LOCK TABLES `facebook_sales` WRITE;
/*!40000 ALTER TABLE `facebook_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `facebook_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_code_usage`
--

DROP TABLE IF EXISTS `gift_code_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_code_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gift_id` int(11) NOT NULL,
  `used_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_code_usage`
--

LOCK TABLES `gift_code_usage` WRITE;
/*!40000 ALTER TABLE `gift_code_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `gift_code_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gift_codes`
--

DROP TABLE IF EXISTS `gift_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gift_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `usage_limit` int(11) DEFAULT 1,
  `times_used` int(11) DEFAULT 0,
  `expiry_date` datetime NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gift_codes`
--

LOCK TABLES `gift_codes` WRITE;
/*!40000 ALTER TABLE `gift_codes` DISABLE KEYS */;
INSERT INTO `gift_codes` (`id`, `code`, `amount`, `usage_limit`, `times_used`, `expiry_date`, `status`, `created_at`) VALUES (18,'GIFT8I2CBX',5.00,5,0,'2026-02-28 11:41:00','active','2026-02-28 05:39:18'),
(19,'GIFTRPB26Z',5.00,1,0,'2026-02-28 11:46:00','active','2026-02-28 05:44:53'),
(20,'8108931894',20.00,1,0,'2026-02-28 14:41:00','active','2026-02-28 08:41:44');
/*!40000 ALTER TABLE `gift_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gmail_sales`
--

DROP TABLE IF EXISTS `gmail_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gmail_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gmail` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `status` enum('pending','processing','approved','rejected') DEFAULT 'pending',
  `rate` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `gmail_sales_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gmail_sales`
--

LOCK TABLES `gmail_sales` WRITE;
/*!40000 ALTER TABLE `gmail_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `gmail_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instagram_sales`
--

DROP TABLE IF EXISTS `instagram_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `instagram_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `insta_username` varchar(100) NOT NULL,
  `insta_password` varchar(255) NOT NULL,
  `two_fa_key` text DEFAULT NULL,
  `rate` decimal(10,2) DEFAULT 0.00,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instagram_sales`
--

LOCK TABLES `instagram_sales` WRITE;
/*!40000 ALTER TABLE `instagram_sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `instagram_sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `trx_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('pending','paid','failed') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_gateway`
--

DROP TABLE IF EXISTS `payment_gateway`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_gateway` (
  `setting_key` varchar(255) NOT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_gateway`
--

LOCK TABLES `payment_gateway` WRITE;
/*!40000 ALTER TABLE `payment_gateway` DISABLE KEYS */;
INSERT INTO `payment_gateway` (`setting_key`, `setting_value`) VALUES ('activation_fee','10'),
('axmirpay_api_key','');
/*!40000 ALTER TABLE `payment_gateway` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `duration_days` int(11) NOT NULL,
  `daily_limit` int(11) NOT NULL,
  `task_rate` decimal(10,2) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premium_task_submissions`
--

DROP TABLE IF EXISTS `premium_task_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `premium_task_submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_id` int(11) NOT NULL,
  `proof_text` text DEFAULT NULL,
  `proof_img` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premium_task_submissions`
--

LOCK TABLES `premium_task_submissions` WRITE;
/*!40000 ALTER TABLE `premium_task_submissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `premium_task_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `premium_tasks`
--

DROP TABLE IF EXISTS `premium_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `premium_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `premium_tasks`
--

LOCK TABLES `premium_tasks` WRITE;
/*!40000 ALTER TABLE `premium_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `premium_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gmail_rate` decimal(10,2) DEFAULT 10.00,
  `niva_rate` decimal(10,2) DEFAULT 0.00,
  `top_rate` decimal(10,2) DEFAULT 0.00,
  `riva_rate` decimal(10,2) DEFAULT 0.00,
  `ns_rate` decimal(10,2) DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` (`id`, `gmail_rate`, `niva_rate`, `top_rate`, `riva_rate`, `ns_rate`) VALUES (1,10.00,0.00,0.00,0.00,0.00);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_messages`
--

DROP TABLE IF EXISTS `support_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_messages`
--

LOCK TABLES `support_messages` WRITE;
/*!40000 ALTER TABLE `support_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `support_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `support_videos`
--

DROP TABLE IF EXISTS `support_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `support_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_title` varchar(255) NOT NULL,
  `video_id` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `support_videos`
--

LOCK TABLES `support_videos` WRITE;
/*!40000 ALTER TABLE `support_videos` DISABLE KEYS */;
INSERT INTO `support_videos` (`id`, `video_title`, `video_id`, `created_at`) VALUES (13,'à¦¸à¦¾à¦‡à¦Ÿà§‡à¦° à¦«à§à¦² à¦Ÿà¦¿à¦‰à¦Ÿà§‹à¦°à¦¿à§Ÿà¦¾à¦² ','uX1TrJi6Zzw?si=w2fgWSoHtvqmGRtR','2026-02-27 11:45:12');
/*!40000 ALTER TABLE `support_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `reward` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_job_logs`
--

DROP TABLE IF EXISTS `user_job_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_job_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `job_id` int(11) NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_job_logs`
--

LOCK TABLES `user_job_logs` WRITE;
/*!40000 ALTER TABLE `user_job_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_job_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_tasks`
--

DROP TABLE IF EXISTS `user_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `task_id` int(11) DEFAULT NULL,
  `photo1` varchar(255) DEFAULT NULL,
  `photo2` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `submitted_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`),
  CONSTRAINT `user_tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_tasks_ibfk_2` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_tasks`
--

LOCK TABLES `user_tasks` WRITE;
/*!40000 ALTER TABLE `user_tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `telegram_id` varchar(100) DEFAULT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `referral_code` varchar(10) DEFAULT NULL,
  `referred_by` varchar(10) DEFAULT NULL,
  `referral_count` int(11) NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `referred_by_id` int(11) DEFAULT NULL,
  `balance` decimal(10,2) DEFAULT 0.00,
  `typing_balance` decimal(10,2) DEFAULT 0.00,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('active','banned') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `role` enum('user','admin') DEFAULT 'user',
  `referral_income` decimal(10,2) DEFAULT 0.00,
  `total_withdraw` decimal(10,2) DEFAULT 0.00,
  `gmail_balance` decimal(10,2) DEFAULT 0.00,
  `salary_balance` decimal(10,2) DEFAULT 0.00,
  `job_balance` decimal(10,2) DEFAULT 0.00,
  `plan_id` int(11) DEFAULT 0,
  `plan_expire_date` date DEFAULT NULL,
  `daily_task_count` int(11) DEFAULT 0,
  `last_task_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `referral_code` (`referral_code`),
  UNIQUE KEY `telegram_id` (`telegram_id`)
) ENGINE=InnoDB AUTO_INCREMENT=558 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `telegram_id`, `fullname`, `email`, `referral_code`, `referred_by`, `referral_count`, `password`, `profile_pic`, `referred_by_id`, `balance`, `typing_balance`, `is_active`, `status`, `created_at`, `role`, `referral_income`, `total_withdraw`, `gmail_balance`, `salary_balance`, `job_balance`, `plan_id`, `plan_expire_date`, `daily_task_count`, `last_task_date`) VALUES (552,NULL,'TN OWNER ','teamnovabd@gmail.com',NULL,NULL,1,'$2y$12$68F6FNscdcHL/6K2zmbkreWPWDXBZBSJfXHYnx2nMIW8fk4RYVc/G',NULL,0,15.00,0.00,0,'active','2026-06-01 11:35:04','admin',15.00,0.00,0.00,0.00,0.00,0,NULL,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visiting_jobs`
--

DROP TABLE IF EXISTS `visiting_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `visiting_jobs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `thumbnail` varchar(255) DEFAULT 'https://via.placeholder.com/150',
  `reward` decimal(10,2) NOT NULL,
  `seconds` int(11) NOT NULL,
  `status` varchar(20) DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visiting_jobs`
--

LOCK TABLES `visiting_jobs` WRITE;
/*!40000 ALTER TABLE `visiting_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `visiting_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraw_methods`
--

DROP TABLE IF EXISTS `withdraw_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraw_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `method_name` varchar(50) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraw_methods`
--

LOCK TABLES `withdraw_methods` WRITE;
/*!40000 ALTER TABLE `withdraw_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraw_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `withdraws`
--

DROP TABLE IF EXISTS `withdraws`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `withdraws` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `method` varchar(50) NOT NULL,
  `number` varchar(50) NOT NULL,
  `trx_id` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  CONSTRAINT `fk_withdraws_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `withdraws`
--

LOCK TABLES `withdraws` WRITE;
/*!40000 ALTER TABLE `withdraws` DISABLE KEYS */;
/*!40000 ALTER TABLE `withdraws` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'primefas_max'
--

--
-- Dumping routines for database 'primefas_max'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-02 10:08:17
