<?php
session_start();
include "config.php";

// Fetch settings
$settings = [];
$res = $conn->query("SELECT setting_key, setting_value FROM admin_settings WHERE setting_key IN ('site_title', 'site_logo', 'site_favicon')");
while ($row = $res->fetch_assoc()) {
    $settings[$row['setting_key']] = $row['setting_value'];
}
$site_title = $settings['site_title'] ?? 'Unique Earn BD';
$site_logo = !empty($settings['site_logo']) ? str_replace("../", "", $settings['site_logo']) : 'image/logo.png';
$site_favicon = !empty($settings['site_favicon']) ? str_replace("../", "", $settings['site_favicon']) : 'image/logo.png';

$msg = "";

if (isset($_POST['register'])) {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $referral_id = $conn->real_escape_string($_POST['referral_id']);

    $checkEmail = $conn->query("SELECT email FROM users WHERE email='$email'");

    if ($checkEmail->num_rows > 0) {
        $msg = '<div class="error-message"><i class="fa-solid fa-circle-exclamation"></i> This email is already registered!</div>';
    } elseif ($password !== $confirm_password) {
        $msg = '<div class="error-message"><i class="fa-solid fa-triangle-exclamation"></i> Passwords do not match!</div>';
    } elseif (strlen($password) < 6) {
        $msg = '<div class="error-message"><i class="fa-solid fa-triangle-exclamation"></i> Password must be at least 6 characters long!</div>';
    } else {
        $hashed_pass = password_hash($password, PASSWORD_BCRYPT);

        // Referral logic
        $referred_by_id = 0;
        if (!empty($referral_id)) {
            $refCheck = $conn->query("SELECT id FROM users WHERE id='$referral_id'");
            if ($refCheck->num_rows > 0) {
                $referred_by_id = $refCheck->fetch_assoc()['id'];
            }
        }

        $stmt = $conn->prepare("INSERT INTO users (fullname, email, password, referred_by_id, status, created_at) VALUES (?, ?, ?, ?, 'inactive', NOW())");
        $stmt->bind_param("sssi", $fullname, $email, $hashed_pass, $referred_by_id);

        if ($stmt->execute()) {
            $new_user_id = $conn->insert_id;
            $_SESSION['fullname'] = $fullname;
            $_SESSION['email'] = $email;
            $_SESSION['user_id'] = $new_user_id;

            // ✅ Referral bonus — referrer-এর balance, referral_income ও referral_count update
            if ($referred_by_id > 0) {
                $conn->query("UPDATE users SET 
                    balance          = balance + 10,
                    referral_income  = referral_income + 10,
                    referral_count   = referral_count + 1
                WHERE id = '$referred_by_id'");
            }

            header("Location: dashboard.php");
            exit();
        } else {
            $msg = '<div class="error-message"><i class="fa-solid fa-circle-exclamation"></i> Server error, please try again!</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | <?= htmlspecialchars($site_title) ?></title>
    <link rel="icon" href="<?= htmlspecialchars($site_favicon) ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
            background: #f4f7fc;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1rem;
        }

        .register-wrapper {
            width: 100%;
            max-width: 460px;
            margin: 0 auto;
        }

        .tab-switcher {
            display: flex;
            background: white;
            padding: 0.5rem;
            border-radius: 60px;
            width: 100%;
            max-width: 300px;
            margin: 0 auto 2rem auto;
            box-shadow: 0 10px 20px -8px rgba(0,50,100,0.1);
            border: 1px solid #eef2f6;
        }
        .tab-switcher a, .tab-switcher button {
            flex: 1;
            padding: 0.75rem 1rem;
            font-weight: 700;
            font-size: 0.95rem;
            text-align: center;
            border-radius: 50px;
            transition: all 0.2s ease;
            text-decoration: none;
            background: transparent;
            border: none;
            cursor: pointer;
        }
        .tab-switcher a {
            color: #64748b;
        }
        .tab-switcher .active-tab {
            background: linear-gradient(90deg, #4f46e5, #7c3aed);
            color: white;
            box-shadow: 0 10px 18px -6px #7c3aed80;
        }
        .tab-switcher a:hover {
            background: #f1f5f9;
        }

        .register-card {
            background: white;
            border-radius: 32px;
            padding: 2rem 1.8rem;
            box-shadow: 0 20px 40px -12px rgba(0,50,100,0.15);
            border: 1px solid #f0f4fa;
            width: 100%;
            transition: all 0.25s ease;
        }

        .logo-area {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.5rem;
        }
        .logo-area img {
            height: 56px;
            width: auto;
            object-fit: contain;
        }
        .logo-area h1 {
            font-size: 1.8rem;
            font-weight: 800;
            color: #0b253c;
            letter-spacing: -0.5px;
        }
        .logo-area p {
            color: #64748b;
            font-size: 0.9rem;
        }

        .error-message {
            background: #fee2e2;
            border: 1px solid #fecaca;
            color: #b91c1c;
            padding: 0.9rem 1.2rem;
            border-radius: 60px;
            font-size: 0.9rem;
            font-weight: 500;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.6rem;
        }
        .error-message i {
            font-size: 1.1rem;
        }

        .form-group {
            position: relative;
            margin-bottom: 1.2rem;
        }
        .form-group input {
            width: 100%;
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            border-radius: 60px;
            padding: 1rem 1.5rem 1rem 3rem;
            font-size: 0.95rem;
            color: #1e293b;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .form-group input:focus {
            outline: 2px solid #4f46e5;
            background: white;
            border-color: transparent;
        }
        .form-group i.input-icon {
            position: absolute;
            left: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 1.1rem;
            transition: color 0.2s;
        }
        .form-group:focus-within i.input-icon {
            color: #4f46e5;
        }
        .form-group .toggle-password {
            position: absolute;
            right: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            font-size: 1.1rem;
        }
        .form-group .toggle-password:hover {
            color: #4f46e5;
        }

        .strength-bar {
            height: 6px;
            background: #e2e8f0;
            border-radius: 10px;
            margin-top: 0.5rem;
            overflow: hidden;
        }
        .strength-fill {
            height: 100%;
            width: 0;
            transition: all 0.3s ease;
        }
        .strength-text {
            font-size: 0.75rem;
            font-weight: 600;
            margin-top: 0.2rem;
            text-align: right;
            color: #64748b;
        }

        .confirm-message {
            position: absolute;
            right: 1.2rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.1rem;
        }

        .btn-register {
            background: linear-gradient(90deg, #4f46e5, #7c3aed);
            border: none;
            color: white;
            font-weight: 800;
            padding: 1.1rem 1.5rem;
            border-radius: 60px;
            width: 100%;
            font-size: 1.1rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            box-shadow: 0 15px 25px -8px #7c3aed80;
            transition: all 0.2s ease;
            border: 1px solid rgba(255,255,255,0.2);
            margin-top: 0.5rem;
            cursor: pointer;
        }
        .btn-register:hover {
            background: linear-gradient(90deg, #4338ca, #6d28d9);
            transform: scale(1.02);
            box-shadow: 0 18px 30px -6px #5b21b6;
        }

        .login-link {
            text-align: center;
            margin-top: 1.8rem;
            color: #64748b;
            font-weight: 500;
            font-size: 0.9rem;
        }
        .login-link a {
            color: #4f46e5;
            font-weight: 700;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }

        .bottom-indicator {
            margin-top: 2rem;
            display: flex;
            justify-content: center;
        }
        .bottom-indicator span {
            width: 80px;
            height: 5px;
            background: #cbd5e1;
            border-radius: 10px;
        }

        .animate-fade-up {
            animation: fadeUp 0.6s ease-out forwards;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>
    <div class="register-wrapper">
        <div class="tab-switcher animate-fade-up">
            <a href="login.php">Login</a>
            <button class="active-tab">Register</button>
        </div>

        <div class="register-card animate-fade-up" style="animation-delay: 0.1s;">
            <div class="logo-area">
                <?php if(file_exists($site_logo) && !empty($site_logo)): ?>
                    <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo">
                <?php else: ?>
                    <div style="width:56px; height:56px; background:#eef2ff; border-radius:18px; display:flex; align-items:center; justify-content:center; color:#4f46e5; font-size:28px;">
                        <i class="fas fa-user-plus"></i>
                    </div>
                <?php endif; ?>
                <h1>Create Account</h1>
                <p>Join <?= htmlspecialchars($site_title) ?></p>
            </div>

            <?= $msg ?>

            <form method="post" id="registerForm">
                <div class="form-group">
                    <i class="fas fa-gift input-icon"></i>
                    <input type="text" name="referral_id" placeholder="Referral ID (optional)" value="<?= isset($_GET['ref']) ? htmlspecialchars($_GET['ref']) : '' ?>">
                </div>

                <div class="form-group">
                    <i class="fas fa-user input-icon"></i>
                    <input type="text" name="fullname" placeholder="Full Name" required>
                </div>

                <div class="form-group">
                    <i class="far fa-envelope input-icon"></i>
                    <input type="email" name="email" placeholder="Email Address" required>
                </div>

                <div class="form-group">
                    <i class="fas fa-lock input-icon"></i>
                    <input type="password" name="password" id="password" placeholder="Password (min 6 characters)" required minlength="6">
                    <button type="button" class="toggle-password" id="togglePassword" tabindex="-1">
                        <i class="fas fa-eye"></i>
                    </button>
                    <div class="strength-bar">
                        <div class="strength-fill" id="strengthFill"></div>
                    </div>
                    <div class="strength-text" id="passwordStrength"></div>
                </div>

                <div class="form-group">
                    <i class="fas fa-check-circle input-icon"></i>
                    <input type="password" name="confirm_password" id="confirmPassword" placeholder="Confirm Password" required>
                    <div class="confirm-message" id="confirmMessage"></div>
                </div>

                <button type="submit" name="register" class="btn-register">
                    <span>Create Account</span>
                    <i class="fas fa-arrow-right"></i>
                </button>
            </form>

            <div class="login-link">
                Already have an account? <a href="login.php">Login</a>
            </div>
        </div>

        <div class="bottom-indicator">
            <span></span>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('confirmPassword');
            const strengthFill = document.getElementById('strengthFill');
            const strengthText = document.getElementById('passwordStrength');
            const confirmMessage = document.getElementById('confirmMessage');

            togglePassword.addEventListener('click', function() {
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.innerHTML = type === 'password' ? '<i class="fas fa-eye"></i>' : '<i class="fas fa-eye-slash" style="color:#4f46e5;"></i>';
            });

            passwordInput.addEventListener('input', function() {
                const val = this.value;
                let strength = 0;
                if(val.length >= 6) strength += 1;
                if(val.match(/[A-Za-z]/) && val.match(/[0-9]/)) strength += 1;
                if(val.match(/[^a-zA-Z0-9]/)) strength += 1;

                if(val.length === 0) {
                    strengthFill.style.width = '0%';
                    strengthText.innerText = '';
                } else if(strength === 1) {
                    strengthFill.style.width = '33%';
                    strengthFill.style.background = '#ef4444';
                    strengthText.innerText = 'Weak';
                } else if(strength === 2) {
                    strengthFill.style.width = '66%';
                    strengthFill.style.background = '#f59e0b';
                    strengthText.innerText = 'Medium';
                } else {
                    strengthFill.style.width = '100%';
                    strengthFill.style.background = '#10b981';
                    strengthText.innerText = 'Strong';
                }
            });

            confirmPasswordInput.addEventListener('input', function() {
                if(this.value === passwordInput.value && this.value !== '') {
                    confirmMessage.innerHTML = '<i class="fas fa-check" style="color:#10b981;"></i>';
                    this.style.borderColor = '#10b981';
                } else {
                    confirmMessage.innerHTML = '<i class="fas fa-times" style="color:#ef4444;"></i>';
                    this.style.borderColor = '#ef4444';
                }
                if(this.value === '') {
                    confirmMessage.innerHTML = '';
                    this.style.borderColor = '';
                }
            });
        });
    </script>
</body>
</html>
