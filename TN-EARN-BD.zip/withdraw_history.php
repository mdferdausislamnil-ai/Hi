<?php
include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">Withdraw History Access Denied!</h4>
                <p class="text-muted small px-3">Your account must be active to view history.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>Activate Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

$user_id = $u['id'];

// Fetch all withdrawal history for the user
$withdraw_query = $conn->query("SELECT * FROM withdraws WHERE user_id = '$user_id' ORDER BY id DESC");
?>

<!-- ====== WITHDRAW HISTORY PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 700px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* record count badge */
    .record-badge {
        background: white;
        color: #0b253c;
        border: 1px solid #e2e8f0;
        border-radius: 40px;
        padding: 8px 20px;
        font-weight: 600;
        font-size: 14px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.02);
    }

    /* history item card */
    .history-item {
        background: white;
        border-radius: 28px;
        padding: 18px 20px;
        margin-bottom: 15px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        display: flex;
        align-items: center;
        transition: all 0.25s ease;
    }
    .history-item:hover {
        transform: translateY(-4px);
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* method icon */
    .method-icon {
        width: 56px;
        height: 56px;
        background: #f8fafc;
        border-radius: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        color: #4f46e5;
        margin-right: 18px;
        flex-shrink: 0;
        border: 1px solid #eef2f6;
        box-shadow: 0 8px 16px -6px rgba(0,0,0,0.04);
    }

    /* info area */
    .info-box {
        flex-grow: 1;
        overflow: hidden;
    }
    .info-box .amount {
        font-weight: 800;
        font-size: 18px;
        color: #0b253c;
        margin-bottom: 4px;
        letter-spacing: -0.2px;
    }
    .info-box .details {
        font-size: 13px;
        color: #64748b;
        font-weight: 500;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .info-box .details i {
        color: #94a3b8;
        font-size: 12px;
    }

    /* status box */
    .status-box {
        text-align: right;
        flex-shrink: 0;
        min-width: 100px;
    }

    /* gradient status badges (like history.php) */
    .st-badge {
        padding: 6px 18px;
        border-radius: 40px;
        font-weight: 700;
        font-size: 12px;
        letter-spacing: 0.3px;
        display: inline-block;
        margin-bottom: 5px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        text-transform: capitalize;
    }
    .st-badge.pending {
        background: linear-gradient(145deg, #f59e0b, #d97706);
        color: white;
    }
    .st-badge.approved {
        background: linear-gradient(145deg, #10b981, #059669);
        color: white;
    }
    .st-badge.rejected {
        background: linear-gradient(145deg, #ef4444, #dc2626);
        color: white;
    }

    .time-text {
        font-size: 11px;
        color: #94a3b8;
        display: block;
        font-weight: 500;
    }

    /* empty state */
    .empty-state {
        background: white;
        border-radius: 32px;
        padding: 60px 20px;
        text-align: center;
        color: #94a3b8;
        border: 1px solid #f0f4fa;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
    }
    .empty-state i {
        color: #cbd5e1;
        margin-bottom: 15px;
    }
    .empty-state h6 {
        font-weight: 800;
        color: #0b253c;
        margin-bottom: 8px;
    }
    .empty-state .btn-primary {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        border: none;
        border-radius: 60px;
        padding: 10px 30px;
        font-weight: 700;
        box-shadow: 0 12px 22px -8px #7c3aed80;
        transition: 0.15s;
    }
    .empty-state .btn-primary:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #5b21b6;
    }

    /* pulse animation for inactive card */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* back link */
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 20px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #4f46e5;
    }
</style>

<div class="container-custom pb-5">
    <!-- header with title and record count -->
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <div class="section-title m-0">
            <i class="fa-solid fa-clock-rotate-left" style="color: #4f46e5;"></i> Withdraw History
        </div>
        <div class="record-badge">
            Records: <?= $withdraw_query->num_rows ?>
        </div>
    </div>

    <!-- history list -->
    <div class="history-container animate-fade-up">
        <?php if ($withdraw_query->num_rows > 0): ?>
            <?php while ($row = $withdraw_query->fetch_assoc()): ?>
                <div class="history-item">
                    <!-- method icon -->
                    <div class="method-icon">
                        <?php 
                        $method = strtolower($row['method']);
                        if(strpos($method, 'bkash') !== false) echo '<i class="fa-solid fa-mobile-screen-button" style="color: #d12053;"></i>';
                        elseif(strpos($method, 'nagad') !== false) echo '<i class="fa-solid fa-wallet" style="color: #f6921e;"></i>';
                        else echo '<i class="fa-solid fa-building-columns" style="color: #4f46e5;"></i>';
                        ?>
                    </div>

                    <!-- info -->
                    <div class="info-box">
                        <div class="amount">৳ <?= number_format($row['amount'], 2) ?></div>
                        <div class="details">
                            <i class="fa-regular fa-building"></i> <?= htmlspecialchars($row['method']) ?>
                            <span class="mx-1">•</span>
                            <i class="fa-regular fa-hashtag"></i> <?= htmlspecialchars($row['number']) ?>
                        </div>
                    </div>

                    <!-- status & time -->
                    <div class="status-box">
                        <span class="st-badge <?= $row['status'] ?>">
                            <?= $row['status'] == 'approved' ? 'Approved' : ($row['status'] == 'rejected' ? 'Rejected' : 'Pending') ?>
                        </span>
                        <span class="time-text"><?= date('d M, h:i A', strtotime($row['created_at'])) ?></span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <!-- empty state -->
            <div class="empty-state">
                <i class="fa-solid fa-receipt fa-4x mb-3"></i>
                <h6 class="fw-bold">No records found!</h6>
                <p class="small">You haven't made any withdrawal requests yet.</p>
                <a href="withdraw.php" class="btn btn-primary mt-3">Withdraw Now</a>
            </div>
        <?php endif; ?>
    </div>

    <!-- back to withdraw page -->
    <div class="text-center">
        <a href="withdraw.php" class="back-link">
            <i class="fa-solid fa-arrow-left"></i> Back to Withdraw Page
        </a>
    </div>
</div>

<!-- entrance animation -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const items = document.querySelectorAll('.history-item, .empty-state');
        items.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            item.style.transition = 'all 0.5s ease';
            setTimeout(() => {
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 100);
        });
    });
</script>

<?php include "footer.php"; ?>