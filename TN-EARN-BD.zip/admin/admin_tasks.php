<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ১. নতুন টাস্ক যোগ করা (ছবি আপলোড সহ)
if (isset($_POST['addTask'])) {
    $title  = $conn->real_escape_string($_POST['title']);
    $link   = $conn->real_escape_string($_POST['link']);
    $reward = floatval($_POST['reward']);
    $image  = "";

    // ছবি আপলোড হ্যান্ডলার
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "../uploads/tasks/";

        // ফোল্ডার না থাকলে তৈরি করো
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $ext      = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed  = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($ext, $allowed)) {
            $filename = "task_" . time() . "_" . rand(1000, 9999) . "." . $ext;
            $dest     = $upload_dir . $filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $image = $filename;
            } else {
                $msg = "danger|ছবি আপলোড করতে সমস্যা হয়েছে!";
            }
        } else {
            $msg = "warning|শুধুমাত্র JPG, PNG, GIF, WEBP ফরম্যাট অনুমতি আছে!";
        }
    }

    if (empty($msg)) {
        if (!empty($title) && !empty($reward)) {
            $sql = "INSERT INTO tasks (title, link, reward, image) VALUES ('$title', '$link', '$reward', '$image')";
            if ($conn->query($sql)) {
                $msg = "success|নতুন টাস্ক সফলভাবে যুক্ত হয়েছে!";
            } else {
                // যদি image কলাম না থাকে তাহলে ছাড়া insert করো
                $sql2 = "INSERT INTO tasks (title, link, reward) VALUES ('$title', '$link', '$reward')";
                if ($conn->query($sql2)) {
                    $msg = "success|নতুন টাস্ক যুক্ত হয়েছে (ছবি ছাড়া — image কলাম নেই)!";
                } else {
                    $msg = "danger|এরর: " . $conn->error;
                }
            }
        } else {
            $msg = "warning|দয়া করে সব তথ্য পূরণ করুন!";
        }
    }
}

// ২. টাস্ক ডিলিট করা
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // ছবি ফাইলও ডিলিট করো
    $r = $conn->query("SELECT image FROM tasks WHERE id=$id");
    if ($r && $row = $r->fetch_assoc()) {
        if (!empty($row['image'])) {
            $img_path = "../uploads/tasks/" . $row['image'];
            if (file_exists($img_path)) unlink($img_path);
        }
    }
    $conn->query("DELETE FROM tasks WHERE id=$id");
    header("Location: admin_tasks.php?msg=deleted");
    exit();
}

// ৩. সব টাস্ক ফেচ করা
$tasks = $conn->query("SELECT * FROM tasks ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Microjobs | Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.06); margin-bottom: 24px; }
        .card-header { background: #fff; border-bottom: 1px solid #f0f0f0; padding: 15px 22px; font-weight: 700; border-radius: 20px 20px 0 0 !important; }

        .form-control, .form-select {
            border-radius: 12px; padding: 11px 14px;
            border: 1px solid #e2e8f0; font-size: 14px;
        }
        .form-control:focus, .form-select:focus {
            border-color: #4f46e5;
            box-shadow: 0 0 0 4px rgba(79,70,229,0.1);
        }

        /* ছবি প্রিভিউ বক্স */
        .img-upload-box {
            border: 2px dashed #c7d2fe;
            border-radius: 16px;
            padding: 18px;
            text-align: center;
            background: #f5f3ff;
            cursor: pointer;
            transition: 0.3s;
            position: relative;
        }
        .img-upload-box:hover { border-color: #4f46e5; background: #ede9fe; }
        .img-upload-box input[type=file] {
            position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
        }
        #imgPreview {
            max-width: 100%; max-height: 130px;
            border-radius: 10px; display: none; margin: 8px auto 0;
        }

        .btn-add {
            background: #4f46e5; color: #fff; border: none;
            border-radius: 12px; font-weight: 700; transition: 0.3s;
        }
        .btn-add:hover { background: #3730a3; color: #fff; transform: translateY(-2px); }

        /* টেবিল */
        .table thead { background: #1e293b; color: #fff; font-size: 12px; text-transform: uppercase; }
        .table td { vertical-align: middle; padding: 14px; font-size: 14px; }
        .reward-badge {
            background: #dcfce7; color: #166534;
            padding: 5px 12px; border-radius: 50px; font-weight: 800;
        }
        .action-btn {
            width: 34px; height: 34px; border-radius: 10px;
            display: inline-flex; align-items: center; justify-content: center; transition: 0.3s;
            border: none; cursor: pointer;
        }
        .btn-link-view { background: #e0e7ff; color: #4338ca; }
        .btn-delete    { background: #fee2e2; color: #b91c1c; }
        .action-btn:hover { transform: scale(1.1); }

        /* টাস্ক থাম্বনেইল */
        .task-thumb {
            width: 52px; height: 52px; object-fit: cover;
            border-radius: 10px; border: 2px solid #e2e8f0;
        }
        .no-thumb {
            width: 52px; height: 52px; border-radius: 10px;
            background: #f1f5f9; display: flex; align-items: center;
            justify-content: center; color: #94a3b8; font-size: 20px;
        }

        @media(max-width:768px){
            .card-header { font-size: 14px; }
            .table td { font-size: 13px; padding: 10px; }
        }
    </style>
</head>
<body class="p-3">
<div class="container">

    <!-- হেডার -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold m-0 text-dark">
            <i class="fa-solid fa-list-check text-primary me-2"></i>Manage Microjobs
        </h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">
            <i class="fa-solid fa-house me-1"></i> Dashboard
        </a>
    </div>

    <!-- অ্যালার্ট -->
    <?php
    if (!empty($msg) || isset($_GET['msg'])) {
        if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') $msg = "danger|🗑️ টাস্কটি ডিলিট করা হয়েছে!";
        $m = explode('|', $msg);
    ?>
    <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small alert-dismissible fade show">
        <i class="fa-solid fa-circle-info me-2"></i> <?= $m[1] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php } ?>

    <div class="row">

        <!-- ফর্ম -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <i class="fa-solid fa-plus-circle text-success me-2"></i>Create New Job
                </div>
                <div class="card-body p-4">
                    <form method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label class="form-label small fw-bold">📌 Job Title (কাজের নাম)</label>
                            <input type="text" name="title" class="form-control"
                                placeholder="যেমন: Subscribe our YouTube" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">🔗 Job Link (লিঙ্ক)</label>
                            <input type="url" name="link" class="form-control" placeholder="https://...">
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">💰 Reward (কত টাকা)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0 fw-bold">৳</span>
                                <input type="number" step="0.01" name="reward" class="form-control border-start-0"
                                    placeholder="0.00" required>
                            </div>
                        </div>

                        <!-- ছবি আপলোড -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold">🖼️ Job Image (ছবি)</label>
                            <div class="img-upload-box" id="uploadBox">
                                <input type="file" name="image" id="imageInput" accept="image/*"
                                    onchange="previewImage(this)">
                                <i class="fa-solid fa-cloud-arrow-up fa-2x text-indigo-400 mb-1"
                                   style="color:#818cf8;"></i>
                                <div class="small text-muted mt-1">ক্লিক করে ছবি বেছে নিন</div>
                                <div class="small text-muted" style="font-size:11px;">JPG, PNG, WEBP সাপোর্টেড</div>
                                <img id="imgPreview" src="" alt="preview">
                            </div>
                        </div>

                        <button type="submit" name="addTask" class="btn btn-add w-100 py-3">
                            PUBLISH JOB <i class="fa-solid fa-paper-plane ms-1"></i>
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- টাস্ক লিস্ট -->
        <div class="col-lg-8">
            <div class="card overflow-hidden">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span><i class="fa-solid fa-table-list text-primary me-2"></i>Existing Jobs</span>
                    <span class="badge bg-primary rounded-pill"><?= $tasks->num_rows ?> Total</span>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr class="text-center">
                                <th>Image</th>
                                <th class="text-start">Job Details</th>
                                <th>Reward</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($tasks->num_rows > 0): while ($row = $tasks->fetch_assoc()): ?>
                        <tr class="text-center">
                            <td>
                                <?php
                                $img_path = "../uploads/tasks/" . $row['image'];
                                if (!empty($row['image']) && file_exists($img_path)):
                                ?>
                                    <img src="<?= $img_path ?>" class="task-thumb"
                                         onclick="viewImg(this.src)" style="cursor:pointer;"
                                         title="ক্লিক করে বড় দেখুন">
                                <?php else: ?>
                                    <div class="no-thumb mx-auto">
                                        <i class="fa-regular fa-image"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-start">
                                <div class="fw-bold text-dark"><?= htmlspecialchars($row['title']) ?></div>
                                <?php if (!empty($row['link'])): ?>
                                <div class="small text-muted text-truncate" style="max-width:190px;">
                                    <?= htmlspecialchars($row['link']) ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="reward-badge">৳<?= number_format($row['reward'], 2) ?></span>
                            </td>
                            <td>
                                <div class="d-flex gap-2 justify-content-center">
                                    <?php if (!empty($row['link'])): ?>
                                    <a href="<?= htmlspecialchars($row['link']) ?>" target="_blank"
                                       class="action-btn btn-link-view" title="লিঙ্ক দেখুন">
                                        <i class="fa-solid fa-external-link"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="?delete=<?= $row['id'] ?>"
                                       class="action-btn btn-delete"
                                       onclick="return confirm('এই টাস্কটি ডিলিট করবেন?')"
                                       title="ডিলিট করুন">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">
                                <i class="fa-regular fa-folder-open fa-2x mb-2 d-block"></i>
                                কোনো টাস্ক তৈরি করা হয়নি।
                            </td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div><!-- /row -->
</div><!-- /container -->

<!-- ইমেজ প্রিভিউ মডাল -->
<div class="modal fade" id="vModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img src="" id="fullImg" class="img-fluid rounded-4 shadow-lg" style="max-height:90vh;">
                <div class="mt-3">
                    <button class="btn btn-light btn-sm rounded-pill px-4" data-bs-dismiss="modal">বন্ধ করুন</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// ছবি প্রিভিউ
function previewImage(input) {
    const preview = document.getElementById('imgPreview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// মডালে বড় ছবি দেখা
function viewImg(src) {
    document.getElementById('fullImg').src = src;
    new bootstrap.Modal(document.getElementById('vModal')).show();
}
</script>
</body>
</html>
