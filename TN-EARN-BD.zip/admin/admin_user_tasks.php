<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    $query = $conn->query("SELECT ut.*, t.reward, u.id as uid FROM user_tasks ut 
                           JOIN tasks t ON ut.task_id = t.id 
                           JOIN users u ON ut.user_id = u.id 
                           WHERE ut.id = '$id'");
    
    if ($query->num_rows > 0) {
        $data = $query->fetch_assoc();
        $user_id = $data['uid'];
        $reward = $data['reward'];

        if ($action == 'approve' && $data['status'] == 'pending') {
            $conn->query("UPDATE users SET balance = balance + $reward WHERE id = '$user_id'");
            $conn->query("UPDATE user_tasks SET status = 'approved' WHERE id = '$id'");
            $msg = "success|✅ টাস্কটি অ্যাপ্রুভ হয়েছে এবং ৳$reward যোগ হয়েছে।";
        } 
        elseif ($action == 'reject' && $data['status'] == 'pending') {
            $conn->query("UPDATE user_tasks SET status = 'rejected' WHERE id = '$id'");
            $msg = "warning|❌ টাস্কটি রিজেক্ট করা হয়েছে।";
        } 
        elseif ($action == 'delete') {
            $conn->query("DELETE FROM user_tasks WHERE id = '$id'");
            $msg = "danger|🗑️ রেকর্ড ডিলিট করা হয়েছে।";
        }
    }
}

// ৩. টাস্ক ফেচ করা
$tasks = $conn->query("SELECT ut.*, u.fullname, u.email, t.title, t.reward 
                       FROM user_tasks ut 
                       JOIN users u ON ut.user_id = u.id 
                       JOIN tasks t ON ut.task_id = t.id 
                       ORDER BY ut.id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Microjob Proofs | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .table thead { background: #1e293b; color: #fff; }
        .status-badge { font-size: 10px; padding: 4px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
        
        /* ইমেজ কন্টেইনার */
        .proof-img-box {
            width: 60px; height: 60px; object-fit: cover; 
            border-radius: 10px; border: 2px solid #fff; 
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            cursor: pointer; transition: 0.3s; background: #eee;
        }
        .proof-img-box:hover { transform: scale(1.1); }
        .no-img { font-size: 10px; color: #991b1b; background: #fee2e2; padding: 5px; border-radius: 5px; }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold"><i class="fa-solid fa-camera text-primary me-2"></i>Job Proofs Manager</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): 
        $m = explode('|', $msg);
    ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small py-2"><?= $m[1] ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User</th>
                        <th>Job Title</th>
                        <th>Screenshots</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $tasks->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= $row['fullname'] ?></div>
                            <div class="text-muted small" style="font-size: 10px;"><?= $row['email'] ?></div>
                        </td>
                        <td class="text-start small fw-bold text-dark"><?= $row['title'] ?></td>
                        <td>
                            <div class="d-flex gap-2 justify-content-center">
                                <?php 
                                // ইমেজের পাথ চেক করা (মেইন ডিরেক্টরি থেকে)
                                $p1 = "../uploads/tasks/" . $row['photo1'];
                                $p2 = "../uploads/tasks/" . $row['photo2'];
                                
                                if (!empty($row['photo1']) && file_exists($p1)) {
                                    echo '<img src="'.$p1.'" class="proof-img-box" onclick="viewImg(this.src)">';
                                } else {
                                    echo '<span class="no-img">Image 1 Missing</span>';
                                }

                                if (!empty($row['photo2']) && file_exists($p2)) {
                                    echo '<img src="'.$p2.'" class="proof-img-box" onclick="viewImg(this.src)">';
                                } else {
                                    echo '<span class="no-img">Image 2 Missing</span>';
                                }
                                ?>
                            </div>
                        </td>
                        <td><span class="status-badge bg-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Delete record?')"><i class="fa-solid fa-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal for Image Preview -->
<div class="modal fade" id="vModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img src="" id="fullImg" class="img-fluid rounded-4 shadow-lg" style="max-height: 90vh;">
                <div class="mt-2"><button type="button" class="btn btn-light btn-sm rounded-pill" data-bs-dismiss="modal">Close</button></div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function viewImg(s) {
        document.getElementById('fullImg').src = s;
        new bootstrap.Modal(document.getElementById('vModal')).show();
    }
</script>
</body>
</html>