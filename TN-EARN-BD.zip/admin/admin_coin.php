<?php
session_start();

// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. অ্যাডমিন সেটিংস থেকে রেটগুলো লোড করা
$s = [];
$settings_res = $conn->query("SELECT * FROM admin_settings");
while ($row = $settings_res->fetch_assoc()) {
    $s[$row['setting_key']] = $row['setting_value'];
}

// ৩. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    $check = $conn->query("SELECT * FROM coin_sales WHERE id='$id' LIMIT 1");
    if ($check->num_rows > 0) {
        $sale = $check->fetch_assoc();
        $user_id = $sale['user_id'];
        $coin_type = strtolower($sale['coin_type']); // niva, riva etc
        $amount = $sale['amount'];

        if ($action == 'approve' && $sale['status'] == 'pending') {
            // রেট বের করা (যেমন: niva_rate)
            $rate_key = $coin_type . "_rate";
            $current_rate = isset($s[$rate_key]) ? floatval($s[$rate_key]) : 0;
            $total_pay = $amount * $current_rate;

            // ব্যালেন্স আপডেট ও স্ট্যাটাস পরিবর্তন
            $conn->query("UPDATE users SET balance = balance + $total_pay WHERE id='$user_id'");
            $conn->query("UPDATE coin_sales SET status='approved' WHERE id='$id'");
            $msg = "success|রিকোয়েস্ট অ্যাপ্রুভ হয়েছে! ইউজারের ব্যালেন্সে ৳$total_pay যোগ করা হয়েছে।";
        } 
        elseif ($action == 'reject' && $sale['status'] == 'pending') {
            $conn->query("UPDATE coin_sales SET status='rejected' WHERE id='$id'");
            $msg = "warning|রিকোয়েস্ট রিজেক্ট করা হয়েছে।";
        } 
        elseif ($action == 'delete') {
            // ইমেজ ডিলিট করা
            if(!empty($sale['screenshot']) && file_exists("../uploads/coins/".$sale['screenshot'])){
                unlink("../uploads/coins/".$sale['screenshot']);
            }
            $conn->query("DELETE FROM coin_sales WHERE id='$id'");
            $msg = "danger|রিকোয়েস্টটি সম্পূর্ণ ডিলিট করা হয়েছে।";
        }
    }
}

// ৪. সব কয়েন সেল ডেটা ফেচ করা
$query = "SELECT cs.*, u.fullname, u.email 
          FROM coin_sales cs 
          JOIN users u ON cs.user_id = u.id 
          ORDER BY cs.id DESC";
$results = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Coin Sales Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .table thead { background: #1e293b; color: #fff; font-size: 13px; }
        .status-badge { font-size: 10px; padding: 4px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
        .thumb-img { width: 50px; height: 50px; object-fit: cover; border-radius: 8px; cursor: pointer; border: 1px solid #ddd; }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-dark"><i class="fa-solid fa-coins text-warning me-2"></i>Coin Sales Submissions</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): 
        $m = explode('|', $msg);
    ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small py-2"><?= $m[1] ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User</th>
                        <th>Coin Type</th>
                        <th>Amount</th>
                        <th>Sender Username</th>
                        <th>Screenshot</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($results && $results->num_rows > 0): while($row = $results->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= htmlspecialchars($row['fullname']) ?></div>
                            <div class="text-muted" style="font-size: 10px;"><?= $row['email'] ?></div>
                        </td>
                        <td><span class="badge bg-primary rounded-pill"><?= $row['coin_type'] ?></span></td>
                        <td class="fw-bold text-dark"><?= number_format($row['amount']) ?></td>
                        <td><code class="text-primary fw-bold"><?= htmlspecialchars($row['sender_username']) ?></code></td>
                        <td>
                            <img src="../uploads/coins/<?= $row['screenshot'] ?>" class="thumb-img" onclick="showImg(this.src)">
                        </td>
                        <td>
                            <span class="status-badge bg-<?= $row['status'] ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td class="small text-muted"><?= date('d M, y', strtotime($row['created_at'])) ?></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success" title="Approve" onclick="return confirm('ইউজারকে পেমেন্ট করতে চান?')"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Reject"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('এটি ডিলিট করতে চান?')" title="Delete"><i class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="8" class="text-center py-5 text-muted">কোনো কয়েন সেল রিকোয়েস্ট পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- ইমেজ দেখার মডেল -->
<div class="modal fade" id="imgModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-transparent border-0">
      <div class="modal-body text-center p-0">
        <img src="" id="fullImg" style="max-width: 100%; max-height: 90vh; border-radius: 15px; box-shadow: 0 0 30px rgba(0,0,0,0.5);">
        <div class="mt-3 text-white"><button type="button" class="btn btn-light btn-sm rounded-pill px-4" data-bs-dismiss="modal">Close</button></div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function showImg(src) {
        document.getElementById('fullImg').src = src;
        new bootstrap.Modal(document.getElementById('imgModal')).show();
    }
</script>
</body>
</html>