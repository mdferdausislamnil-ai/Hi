<?php
session_start();

// যদি অলরেডি লগইন করা থাকে, ড্যাশবোর্ডে পাঠাও
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header("Location: index.php");
    exit;
}

$msg = "";

// Fixed Admin Gmail & Password
$admin_email = "admin@gmail.com";
$admin_password = "123456"; // চাইলে শক্তিশালী পাসওয়ার্ড দাও

if (isset($_POST['login'])) {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // ডাটাবেস ছাড়া সরাসরি চেক
    if ($email === $admin_email && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = 1;
        $_SESSION['admin_name'] = "Administrator";

        header("Location: index.php");
        exit;
    } else {
        $msg = "Invalid Gmail or Password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Control Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            font-family: 'Outfit', sans-serif;
            background: #0b0f1a;
            background-image: radial-gradient(at 0% 0%, rgba(30, 41, 59, 0.7) 0, transparent 50%), 
                              radial-gradient(at 100% 100%, rgba(15, 23, 42, 1) 0, transparent 50%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .glass-card {
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .input-group input:focus {
            border-color: #3b82f6;
            box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2);
        }

        .login-btn {
            background: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);
            transition: all 0.3s ease;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(59, 130, 246, 0.3);
        }
    </style>
</head>
<body class="p-4">

    <div class="glass-card w-full max-w-md rounded-[2rem] p-8 md:p-10 relative overflow-hidden">
        <!-- Decorative Glow -->
        <div class="absolute -top-24 -right-24 w-48 h-48 bg-blue-600/20 blur-[60px] rounded-full"></div>
        <div class="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-600/20 blur-[60px] rounded-full"></div>

        <div class="relative z-10">
            <!-- Header -->
            <div class="text-center mb-10">
                <div class="w-16 h-16 bg-blue-600/10 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-blue-500/20">
                    <i class="fas fa-user-shield text-3xl text-blue-500"></i>
                </div>
                <h2 class="text-3xl font-bold text-white tracking-tight">Admin Login</h2>
                <p class="text-slate-400 mt-2 text-sm">Enter your credentials to access the panel</p>
            </div>

            <!-- Error Message -->
            <?php if($msg): ?>
                <div class="bg-red-500/10 border border-red-500/20 text-red-400 text-sm py-3 px-4 rounded-xl mb-6 flex items-center gap-3 animate-pulse">
                    <i class="fas fa-circle-exclamation"></i>
                    <?= $msg ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <!-- Email Field -->
                <div class="input-group">
                    <label class="block text-sm font-medium text-slate-300 mb-2 ml-1">Email Address</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-slate-500">
                            <i class="fas fa-envelope"></i>
                        </span>
                        <input type="email" name="email" required
                            class="w-full bg-white/5 border border-white/10 text-white rounded-xl py-3.5 pl-11 pr-4 focus:outline-none transition-all placeholder:text-slate-600"
                            placeholder="admin@gmail.com">
                    </div>
                </div>

                <!-- Password Field -->
                <div class="input-group">
                    <label class="block text-sm font-medium text-slate-300 mb-2 ml-1">Password</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 pl-4 flex items-center text-slate-500">
                            <i class="fas fa-lock"></i>
                        </span>
                        <input type="password" name="password" required
                            class="w-full bg-white/5 border border-white/10 text-white rounded-xl py-3.5 pl-11 pr-4 focus:outline-none transition-all placeholder:text-slate-600"
                            placeholder="••••••••">
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" name="login" class="login-btn w-full text-white font-bold py-4 rounded-xl flex items-center justify-center gap-2 group">
                    <span>Sign In to Dashboard</span>
                    <i class="fas fa-arrow-right text-sm group-hover:translate-x-1 transition-transform"></i>
                </button>
            </form>

            <!-- Footer Note -->
            <div class="mt-8 text-center">
                <a href="../index.php" class="text-slate-500 hover:text-blue-400 text-sm transition-colors">
                    <i class="fas fa-arrow-left mr-1"></i> Back to Home Site
                </a>
            </div>
        </div>
    </div>

</body>
</html>