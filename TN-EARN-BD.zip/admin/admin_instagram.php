<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    // ডেটা চেক করা
    $check = $conn->query("SELECT * FROM instagram_sales WHERE id='$id'");
    if ($check && $check->num_rows > 0) {
        $data = $check->fetch_assoc();
        $user_id = $data['user_id'];
        $rate = $data['rate'];

        if ($action == 'approve' && $data['status'] != 'approved') {
            // ব্যালেন্স আপডেট এবং স্ট্যাটাস পরিবর্তন
            $conn->query("UPDATE users SET balance = balance + $rate WHERE id='$user_id'");
            $conn->query("UPDATE instagram_sales SET status='approved' WHERE id='$id'");
            $msg = "✅ ইনস্টাগ্রাম আইডি অ্যাপ্রুভ হয়েছে এবং টাকা যোগ হয়েছে!";
        } 
        elseif ($action == 'reject') {
            $conn->query("UPDATE instagram_sales SET status='rejected' WHERE id='$id'");
            $msg = "❌ রিকোয়েস্ট রিজেক্ট করা হয়েছে!";
        } 
        elseif ($action == 'delete') {
            $conn->query("DELETE FROM instagram_sales WHERE id='$id'");
            $msg = "🗑️ ডেটা ডিলিট করা হয়েছে!";
        }
    }
}

// ৩. সব ইনস্টাগ্রাম সেল ডেটা ফেচ করা
$query = "SELECT isal.*, u.fullname, u.email 
          FROM instagram_sales isal 
          JOIN users u ON isal.user_id = u.id 
          ORDER BY isal.id DESC";
$results = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Instagram Sales</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .table thead { background: linear-gradient(45deg, #f09433, #bc1888); color: #fff; font-size: 13px; }
        .copy-btn { 
            cursor: pointer; background: #fff5f8; color: #bc1888; 
            border: 1px solid #fed7e2; padding: 2px 8px; border-radius: 6px; 
            font-size: 11px; font-weight: bold; transition: 0.2s;
        }
        .copy-btn:hover { background: #bc1888; color: #fff; }
        .status-badge { font-size: 11px; padding: 4px 10px; border-radius: 50px; font-weight: 700; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-dark"><i class="fa-brands fa-instagram text-danger me-2"></i>Instagram ID Submissions</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): ?>
        <div class="alert alert-success border-0 shadow-sm small py-2"><?= $msg ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User</th>
                        <th>Instagram Username</th>
                        <th>Password</th>
                        <th>2FA Backup Key</th>
                        <th>Rate</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($results && $results->num_rows > 0): while($row = $results->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= htmlspecialchars($row['fullname']) ?></div>
                            <div class="text-muted" style="font-size: 10px;"><?= $row['email'] ?></div>
                        </td>
                        <td>
                            <span id="user_<?= $row['id'] ?>" class="small fw-bold text-primary"><?= htmlspecialchars($row['insta_username']) ?></span>
                            <button class="copy-btn" onclick="copyText('user_<?= $row['id'] ?>')">Copy</button>
                        </td>
                        <td>
                            <span id="pass_<?= $row['id'] ?>" class="small"><?= htmlspecialchars($row['insta_password']) ?></span>
                            <button class="copy-btn" onclick="copyText('pass_<?= $row['id'] ?>')">Copy</button>
                        </td>
                        <td>
                            <?php if($row['two_fa_key']): ?>
                                <span id="fa_<?= $row['id'] ?>" class="d-none"><?= htmlspecialchars($row['two_fa_key']) ?></span>
                                <button class="copy-btn" onclick="copyText('fa_<?= $row['id'] ?>')">Copy 2FA</button>
                            <?php else: ?> - <?php endif; ?>
                        </td>
                        <td class="fw-bold text-dark">৳<?= number_format($row['rate'], 2) ?></td>
                        <td>
                            <span class="status-badge bg-<?= $row['status'] ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success" title="Approve"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Reject"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('এটি ডিলিট করতে চান?')" title="Delete"><i class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">কোনো ইনস্টাগ্রাম আইডি সাবমিট করা হয়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // কপি ফাংশন
    function copyText(id) {
        let text = document.getElementById(id).innerText;
        navigator.clipboard.writeText(text).then(() => {
            // সুন্দর ছোট একটি অ্যালার্ট
            alert("Copied: " + text);
        });
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>