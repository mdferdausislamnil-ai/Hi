<?php
include "../config.php";

// Settings update
if (isset($_POST['update'])) {
    $limit = $_POST['daily_limit'];
    $rate = $_POST['per_gmail_rate'];

    $conn->query("UPDATE admin_settings SET daily_limit='$limit', per_gmail_rate='$rate' WHERE id=1");
    $msg = "Settings updated successfully!";
}

// Fetch current settings
$settings = $conn->query("SELECT * FROM admin_settings LIMIT 1")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Gmail Settings</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #eef2f3, #8e9eab);
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.card {
    background: #ffffffcc;
    backdrop-filter: blur(10px);
    border-radius: 20px;
    padding: 30px 25px;
    max-width: 400px;
    width: 100%;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.card:hover {
    transform: translateY(-5px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.2);
}

.card h2 {
    font-weight: 700;
    font-size: 1.8rem;
    color: #0d6efd;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
}

.card h2 img {
    width: 35px;
}

input {
    width: 100%;
    padding: 12px 15px;
    margin: 10px 0;
    border-radius: 10px;
    border: 1px solid #ccc;
    font-size: 16px;
    transition: border 0.3s ease, box-shadow 0.3s ease;
}

input:focus {
    border-color: #0d6efd;
    box-shadow: 0 0 8px rgba(13,110,253,0.3);
    outline: none;
}

button {
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    font-size: 16px;
    font-weight: 600;
    border: none;
    background: #0d6efd;
    color: white;
    cursor: pointer;
    transition: background 0.3s ease;
}

button:hover {
    background: #0b5ed7;
}

.success {
    color: #28a745;
    font-weight: 600;
    margin-bottom: 15px;
}

.footer {
    margin-top: 15px;
    font-size: 13px;
    color: #555;
}
</style>
</head>
<body>

<div class="card">
    <h2>
        <img src="https://upload.wikimedia.org/wikipedia/commons/4/4e/Gmail_Icon.png" alt="Gmail Icon">
        Gmail Generate Settings
    </h2>

    <?php if(isset($msg)): ?>
        <div class="success"><?= $msg ?></div>
    <?php endif; ?>

    <form method="post">
        <input type="number" name="daily_limit" value="<?= $settings['daily_limit'] ?>" placeholder="Daily Limit (per day)" required>
        <input type="text" name="per_gmail_rate" value="<?= $settings['per_gmail_rate'] ?>" placeholder="Per Gmail Rate ($)" required>
        <button name="update">Update Settings</button>
    </form>

    <div class="footer">
        <p>Developed by <b>Khokon</b></p>
    </div>
</div>

</body>
</html>