<?php
// ১. এরর দেখার জন্য
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// ২. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

// ৩. ডাটাবেস টেবিল এবং কলাম অটো-আপডেট (একদম ফিক্সড সমাধান)
$conn->query("CREATE TABLE IF NOT EXISTS gift_codes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) UNIQUE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    usage_limit INT DEFAULT 1,
    times_used INT DEFAULT 0,
    expiry_date DATETIME NOT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// যদি আগে টেবিল তৈরি করা থাকে কিন্তু 'usage_limit' কলাম না থাকে, তবে তা যোগ করা হবে
$check_column = $conn->query("SHOW COLUMNS FROM gift_codes LIKE 'usage_limit'");
if ($check_column->num_rows == 0) {
    $conn->query("ALTER TABLE gift_codes ADD COLUMN usage_limit INT DEFAULT 1 AFTER amount");
}
$check_times_used = $conn->query("SHOW COLUMNS FROM gift_codes LIKE 'times_used'");
if ($check_times_used->num_rows == 0) {
    $conn->query("ALTER TABLE gift_codes ADD COLUMN times_used INT DEFAULT 0 AFTER usage_limit");
}

$msg_status = "";
$msg_text = "";

// ৪. গিফট কোড তৈরি করার লজিক
if (isset($_POST['create_code'])) {
    $code = strtoupper(trim($conn->real_escape_string($_POST['code'])));
    $amount = floatval($_POST['amount']);
    $limit = intval($_POST['usage_limit']);
    
    $expiry_raw = $_POST['expiry_date'];
    $expiry = str_replace("T", " ", $expiry_raw);

    if(empty($code) || $amount <= 0 || empty($expiry)) {
        $msg_status = "error";
        $msg_text = "সব তথ্য সঠিকভাবে পূরণ করুন!";
    } else {
        // ডুপ্লিকেট চেক
        $check = $conn->query("SELECT id FROM gift_codes WHERE code='$code'");
        
        if ($check && $check->num_rows > 0) {
            $msg_status = "error";
            $msg_text = "এই কোডটি ইতিমধ্যে ডাটাবেসে আছে!";
        } else {
            // ইনসার্ট কুয়েরি
            $sql = "INSERT INTO gift_codes (code, amount, usage_limit, times_used, expiry_date) 
                    VALUES ('$code', '$amount', '$limit', 0, '$expiry')";
            
            if ($conn->query($sql)) {
                $msg_status = "success";
                $msg_text = "নতুন গিফট কোড সফলভাবে তৈরি হয়েছে!";
            } else {
                $msg_status = "error";
                $msg_text = "SQL Error: " . $conn->error;
            }
        }
    }
}

// ৫. ডিলিট লজিক
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    if($conn->query("DELETE FROM gift_codes WHERE id=$id")) {
        $msg_status = "success";
        $msg_text = "গিফট কোডটি ডিলিট করা হয়েছে!";
    }
}

// ৬. লিস্ট ফেচ করা
$codes = $conn->query("SELECT * FROM gift_codes ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Gift Codes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <!-- SweetAlert2 for Popups -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .badge-limit { background: #f1f5f9; color: #334155; border: 1px solid #cbd5e1; padding: 5px 10px; border-radius: 50px; font-size: 11px; font-weight: 700; }
    </style>
</head>
<body class="p-3">

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold"><i class="fa-solid fa-gift text-primary me-2"></i> Gift Code Manager</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <div class="row">
        <!-- কোড তৈরির ফর্ম -->
        <div class="col-md-4 mb-4">
            <div class="card p-4">
                <h6 class="fw-bold border-bottom pb-2 mb-3">Create New Code</h6>
                <form method="POST">
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Gift Code</label>
                        <div class="input-group">
                            <input type="text" name="code" id="gCode" class="form-control" placeholder="BONUS50" required>
                            <button type="button" class="btn btn-outline-secondary" onclick="generateCode()"><i class="fa-solid fa-wand-magic-sparkles"></i></button>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Amount (৳)</label>
                        <input type="number" step="0.01" name="amount" class="form-control" placeholder="50" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">User Limit</label>
                        <input type="number" name="usage_limit" class="form-control" placeholder="100" value="1" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-bold">Expiry Date</label>
                        <input type="datetime-local" name="expiry_date" class="form-control" required>
                    </div>
                    <button type="submit" name="create_code" class="btn btn-primary w-100 fw-bold py-2 rounded-3">Publish Code</button>
                </form>
            </div>
        </div>

        <!-- কোড লিস্ট -->
        <div class="col-md-8">
            <div class="card p-3 overflow-hidden">
                <h6 class="fw-bold border-bottom pb-2 mb-3">Code List</h6>
                <div class="table-responsive">
                    <table class="table table-hover align-middle text-center small">
                        <thead class="table-light">
                            <tr>
                                <th>Code</th>
                                <th>Tk</th>
                                <th>Used</th>
                                <th>Expiry</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($codes && $codes->num_rows > 0): while($row = $codes->fetch_assoc()): 
                                $is_expired = strtotime($row['expiry_date']) < time();
                                $is_full = $row['times_used'] >= $row['usage_limit'];
                                
                                $status_badge = '<span class="badge bg-success">Active</span>';
                                if($is_expired) $status_badge = '<span class="badge bg-danger">Expired</span>';
                                elseif($is_full) $status_badge = '<span class="badge bg-secondary">Full</span>';
                            ?>
                            <tr>
                                <td class="fw-bold text-primary"><?= htmlspecialchars($row['code']) ?></td>
                                <td class="fw-bold">৳<?= number_format($row['amount'], 2) ?></td>
                                <td>
                                    <span class="badge-limit">
                                        <?= $row['times_used'] ?> / <?= $row['usage_limit'] ?>
                                    </span>
                                </td>
                                <td><?= date('d M, h:i A', strtotime($row['expiry_date'])) ?></td>
                                <td><?= $status_badge ?></td>
                                <td>
                                    <a href="?delete=<?= $row['id'] ?>" class="text-danger" onclick="return confirm('নিশ্চিত ডিলিট করতে চান?')"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                            <?php endwhile; else: ?>
                                <tr><td colspan="6" class="text-muted py-3">No codes created yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // সাকসেস বা এরর মেসেজ পপআপ
    <?php if($msg_status != ""): ?>
        Swal.fire({
            icon: '<?= $msg_status ?>',
            title: '<?= $msg_status == "success" ? "সফল হয়েছে!" : "উফফ!" ?>',
            text: '<?= $msg_text ?>',
            timer: 3000,
            showConfirmButton: false
        });
    <?php endif; ?>

    function generateCode() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = '';
        for (let i = 0; i < 6; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        document.getElementById('gCode').value = "GIFT" + result;
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>