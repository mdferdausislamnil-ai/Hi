<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";
$msg = "";

// ১. টাস্ক অ্যাড (ছবি সহ)
if (isset($_POST['add_task'])) {
    $plan_id = intval($_POST['plan_id']);
    $title   = $conn->real_escape_string($_POST['title']);
    $link    = $conn->real_escape_string($_POST['link']);
    $image   = "";

    // ছবি আপলোড
    if (!empty($_FILES['image']['name'])) {
        $upload_dir = "../uploads/tasks/";
        if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $ext     = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];

        if (in_array($ext, $allowed)) {
            $filename = "ptask_" . time() . "_" . rand(1000,9999) . "." . $ext;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_dir . $filename)) {
                $image = $filename;
            } else {
                $msg = "danger|ছবি আপলোড ব্যর্থ হয়েছে!";
            }
        } else {
            $msg = "warning|শুধু JPG, PNG, WEBP অনুমতি আছে!";
        }
    }

    if (empty($msg)) {
        $sql = "INSERT INTO premium_tasks (plan_id, title, link, image) VALUES ('$plan_id','$title','$link','$image')";
        if ($conn->query($sql)) {
            $msg = "success|✅ প্রিমিয়াম টাস্ক সফলভাবে যুক্ত হয়েছে!";
        } else {
            // image কলাম না থাকলে
            $sql2 = "INSERT INTO premium_tasks (plan_id, title, link) VALUES ('$plan_id','$title','$link')";
            if ($conn->query($sql2)) {
                $msg = "success|✅ টাস্ক যুক্ত হয়েছে (ছবি ছাড়া)!";
            } else {
                $msg = "danger|এরর: " . $conn->error;
            }
        }
    }
}

// ২. টাস্ক ডিলিট
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $r = $conn->query("SELECT image FROM premium_tasks WHERE id=$id");
    if ($r && $row = $r->fetch_assoc()) {
        if (!empty($row['image'])) {
            $f = "../uploads/tasks/" . $row['image'];
            if (file_exists($f)) unlink($f);
        }
    }
    $conn->query("DELETE FROM premium_tasks WHERE id=$id");
    header("Location: manage_premium_tasks.php?msg=deleted");
    exit();
}

// ৩. ডেটা লোড
$plans = $conn->query("SELECT * FROM plans ORDER BY price ASC");
$tasks = $conn->query("SELECT pt.*, p.name as plan_name FROM premium_tasks pt 
                       JOIN plans p ON pt.plan_id = p.id 
                       ORDER BY pt.id DESC");
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Premium Tasks | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.06); margin-bottom: 24px; }
        .card-header {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: white; border-bottom: none;
            padding: 15px 22px; font-weight: 700;
            border-radius: 20px 20px 0 0 !important;
        }
        .card-header-list {
            background: #fff; border-bottom: 1px solid #f0f0f0;
            padding: 15px 22px; font-weight: 700;
            border-radius: 20px 20px 0 0 !important;
        }
        .form-control, .form-select {
            border-radius: 12px; padding: 11px 14px;
            border: 1px solid #e2e8f0; font-size: 14px;
        }
        .form-control:focus, .form-select:focus {
            border-color: #f59e0b;
            box-shadow: 0 0 0 4px rgba(245,158,11,0.15);
        }

        /* ছবি আপলোড বক্স */
        .img-upload-box {
            border: 2px dashed #fcd34d;
            border-radius: 16px; padding: 18px;
            text-align: center; background: #fffbeb;
            cursor: pointer; transition: 0.3s; position: relative;
        }
        .img-upload-box:hover { border-color: #f59e0b; background: #fef3c7; }
        .img-upload-box input[type=file] {
            position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%;
        }
        #imgPreview { max-width:100%; max-height:130px; border-radius:10px; display:none; margin:8px auto 0; }

        .btn-gold {
            background: linear-gradient(135deg, #f59e0b, #d97706);
            color: #fff; border: none; border-radius: 12px;
            font-weight: 700; transition: 0.3s;
        }
        .btn-gold:hover { opacity: 0.9; color: #fff; transform: translateY(-2px); }

        /* টেবিল */
        .table thead { background: #1e293b; color: #fff; font-size: 12px; text-transform: uppercase; }
        .table td { vertical-align: middle; padding: 14px; font-size: 14px; }

        .task-thumb {
            width: 52px; height: 52px; object-fit: cover;
            border-radius: 10px; border: 2px solid #fde68a; cursor: pointer;
        }
        .no-thumb {
            width: 52px; height: 52px; border-radius: 10px;
            background: #fef3c7; display: flex; align-items: center;
            justify-content: center; color: #f59e0b; font-size: 20px;
        }
        .action-btn {
            width: 34px; height: 34px; border-radius: 10px;
            display: inline-flex; align-items: center; justify-content: center;
            transition: 0.3s; border: none;
        }
        .btn-link-view { background: #e0e7ff; color: #4338ca; }
        .btn-delete    { background: #fee2e2; color: #b91c1c; }
        .action-btn:hover { transform: scale(1.1); }
    </style>
</head>
<body class="p-3">
<div class="container">

    <!-- হেডার -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold m-0">
            <i class="fa-solid fa-crown text-warning me-2"></i>Premium Task Manager
        </h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">
            <i class="fa-solid fa-house me-1"></i> Dashboard
        </a>
    </div>

    <!-- অ্যালার্ট -->
    <?php
    if (!empty($msg) || isset($_GET['msg'])) {
        if (isset($_GET['msg']) && $_GET['msg'] == 'deleted') $msg = "danger|🗑️ টাস্ক ডিলিট করা হয়েছে!";
        $m = explode('|', $msg);
    ?>
    <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small alert-dismissible fade show">
        <i class="fa-solid fa-circle-info me-2"></i> <?= $m[1] ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php } ?>

    <div class="row">

        <!-- ফর্ম -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <i class="fa-solid fa-plus-circle me-2"></i>Create Premium Task
                </div>
                <div class="card-body p-4">
                    <form method="POST" enctype="multipart/form-data">

                        <div class="mb-3">
                            <label class="form-label small fw-bold">💎 Plan নির্বাচন করুন</label>
                            <select name="plan_id" class="form-select" required>
                                <option value="">-- Plan বেছে নিন --</option>
                                <?php
                                if ($plans && $plans->num_rows > 0):
                                    while ($p = $plans->fetch_assoc()):
                                ?>
                                    <option value="<?= $p['id'] ?>">
                                        <?= htmlspecialchars($p['name']) ?> — ৳<?= $p['price'] ?>
                                    </option>
                                <?php endwhile; else: ?>
                                    <option disabled>কোনো Plan নেই — আগে Plan যোগ করুন</option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">📌 Task Title</label>
                            <input type="text" name="title" class="form-control"
                                placeholder="যেমন: Watch Video / Like Page" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label small fw-bold">🔗 Link / URL</label>
                            <input type="url" name="link" class="form-control" placeholder="https://...">
                        </div>

                        <!-- ছবি আপলোড -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold">🖼️ Task Image (ছবি)</label>
                            <div class="img-upload-box">
                                <input type="file" name="image" id="imageInput" accept="image/*"
                                    onchange="previewImage(this)">
                                <i class="fa-solid fa-cloud-arrow-up fa-2x mb-1" style="color:#f59e0b;"></i>
                                <div class="small text-muted mt-1">ক্লিক করে ছবি বেছে নিন</div>
                                <div class="small text-muted" style="font-size:11px;">JPG, PNG, WEBP</div>
                                <img id="imgPreview" src="" alt="preview">
                            </div>
                        </div>

                        <button type="submit" name="add_task" class="btn btn-gold w-100 py-3">
                            <i class="fa-solid fa-crown me-2"></i>PUBLISH PREMIUM TASK
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- টাস্ক লিস্ট -->
        <div class="col-lg-8">
            <div class="card overflow-hidden">
                <div class="card-header-list d-flex justify-content-between align-items-center">
                    <span class="fw-bold">
                        <i class="fa-solid fa-list text-warning me-2"></i>Active Premium Tasks
                    </span>
                    <span class="badge bg-warning text-dark rounded-pill">
                        <?= ($tasks ? $tasks->num_rows : 0) ?> Total
                    </span>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr class="text-center">
                                <th>Image</th>
                                <th class="text-start">Task Info</th>
                                <th>Plan</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($tasks && $tasks->num_rows > 0): while ($t = $tasks->fetch_assoc()): ?>
                        <tr class="text-center">
                            <td>
                                <?php
                                $img_path = "../uploads/tasks/" . $t['image'];
                                if (!empty($t['image']) && file_exists($img_path)):
                                ?>
                                    <img src="<?= $img_path ?>" class="task-thumb"
                                         onclick="viewImg(this.src)" title="বড় দেখুন">
                                <?php else: ?>
                                    <div class="no-thumb mx-auto">
                                        <i class="fa-solid fa-crown"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="text-start">
                                <div class="fw-bold text-dark"><?= htmlspecialchars($t['title']) ?></div>
                                <?php if (!empty($t['link'])): ?>
                                <div class="small text-muted text-truncate" style="max-width:180px;">
                                    <?= htmlspecialchars($t['link']) ?>
                                </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-warning text-dark rounded-pill">
                                    <?= htmlspecialchars($t['plan_name']) ?>
                                </span>
                            </td>
                            <td>
                                <div class="d-flex gap-2 justify-content-center">
                                    <?php if (!empty($t['link'])): ?>
                                    <a href="<?= htmlspecialchars($t['link']) ?>" target="_blank"
                                       class="action-btn btn-link-view" title="লিঙ্ক দেখুন">
                                        <i class="fa-solid fa-external-link"></i>
                                    </a>
                                    <?php endif; ?>
                                    <a href="?delete=<?= $t['id'] ?>"
                                       class="action-btn btn-delete"
                                       onclick="return confirm('এই টাস্ক ডিলিট করবেন?')">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">
                                <i class="fa-solid fa-crown fa-2x mb-2 d-block text-warning opacity-50"></i>
                                কোনো Premium Task নেই।
                            </td>
                        </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

<!-- ইমেজ মডাল -->
<div class="modal fade" id="vModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img src="" id="fullImg" class="img-fluid rounded-4 shadow-lg" style="max-height:90vh;">
                <div class="mt-3">
                    <button class="btn btn-light btn-sm rounded-pill px-4" data-bs-dismiss="modal">বন্ধ করুন</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function previewImage(input) {
    const preview = document.getElementById('imgPreview');
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(input.files[0]);
    }
}
function viewImg(src) {
    document.getElementById('fullImg').src = src;
    new bootstrap.Modal(document.getElementById('vModal')).show();
}
</script>
</body>
</html>
