<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    // জিমেইল ডেটা চেক
    $check = $conn->query("SELECT * FROM gmail_sales WHERE id='$id' LIMIT 1");
    if ($check->num_rows > 0) {
        $data = $check->fetch_assoc();
        $user_id = $data['user_id'];
        $rate = $data['rate'];

        if ($action == 'approve' && $data['status'] != 'approved') {
            // ব্যালেন্স আপডেট এবং স্ট্যাটাস পরিবর্তন
            $conn->query("UPDATE users SET balance = balance + $rate WHERE id='$user_id'");
            $conn->query("UPDATE gmail_sales SET status='approved' WHERE id='$id'");
            $msg = "success|✅ জিমেইল অ্যাপ্রুভ হয়েছে এবং টাকা যোগ হয়েছে!";
        } 
        elseif ($action == 'reject') {
            $conn->query("UPDATE gmail_sales SET status='rejected' WHERE id='$id'");
            $msg = "warning|❌ রিকোয়েস্ট রিজেক্ট করা হয়েছে!";
        } 
        elseif ($action == 'delete') {
            $conn->query("DELETE FROM gmail_sales WHERE id='$id'");
            $msg = "danger|🗑️ ডেটা ডিলিট করা হয়েছে!";
        }
    }
}

// ৩. সব জিমেইল সেল ডেটা ফেচ করা
$query = "SELECT gs.*, u.fullname, u.email as u_email 
          FROM gmail_sales gs 
          JOIN users u ON gs.user_id = u.id 
          ORDER BY gs.id DESC";
$results = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Gmail Sales Manager</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
        .table thead { background: #ea4335; color: #fff; font-size: 13px; }
        .copy-btn { 
            cursor: pointer; background: #fff5f5; color: #ea4335; 
            border: 1px solid #fab1a0; padding: 2px 8px; border-radius: 6px; 
            font-size: 11px; font-weight: bold; transition: 0.2s;
        }
        .copy-btn:hover { background: #ea4335; color: #fff; }
        .status-badge { font-size: 10px; padding: 4px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-dark"><i class="fa-solid fa-envelope-circle-check text-danger me-2"></i>Gmail Sales Submissions</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): 
        $m = explode('|', $msg);
    ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small py-2"><?= $m[1] ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User Info</th>
                        <th>Gmail Address</th>
                        <th>Password</th>
                        <th>Rate</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($results && $results->num_rows > 0): while($row = $results->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= htmlspecialchars($row['fullname']) ?></div>
                            <div class="text-muted" style="font-size: 10px;"><?= $row['u_email'] ?></div>
                        </td>
                        <td>
                            <span id="gmail_<?= $row['id'] ?>" class="small fw-bold"><?= htmlspecialchars($row['gmail']) ?></span>
                            <button class="copy-btn ms-1" onclick="copyText('gmail_<?= $row['id'] ?>')">Copy</button>
                        </td>
                        <td>
                            <span id="pass_<?= $row['id'] ?>" class="small"><?= htmlspecialchars($row['pass']) ?></span>
                            <button class="copy-btn ms-1" onclick="copyText('pass_<?= $row['id'] ?>')">Copy</button>
                        </td>
                        <td class="fw-bold text-dark">৳<?= number_format($row['rate'], 2) ?></td>
                        <td>
                            <span class="status-badge bg-<?= $row['status'] ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td class="small text-muted"><?= date('d M, y', strtotime($row['created_at'])) ?></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success" title="Approve" onclick="return confirm('টাকা কি ইউজারের ব্যালেন্সে যোগ করবেন?')"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Reject"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('এটি ডিলিট করতে চান?')" title="Delete"><i class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">কোনো জিমেইল সেল রিকোয়েস্ট পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // কপি ফাংশন
    function copyText(id) {
        let text = document.getElementById(id).innerText;
        navigator.clipboard.writeText(text).then(() => {
            alert("Copied: " + text);
        });
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>