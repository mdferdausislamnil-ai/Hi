<?php
session_start();

// ১. সিকিউরিটি চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";
$msg = "";

// হেল্পার ফাংশন ১: জেনারেল সেটিংস আপডেট (admin_settings টেবিল)
function updateSetting($conn, $key, $value) {
    $value = $conn->real_escape_string($value);
    $conn->query("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('$key', '$value') 
                  ON DUPLICATE KEY UPDATE setting_value='$value'");
}

// হেল্পার ফাংশন ২: পেমেন্ট গেটওয়ে সেটিংস আপডেট (payment_gateway টেবিল)
function updateGateway($conn, $key, $value) {
    $value = $conn->real_escape_string($value);
    $conn->query("INSERT INTO payment_gateway (setting_key, setting_value) VALUES ('$key', '$value') 
                  ON DUPLICATE KEY UPDATE setting_value='$value'");
}

// --- ফর্ম সাবমিশন হ্যান্ডলিং ---

// ১. সাইট আইডেন্টিটি ও লোগো আপডেট
if (isset($_POST['update_identity'])) {
    updateSetting($conn, 'site_title', $_POST['site_title']);
    updateSetting($conn, 'site_name', $_POST['site_name']);
    updateSetting($conn, 'site_start_date', $_POST['site_start_date']);
    updateSetting($conn, 'notice_text', $_POST['notice_text']);

    if (!empty($_FILES['site_logo']['name'])) {
        $target = "../uploads/" . time() . "_logo." . pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION);
        if (!is_dir("../uploads")) mkdir("../uploads", 0777, true);
        if(move_uploaded_file($_FILES['site_logo']['tmp_name'], $target)) {
            updateSetting($conn, 'site_logo', $target);
        }
    }
    $msg = "✅ সাইট আইডেন্টিটি আপডেট হয়েছে!";
}

// ২. পেমেন্ট সেটিংস (AXMIR PAY) - নতুন টেবিল payment_gateway ব্যবহার করা হয়েছে
if (isset($_POST['update_activation_payment'])) {
    updateGateway($conn, 'axmirpay_api_key', $_POST['axmirpay_api_key']);
    updateGateway($conn, 'activation_fee', $_POST['activation_fee']);
    $msg = "✅ DEVLOPER KHOKON এর  গেটওয়ে সেটিংস পেমেন্ট টেবলে সেভ হয়েছে!";
}

// ৩. টেলিগ্রাম লিংক আপডেট
if (isset($_POST['update_telegram'])) {
    updateSetting($conn, 'telegram_channel_link', $_POST['telegram_channel_link']);
    updateSetting($conn, 'telegram_group_link', $_POST['telegram_group_link']);
    $msg = "✅ টেলিগ্রাম লিংক আপডেট হয়েছে!";
}

// ৪. সার্ভিস রেট সেটিংস
if (isset($_POST['update_rates'])) {
    $rates = ['gmail_rate', 'fb_rate', 'insta_rate', 'niva_rate', 'top_rate', 'riva_rate', 'ns_rate'];
    foreach($rates as $r) { updateSetting($conn, $r, $_POST[$r]); }
    $msg = "✅ সার্ভিস ইনকাম রেট আপডেট হয়েছে!";
}

// ৫. সার্ভিস পাসওয়ার্ড
if (isset($_POST['update_service_pass'])) {
    updateSetting($conn, 'gmail_sell_pass', $_POST['gmail_sell_pass']);
    updateSetting($conn, 'fb_sell_pass', $_POST['fb_sell_pass']);
    updateSetting($conn, 'insta_sell_pass', $_POST['insta_sell_pass']);
    $msg = "✅ সার্ভিস পাসওয়ার্ড আপডেট হয়েছে!";
}

// ৬. কয়েন সেটিংস
if (isset($_POST['update_coins'])) {
    foreach(['niva', 'top', 'riva', 'ns'] as $ck){
        updateSetting($conn, $ck.'_username', $_POST[$ck.'_username']);
        updateSetting($conn, $ck.'_status', isset($_POST[$ck.'_status']) ? 'active' : 'inactive');
    }
    $msg = "✅ কয়েন সেটিংস আপডেট হয়েছে!";
}

// ৭. টাস্ক সুইচ
if (isset($_POST['update_tasks'])) {
    $task_keys = ['task_microjob_status', 'task_facebook_status', 'task_gmail_status', 'task_instagram_status', 'task_coins_status', 'task_typing_status'];
    foreach($task_keys as $tk){ updateSetting($conn, $tk, isset($_POST[$tk]) ? 'active' : 'inactive'); }
    $msg = "✅ সেকশন স্ট্যাটাস আপডেট হয়েছে!";
}

// ৮. ফিন্যান্সিয়াল সেটিংস
if (isset($_POST['update_finance'])) {
    updateSetting($conn, 'referral_bonus', $_POST['referral_bonus']);
    updateSetting($conn, 'min_withdraw', $_POST['min_withdraw']);
    updateSetting($conn, 'max_withdraw', $_POST['max_withdraw']);
    $msg = "✅ ফিন্যান্সিয়াল লিমিট আপডেট হয়েছে!";
}

// ৯. উইথড্র মেথড যোগ/ডিলিট
if (isset($_POST['add_method'])) {
    $method_name = $conn->real_escape_string($_POST['new_method_name']);
    if (!empty($method_name)) {
        $conn->query("INSERT INTO withdraw_methods (method_name) VALUES ('$method_name')");
        $msg = "✅ নতুন উইথড্র মেথড যুক্ত হয়েছে!";
    }
}
if (isset($_GET['delete_method'])) {
    $id = intval($_GET['delete_method']);
    $conn->query("DELETE FROM withdraw_methods WHERE id=$id");
    header("Location: settings.php?msg=deleted");
    exit;
}

// --- সব ডাটা লোড করা (Array Merging) ---
$s = [];

// ১. admin_settings থেকে ডাটা আনা
$res1 = $conn->query("SELECT * FROM admin_settings");
if($res1){ while ($row = $res1->fetch_assoc()) { $s[$row['setting_key']] = $row['setting_value']; } }

// ২. payment_gateway থেকে ডাটা আনা
$res2 = $conn->query("SELECT * FROM payment_gateway");
if($res2){ while ($row = $res2->fetch_assoc()) { $s[$row['setting_key']] = $row['setting_value']; } }

$methods = $conn->query("SELECT * FROM withdraw_methods");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Master Settings Panel</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
    body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
    .card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
    .card-header { background: #fff; font-weight: 700; border-bottom: 1px solid #f0f0f0; padding: 15px; color: #4f46e5; }
    .btn-save { background: #4f46e5; color: white; border: none; padding: 8px 15px; border-radius: 8px; font-weight: 600; width: 100%; transition: 0.3s; }
    .btn-save:hover { background: #3730a3; }
    .form-label { font-size: 13px; font-weight: 700; color: #475569; margin-bottom: 5px; }
    .section-title { font-size: 16px; font-weight: 800; color: #1e293b; margin-bottom: 15px; border-left: 4px solid #4f46e5; padding-left: 10px; }
</style>
</head>
<body>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold"><i class="fa-solid fa-gears text-primary me-2"></i> মাস্টার সেটিংস প্যানেল</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">ড্যাশবোর্ড</a>
    </div>

    <?php if($msg || isset($_GET['msg'])): ?> 
        <div class="alert alert-success border-0 shadow-sm mb-4">
            <?= ($msg == "" && isset($_GET['msg'])) ? "সফলভাবে ডিলিট হয়েছে!" : $msg ?>
        </div> 
    <?php endif; ?>

    <div class="row">
        
        <!-- ১. সাইট আইডেন্টিটি -->
        <div class="col-md-12">
            <form method="POST" enctype="multipart/form-data">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-globe me-2"></i> সাইট আইডেন্টিটি ও নোটিশ সেটিংস</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-3"><label class="form-label">সাইটের নাম</label><input type="text" name="site_name" value="<?= $s['site_name'] ?? '' ?>" class="form-control"></div>
                            <div class="col-md-4 mb-3"><label class="form-label">সাইটের টাইটেল</label><input type="text" name="site_title" value="<?= $s['site_title'] ?? '' ?>" class="form-control"></div>
                            <div class="col-md-4 mb-3"><label class="form-label">সাইট শুরুর তারিখ</label><input type="datetime-local" name="site_start_date" value="<?= $s['site_start_date'] ?? '' ?>" class="form-control"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">সাইট লোগো আপডেট</label><input type="file" name="site_logo" class="form-control"></div>
                            <div class="col-md-6 mb-3"><label class="form-label">স্ক্রলিং নোটিশ টেক্সট</label><textarea name="notice_text" class="form-control" rows="1"><?= $s['notice_text'] ?? '' ?></textarea></div>
                        </div>
                        <button type="submit" name="update_identity" class="btn-save">আইডেন্টিটি আপডেট করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ২. পেমেন্ট সেটিংস (AXMIR PAY - Table: payment_gateway) -->
        <div class="col-md-6">
            <form method="POST">
                <div class="card">
                    <div class="card-header bg-primary bg-opacity-10 text-primary"><i class="fa-solid fa-bolt me-2"></i> AXMIR PAY অটো পেমেন্ট গেটওয়ে</div>
                    <div class="card-body">
                        <div class="section-title">Gateway Configuration</div>
                        <div class="mb-4">
                            <label class="form-label text-primary">AXMIR PAY API Key</label>
                            <input type="text" name="axmirpay_api_key" value="<?= $s['axmirpay_api_key'] ?? '' ?>" class="form-control" placeholder="Enter API Key from Axmir Pay">
                            <small class="text-muted">এটি সরাসরি `payment_gateway` টেবিলে সেভ হবে।</small>
                        </div>

                        <div class="mb-4 border-top pt-3">
                            <label class="form-label text-danger">অ্যাক্টিভেশন ফি (৳)</label>
                            <input type="number" name="activation_fee" value="<?= $s['activation_fee'] ?? '100' ?>" class="form-control">
                        </div>
                        
                        <button type="submit" name="update_activation_payment" class="btn-save">পেমেন্ট গেটওয়ে সেভ করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৩. টেলিগ্রাম লিংক -->
        <div class="col-md-6">
            <form method="POST">
                <div class="card">
                    <div class="card-header bg-info bg-opacity-10 text-info"><i class="fa-brands fa-telegram me-2"></i> টেলিগ্রাম বাটন লিংক</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Telegram Channel Link</label>
                            <input type="url" name="telegram_channel_link" value="<?= $s['telegram_channel_link'] ?? '' ?>" class="form-control" placeholder="https://t.me/yourchannel">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telegram Group Link</label>
                            <input type="url" name="telegram_group_link" value="<?= $s['telegram_group_link'] ?? '' ?>" class="form-control" placeholder="https://t.me/yourgroup">
                        </div>
                        <button type="submit" name="update_telegram" class="btn-save bg-info">লিংক আপডেট করুন</button>
                    </div>
                </div>
            </form>

            <!-- ফিন্যান্সিয়াল সেটিংস -->
            <form method="POST">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-sack-dollar me-2"></i> বোনাস ও উইথড্র লিমিট</div>
                    <div class="card-body">
                        <div class="mb-3"><label class="form-label">রেফার বোনাস (৳)</label><input type="number" name="referral_bonus" value="<?= $s['referral_bonus'] ?? '0' ?>" class="form-control"></div>
                        <div class="row">
                            <div class="col-6 mb-3"><label class="form-label">মিনিমাম উইথড্র (৳)</label><input type="number" name="min_withdraw" value="<?= $s['min_withdraw'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-6 mb-3"><label class="form-label">ম্যাক্সিমাম উইথড্র (৳)</label><input type="number" name="max_withdraw" value="<?= $s['max_withdraw'] ?? '0' ?>" class="form-control"></div>
                        </div>
                        <button type="submit" name="update_finance" class="btn-save">লিমিট সেভ করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৪. সার্ভিস ইনকাম রেট -->
        <div class="col-md-12">
            <form method="POST">
                <div class="card">
                    <div class="card-header bg-success bg-opacity-10 text-success"><i class="fa-solid fa-tag me-2"></i> সার্ভিস ইনকাম রেট সেটিংস (৳)</div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3 mb-3"><label class="form-label">Gmail Rate</label><input type="number" step="0.01" name="gmail_rate" value="<?= $s['gmail_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">Facebook Rate</label><input type="number" step="0.01" name="fb_rate" value="<?= $s['fb_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">Instagram Rate</label><input type="number" step="0.01" name="insta_rate" value="<?= $s['insta_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">NIVA Coin Rate (Per 1000)</label><input type="number" step="0.01" name="niva_rate" value="<?= $s['niva_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">TOP Coin Rate (Per 1000)</label><input type="number" step="0.01" name="top_rate" value="<?= $s['top_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">RIVA Coin Rate (Per 1000)</label><input type="number" step="0.01" name="riva_rate" value="<?= $s['riva_rate'] ?? '0' ?>" class="form-control"></div>
                            <div class="col-md-3 mb-3"><label class="form-label">NS Coin Rate (Per 1000)</label><input type="number" step="0.01" name="ns_rate" value="<?= $s['ns_rate'] ?? '0' ?>" class="form-control"></div>
                        </div>
                        <button type="submit" name="update_rates" class="btn-save bg-success">ইনকাম রেট সেভ করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৫. সার্ভিস পাসওয়ার্ড -->
        <div class="col-md-6">
            <form method="POST">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-lock me-2"></i> সার্ভিস ডেইলি পাসওয়ার্ড</div>
                    <div class="card-body">
                        <div class="mb-3"><label class="form-label">Gmail Sell Pass</label><input type="text" name="gmail_sell_pass" value="<?= $s['gmail_sell_pass'] ?? '' ?>" class="form-control"></div>
                        <div class="mb-3"><label class="form-label">Facebook Sell Pass</label><input type="text" name="fb_sell_pass" value="<?= $s['fb_sell_pass'] ?? '' ?>" class="form-control"></div>
                        <div class="mb-3"><label class="form-label">Instagram Sell Pass</label><input type="text" name="insta_sell_pass" value="<?= $s['insta_sell_pass'] ?? '' ?>" class="form-control"></div>
                        <button type="submit" name="update_service_pass" class="btn-save">পাসওয়ার্ড সেভ করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৬. কয়েন আইডি ও স্ট্যাটাস -->
        <div class="col-md-6">
            <form method="POST">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-coins me-2"></i> কয়েন সেল ইউজারনেম ও অন/অফ</div>
                    <div class="card-body p-0">
                        <table class="table table-sm table-bordered text-center align-middle mb-0">
                            <thead class="table-light"><tr><th>Coin</th><th>Admin ID</th><th>Switch</th></tr></thead>
                            <tbody>
                                <?php foreach(['niva'=>'NIVA','top'=>'TOP','riva'=>'RIVA','ns'=>'NS'] as $k=>$v): ?>
                                <tr>
                                    <td><b><?= $v ?></b></td>
                                    <td><input type="text" name="<?= $k ?>_username" value="<?= $s[$k.'_username'] ?? '' ?>" class="form-control form-control-sm text-center"></td>
                                    <td>
                                        <div class="form-check form-switch d-flex justify-content-center">
                                            <input class="form-check-input" type="checkbox" name="<?= $k ?>_status" <?= ($s[$k.'_status'] ?? '') == 'active' ? 'checked' : '' ?>>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <div class="p-3"><button type="submit" name="update_coins" class="btn-save">কয়েন সেটিংস আপডেট</button></div>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৭. সেকশন কন্ট্রোল -->
        <div class="col-md-6">
            <form method="POST">
                <div class="card">
                    <div class="card-header"><i class="fa-solid fa-toggle-on me-2"></i> সেকশন অন/অফ কন্ট্রোল</div>
                    <div class="card-body">
                        <?php 
                        $tl = ['task_microjob_status'=>'Microjobs','task_facebook_status'=>'FB Sell','task_gmail_status'=>'Gmail Sell','task_instagram_status'=>'Insta Sell','task_coins_status'=>'Coins Sell','task_typing_status'=>'Typing Job'];
                        foreach($tl as $k=>$v): ?>
                        <div class="d-flex justify-content-between mb-2">
                            <span><?= $v ?></span>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="<?= $k ?>" <?= ($s[$k] ?? '') == 'active' ? 'checked' : '' ?>>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <button type="submit" name="update_tasks" class="btn-save mt-2">স্ট্যাটাস সেভ করুন</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- ৮. উইথড্র মেথড ম্যানেজার -->
        <div class="col-md-6">
            <div class="card">
                <div class="card-header"><i class="fa-solid fa-university me-2"></i> উইথড্র মেথড ম্যানেজার</div>
                <div class="card-body">
                    <form method="POST" class="d-flex gap-2 mb-3">
                        <input type="text" name="new_method_name" class="form-control" placeholder="নতুন মেথড (যেমন: Rocket)" required>
                        <button type="submit" name="add_method" class="btn btn-primary"><i class="fa-solid fa-plus"></i></button>
                    </form>
                    <ul class="list-group">
                        <?php while($m = $methods->fetch_assoc()): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?= htmlspecialchars($m['method_name']) ?>
                            <a href="?delete_method=<?= $m['id'] ?>" class="text-danger" onclick="return confirm('ডিলিট করবেন?')"><i class="fa-solid fa-trash-can"></i></a>
                        </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>