<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header("Location: login.php"); exit; }
include "../config.php";

$msg = "";

// লিঙ্ক আপডেট
if (isset($_POST['update_links'])) {
    foreach (['support_fb', 'support_yt', 'support_tg_ch', 'support_tg_gp'] as $key) {
        $val = $conn->real_escape_string($_POST[$key]);
        $conn->query("INSERT INTO admin_settings (setting_key, setting_value) VALUES ('$key', '$val') ON DUPLICATE KEY UPDATE setting_value='$val'");
    }
    $msg = "লিঙ্কগুলো আপডেট হয়েছে!";
}

// ভিডিও অ্যাড
if (isset($_POST['add_video'])) {
    $title = $conn->real_escape_string($_POST['video_title']);
    $vid = $conn->real_escape_string($_POST['video_id']);
    $conn->query("INSERT INTO support_videos (video_title, video_id) VALUES ('$title', '$vid')");
    $msg = "নতুন ভিডিও যুক্ত হয়েছে!";
}

// ভিডিও ডিলিট
if (isset($_GET['delete_vid'])) {
    $id = intval($_GET['delete_vid']);
    $conn->query("DELETE FROM support_videos WHERE id=$id");
    header("Location: admin_support.php");
}

$s = [];
$res = $conn->query("SELECT * FROM admin_settings");
while ($row = $res->fetch_assoc()) { $s[$row['setting_key']] = $row['setting_value']; }
$videos = $conn->query("SELECT * FROM support_videos ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: sans-serif; }
        .card { border: none; border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .form-label { font-size: 13px; font-weight: bold; margin-bottom: 4px; }
    </style>
</head>
<body class="p-3">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold m-0">Support Manager</h6>
        <a href="index.php" class="btn btn-sm btn-dark">Back</a>
    </div>

    <?php if($msg): ?> <div class="alert alert-success p-2 small"><?= $msg ?></div> <?php endif; ?>

    <!-- সোশ্যাল লিঙ্ক ফর্ম -->
    <div class="card p-3">
        <form method="POST">
            <div class="row g-2">
                <div class="col-6"><label class="form-label">Facebook</label><input type="url" name="support_fb" value="<?= $s['support_fb'] ?? '' ?>" class="form-control form-control-sm"></div>
                <div class="col-6"><label class="form-label">Telegram Channel</label><input type="url" name="support_tg_ch" value="<?= $s['support_tg_ch'] ?? '' ?>" class="form-control form-control-sm"></div>
                <div class="col-6"><label class="form-label">Telegram Group</label><input type="url" name="support_tg_gp" value="<?= $s['support_tg_gp'] ?? '' ?>" class="form-control form-control-sm"></div>
                <div class="col-6"><label class="form-label">YouTube</label><input type="url" name="support_yt" value="<?= $s['support_yt'] ?? '' ?>" class="form-control form-control-sm"></div>
            </div>
            <button type="submit" name="update_links" class="btn btn-primary btn-sm w-100 mt-3 fw-bold">Update Social Links</button>
        </form>
    </div>

    <!-- ভিডিও অ্যাড ফর্ম -->
    <div class="card p-3">
        <form method="POST">
            <label class="form-label">Video Title</label>
            <input type="text" name="video_title" class="form-control form-control-sm mb-2" placeholder="কিভাবে একাউন্ট খুলবেন" required>
            <label class="form-label">YouTube Video ID</label>
            <input type="text" name="video_id" class="form-control form-control-sm mb-3" placeholder="dQw4w9WgXcQ" required>
            <button type="submit" name="add_video" class="btn btn-success btn-sm w-100 fw-bold">Add Video Tutorial</button>
        </form>
    </div>

    <!-- ভিডিও লিস্ট -->
    <div class="card p-3">
        <h6 class="small fw-bold border-bottom pb-2">Added Videos</h6>
        <?php while($v = $videos->fetch_assoc()): ?>
            <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                <span class="small"><?= $v['video_title'] ?></span>
                <a href="?delete_vid=<?= $v['id'] ?>" class="text-danger" onclick="return confirm('ডিলিট করবেন?')"><i class="fa-solid fa-trash-can"></i></a>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>