<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    $check = $conn->query("SELECT * FROM withdraws WHERE id='$id' LIMIT 1");
    if ($check->num_rows > 0) {
        $data = $check->fetch_assoc();
        $user_id = $data['user_id'];
        $amount = $data['amount'];

        if ($action == 'approve' && $data['status'] == 'pending') {
            $conn->query("UPDATE withdraws SET status='approved' WHERE id='$id'");
            $msg = "success|✅ উইথড্রাল রিকোয়েস্ট সফলভাবে অ্যাপ্রুভ করা হয়েছে!";
        } 
        elseif ($action == 'reject' && $data['status'] == 'pending') {
            // রিজেক্ট করলে টাকা ফেরত দেওয়া
            $conn->query("UPDATE users SET balance = balance + $amount WHERE id='$user_id'");
            $conn->query("UPDATE withdraws SET status='rejected' WHERE id='$id'");
            $msg = "warning|❌ রিকোয়েস্ট রিজেক্ট করা হয়েছে এবং টাকা ইউজারের ব্যালেন্সে ফেরত দেওয়া হয়েছে।";
        } 
        elseif ($action == 'delete') {
            $conn->query("DELETE FROM withdraws WHERE id='$id'");
            $msg = "danger|🗑️ উইথড্র রেকর্ড ডিলিট করা হয়েছে!";
        }
    }
}

// ৩. উইথড্র ডেটা ফেচ করা
$withdraws = $conn->query("SELECT w.*, u.fullname, u.email 
                           FROM withdraws w 
                           JOIN users u ON w.user_id = u.id 
                           ORDER BY w.id DESC");

// সাইট নাম আনা
$s_res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='site_name'");
$site_name = ($s_res && $s_res->num_rows > 0) ? $s_res->fetch_assoc()['setting_value'] : "Admin Panel";
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Withdraws | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; padding-bottom: 60px; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .table thead { background: #1e293b; color: #fff; font-size: 13px; }
        .status-badge { font-size: 10px; padding: 5px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
        
        /* Footer Style */
        .admin-footer {
            background: #fff; text-align: center; padding: 15px; 
            border-top: 1px solid #e2e8f0; position: fixed; 
            bottom: 0; left: 0; right: 0; z-index: 100;
        }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-dark"><i class="fa-solid fa-money-bill-transfer text-success me-2"></i>Withdraw Requests</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): 
        $m = explode('|', $msg);
    ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small py-2"><?= $m[1] ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User Info</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Account Number</th>
                        <th>Status</th>
                        <th>Request Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($withdraws->num_rows > 0): while($row = $withdraws->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= htmlspecialchars($row['fullname']) ?></div>
                            <div class="text-muted" style="font-size: 10px;"><?= $row['email'] ?></div>
                        </td>
                        <td class="fw-bold text-primary">৳<?= number_format($row['amount'], 2) ?></td>
                        <td><span class="badge bg-secondary rounded-pill small"><?= $row['method'] ?></span></td>
                        <td><code class="text-dark fw-bold" style="font-size: 14px;"><?= htmlspecialchars($row['number']) ?></code></td>
                        <td>
                            <span class="status-badge bg-<?= $row['status'] ?>">
                                <?= $row['status'] ?>
                            </span>
                        </td>
                        <td class="small text-muted"><?= date('d M, h:i A', strtotime($row['created_at'])) ?></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success" onclick="return confirm('পেমেন্ট কি সফল হয়েছে?')" title="Approve"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" onclick="return confirm('রিজেক্ট করলে টাকা ইউজারের ব্যালেন্সে ফেরত যাবে। নিশ্চিত তো?')" title="Reject"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('রেকর্ডটি ডিলিট করতে চান?')" title="Delete"><i class="fa-solid fa-trash-can"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">কোনো উইথড্র রিকোয়েস্ট পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<footer class="admin-footer">
    <p class="mb-0 small fw-bold text-muted">
        © 2026 <strong><?= htmlspecialchars($site_name) ?></strong> | Developed by <span class="text-primary">DEVE SAHABI</span>
    </p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>