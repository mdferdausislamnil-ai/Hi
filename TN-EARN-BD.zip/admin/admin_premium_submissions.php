<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

$msg = "";

// ২. ডাটাবেস টেবিল চেক এবং তৈরি (যদি না থাকে)
$tableCheck = "CREATE TABLE IF NOT EXISTS premium_task_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    task_id INT NOT NULL,
    proof_text TEXT NULL,
    proof_img VARCHAR(255) NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($tableCheck);

// ৩. অ্যাকশন হ্যান্ডলার (Approve / Reject / Delete)
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action'];

    // সাবমিশন ডাটা এবং ওই প্ল্যানের টাস্ক রেট বের করা
    $query = $conn->query("SELECT s.*, p.task_rate, s.user_id 
                           FROM premium_task_submissions s 
                           JOIN premium_tasks t ON s.task_id = t.id 
                           JOIN plans p ON t.plan_id = p.id 
                           WHERE s.id = '$id'");
    
    if ($query->num_rows > 0) {
        $data = $query->fetch_assoc();
        $user_id = $data['user_id'];
        $reward = floatval($data['task_rate']);

        if ($action == 'approve' && $data['status'] == 'pending') {
            // ব্যালেন্স যোগ করা
            $conn->query("UPDATE users SET balance = balance + $reward WHERE id = '$user_id'");
            // স্ট্যাটাস আপডেট
            $conn->query("UPDATE premium_task_submissions SET status = 'approved' WHERE id = '$id'");
            $msg = "success|✅ টাস্ক অ্যাপ্রুভ হয়েছে এবং ৳$reward যোগ হয়েছে।";
        } 
        elseif ($action == 'reject' && $data['status'] == 'pending') {
            $conn->query("UPDATE premium_task_submissions SET status = 'rejected' WHERE id = '$id'");
            $msg = "warning|❌ টাস্কটি রিজেক্ট করা হয়েছে।";
        } 
        elseif ($action == 'delete') {
            // ইমেজ থাকলে ডিলিট করা
            if(!empty($data['proof_img']) && file_exists("../uploads/tasks/" . $data['proof_img'])){
                unlink("../uploads/tasks/" . $data['proof_img']);
            }
            $conn->query("DELETE FROM premium_task_submissions WHERE id = '$id'");
            $msg = "danger|🗑️ রেকর্ড ডিলিট করা হয়েছে।";
        }
    }
}

// ৪. পেন্ডিং সাবমিশনগুলো প্রথমে দেখাবে
$submissions = $conn->query("SELECT s.*, u.fullname, u.email, t.title, p.name as plan_name, p.task_rate 
                             FROM premium_task_submissions s 
                             JOIN users u ON s.user_id = u.id 
                             JOIN premium_tasks t ON s.task_id = t.id 
                             JOIN plans p ON t.plan_id = p.id 
                             ORDER BY s.id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Task Submissions</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .table thead { background: #1e293b; color: #fff; font-size: 13px; }
        .status-badge { font-size: 10px; padding: 4px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .bg-pending { background: #fef3c7; color: #92400e; }
        .bg-approved { background: #dcfce7; color: #166534; }
        .bg-rejected { background: #fee2e2; color: #991b1b; }
        
        .proof-img-box {
            width: 50px; height: 50px; object-fit: cover; 
            border-radius: 8px; border: 1px solid #ddd; cursor: pointer;
        }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold"><i class="fa-solid fa-crown text-warning me-2"></i>Premium Task Proofs</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <?php if($msg): $m = explode('|', $msg); ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small py-2"><?= $m[1] ?></div>
    <?php endif; ?>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>User</th>
                        <th>Task / Plan</th>
                        <th>Proof (Image/Text)</th>
                        <th>Rate</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($submissions->num_rows > 0): while($row = $submissions->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td class="text-start">
                            <div class="fw-bold small"><?= $row['fullname'] ?></div>
                            <div class="text-muted small" style="font-size: 10px;"><?= $row['email'] ?></div>
                        </td>
                        <td class="text-start">
                            <span class="badge bg-info text-dark mb-1"><?= $row['plan_name'] ?></span>
                            <div class="small text-muted text-truncate" style="max-width: 150px;"><?= $row['title'] ?></div>
                        </td>
                        <td>
                            <?php if(!empty($row['proof_img'])): ?>
                                <img src="../uploads/tasks/<?= $row['proof_img'] ?>" class="proof-img-box" onclick="viewImg(this.src)">
                            <?php else: ?>
                                <button type="button" class="btn btn-sm btn-light border" onclick="alert('Proof Text: <?= $row['proof_text'] ?>')">
                                    <i class="fa-solid fa-file-lines"></i> View Text
                                </button>
                            <?php endif; ?>
                        </td>
                        <td class="fw-bold text-success">৳<?= number_format($row['task_rate'], 2) ?></td>
                        <td><span class="status-badge bg-<?= $row['status'] ?>"><?= $row['status'] ?></span></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center">
                                <?php if($row['status'] == 'pending'): ?>
                                    <a href="?action=approve&id=<?= $row['id'] ?>" class="btn btn-sm btn-success" title="Approve"><i class="fa-solid fa-check"></i></a>
                                    <a href="?action=reject&id=<?= $row['id'] ?>" class="btn btn-sm btn-warning" title="Reject"><i class="fa-solid fa-xmark"></i></a>
                                <?php endif; ?>
                                <a href="?action=delete&id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-danger border-0" onclick="return confirm('Delete record?')"><i class="fa-solid fa-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="6" class="text-center py-5 text-muted">কোনো প্রিমিয়াম টাস্ক সাবমিশন পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal for Image Preview -->
<div class="modal fade" id="vModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-transparent border-0">
            <div class="modal-body p-0 text-center">
                <img src="" id="fullImg" class="img-fluid rounded-4 shadow-lg" style="max-height: 90vh;">
                <div class="mt-2"><button type="button" class="btn btn-light btn-sm rounded-pill" data-bs-dismiss="modal">Close</button></div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function viewImg(s) {
        document.getElementById('fullImg').src = s;
        new bootstrap.Modal(document.getElementById('vModal')).show();
    }
</script>
</body>
</html>