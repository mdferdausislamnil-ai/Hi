<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";
$msg = "";

// ২. ইউজার ডিলিট হ্যান্ডলার
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id");
    $msg = "success|ইউজার সফলভাবে ডিলিট করা হয়েছে!";
}

// ৩. ইউজার আপডেট হ্যান্ডলার (Modal Form Submission)
if (isset($_POST['update_user'])) {
    $id = intval($_POST['user_id']);
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $balance = floatval($_POST['balance']);
    $status = $_POST['status'];
    $role = $_POST['role'];

    // পাসওয়ার্ড পরিবর্তন লজিক
    $pass_update = "";
    if (!empty($_POST['password'])) {
        $new_pass = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $pass_update = ", password='$new_pass'";
    }

    // প্রোফাইল পিকচার আপলোড
    $pic_update = "";
    if (!empty($_FILES['profile_pic']['name'])) {
        $targetDir = "../Uploads/profile/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $fileName = "user_" . $id . "_" . time() . "." . pathinfo($_FILES['profile_pic']['name'], PATHINFO_EXTENSION);
        if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $targetDir . $fileName)) {
            $pic_path = "Uploads/profile/" . $fileName;
            $pic_update = ", profile_pic='$pic_path'";
        }
    }

    $sql = "UPDATE users SET fullname='$fullname', email='$email', balance='$balance', status='$status', role='$role' $pass_update $pic_update WHERE id=$id";
    
    if ($conn->query($sql)) {
        $msg = "success|ইউজারের তথ্য সফলভাবে আপডেট করা হয়েছে!";
    } else {
        $msg = "danger|এরর: " . $conn->error;
    }
}

// ৪. ইউজার সার্চ এবং ফিল্টার
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : "";
$where = $search ? "WHERE fullname LIKE '%$search%' OR email LIKE '%$search%' OR id='$search'" : "";

$users = $conn->query("SELECT * FROM users $where ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .user-img { width: 45px; height: 45px; border-radius: 50%; object-fit: cover; border: 2px solid #e2e8f0; }
        .status-badge { font-size: 11px; padding: 4px 10px; border-radius: 50px; font-weight: 700; text-transform: uppercase; }
        .bg-active { background: #dcfce7; color: #166534; }
        .bg-inactive { background: #fee2e2; color: #991b1b; }
        .table td { vertical-align: middle; padding: 12px; }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <!-- Top Header -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <h4 class="fw-bold text-dark m-0"><i class="fa-solid fa-users-gear text-primary me-2"></i>User Management</h4>
        <div class="d-flex gap-2">
            <form action="" method="GET" class="d-flex gap-1">
                <input type="text" name="search" class="form-control form-control-sm rounded-pill px-3" placeholder="ID, Name or Email" value="<?= $search ?>">
                <button type="submit" class="btn btn-primary btn-sm rounded-pill px-3"><i class="fa-solid fa-search"></i></button>
            </form>
            <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-3">Dashboard</a>
        </div>
    </div>

    <?php if($msg): 
        $m = explode('|', $msg);
    ?>
        <div class="alert alert-<?= $m[0] ?> border-0 shadow-sm small alert-dismissible fade show" role="alert">
            <?= $m[1] ?> <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- User Table -->
    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Email</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Role</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($users->num_rows > 0): while($u = $users->fetch_assoc()): ?>
                    <tr>
                        <td class="fw-bold">#<?= $u['id'] ?></td>
                        <td>
                            <div class="d-flex align-items-center">
                                <img src="../<?= $u['profile_pic'] ?: 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png' ?>" class="user-img me-2">
                                <div class="fw-bold small"><?= htmlspecialchars($u['fullname']) ?></div>
                            </div>
                        </td>
                        <td class="small"><?= $u['email'] ?></td>
                        <td class="fw-bold text-success">৳<?= number_format($u['balance'], 2) ?></td>
                        <td>
                            <span class="status-badge bg-<?= $u['status'] ?>">
                                <?= $u['status'] ?>
                            </span>
                        </td>
                        <td><span class="badge bg-secondary small"><?= strtoupper($u['role']) ?></span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick='editUser(<?= json_encode($u) ?>)'><i class="fa-solid fa-edit"></i> Edit</button>
                            <a href="?delete=<?= $u['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('আপনি কি নিশ্চিত যে এই ইউজারকে ডিলিট করবেন?')"><i class="fa-solid fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">কোনো ইউজার পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit User Modal -->
<div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">Edit User Details</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body p-4">
                    <input type="hidden" name="user_id" id="edit_id">
                    
                    <div class="row">
                        <div class="col-md-12 mb-3">
                            <label class="form-label small fw-bold">Full Name</label>
                            <input type="text" name="fullname" id="edit_name" class="form-control" required>
                        </div>
                        <div class="col-md-12 mb-3">
                            <label class="form-label small fw-bold">Email Address</label>
                            <input type="email" name="email" id="edit_email" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-success">Current Balance (৳)</label>
                            <input type="number" step="0.01" name="balance" id="edit_balance" class="form-control fw-bold border-success">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Change Password</label>
                            <input type="text" name="password" class="form-control" placeholder="নতুন পাসওয়ার্ড দিন">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Status</label>
                            <select name="status" id="edit_status" class="form-select">
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold">Role</label>
                            <select name="role" id="edit_role" class="form-select">
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                            </select>
                        </div>
                        <div class="col-md-12 mb-2">
                            <label class="form-label small fw-bold">Update Profile Picture</label>
                            <input type="file" name="profile_pic" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-0 p-4 pt-0">
                    <button type="submit" name="update_user" class="btn btn-primary w-100 py-2 fw-bold">SAVE ALL CHANGES</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function editUser(user) {
        document.getElementById('edit_id').value = user.id;
        document.getElementById('edit_name').value = user.fullname;
        document.getElementById('edit_email').value = user.email;
        document.getElementById('edit_balance').value = user.balance;
        document.getElementById('edit_status').value = user.status;
        document.getElementById('edit_role').value = user.role;
        
        var editModal = new bootstrap.Modal(document.getElementById('editModal'));
        editModal.show();
    }
</script>
</body>
</html>