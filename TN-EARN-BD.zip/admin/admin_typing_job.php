<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
include "../config.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $total = intval($_POST['total_lines']);
    $rate = floatval($_POST['rate_per_line']);
    $conn->query("UPDATE typing_job_settings SET total_lines='$total', rate_per_line='$rate' WHERE id=1");
    echo "<script>alert('Updated Successfully');</script>";
}
$data = $conn->query("SELECT * FROM typing_job_settings WHERE id=1")->fetch_assoc();
?>
<!-- এরপর HTML -->
<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Typing Job Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:#0b001f;color:white;font-family:Poppins;}
.container{max-width:500px;margin-top:80px;background:#1a003d;padding:30px;border-radius:10px;box-shadow:0 0 10px #5000ff;}
input{margin-bottom:15px;}
button{width:100%;}
</style>
</head>
<body>
<div class="container">
<h3 class="text-center mb-4">⚙️ Typing Job Settings</h3>
<form method="POST">
  <label>👉 Total Lines:</label>
  <input type="number" name="total_lines" class="form-control" value="<?= $data['total_lines'] ?>" required>
  <label>💰 Rate Per Line (৳):</label>
  <input type="text" name="rate_per_line" class="form-control" value="<?= $data['rate_per_line'] ?>" required>
  <button class="btn btn-primary mt-3">Update</button>
</form>
</div>
</body>
</html>