<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit;
}

include "../config.php";

function getCount($conn, $table, $condition = "") {
    try {
        $check = $conn->query("SHOW TABLES LIKE '$table'");
        if ($check->num_rows > 0) {
            $sql = "SELECT COUNT(*) as total FROM $table $condition";
            $res = $conn->query($sql);
            if ($res) return $res->fetch_assoc()['total'];
        }
        return 0;
    } catch (Exception $e) {
        return 0;
    }
}

$stats = [
    'users'     => getCount($conn, "users"),
    'withdraw'  => getCount($conn, "withdraws", "WHERE status='pending'"),
    'jobs'      => getCount($conn, "user_tasks", "WHERE status='pending'"),
    'v_jobs'    => getCount($conn, "visiting_jobs"),
    'gmail'     => getCount($conn, "gmail_sales", "WHERE status='pending'"),
    'facebook'  => getCount($conn, "facebook_sales", "WHERE status='pending'"),
    'instagram' => getCount($conn, "instagram_sales", "WHERE status='pending'"),
    'coins'     => getCount($conn, "coin_sales", "WHERE status='pending'"),
    'gift'      => getCount($conn, "gift_code_requests", "WHERE status='pending'"),
    'premium'   => getCount($conn, "premium_tasks"),
    'regular'   => getCount($conn, "tasks"),
    'typing'    => getCount($conn, "typing_jobs"),
    'plans'     => getCount($conn, "plans"),
];

$site_name = "ADMIN PANEL";
$query = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='site_name'");
if ($query && $query->num_rows > 0) {
    $site_name = $query->fetch_assoc()['setting_value'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($site_name) ?> - Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { background:#f1f5f9; font-family:sans-serif; }

/* NAVBAR */
.navbar { background:#ffffff; padding:15px; box-shadow:0 2px 10px rgba(0,0,0,0.05); }
.navbar-brand { font-weight:bold; font-size:22px; }

/* SIDEBAR */
.offcanvas { background:#071739; width:260px !important; color:white; }
.sidebar-title {
    padding:25px 20px;
    font-size:26px;
    font-weight:bold;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,0.1);
}

.nav-link-custom {
    display:flex;
    align-items:center;
    gap:12px;
    padding:13px 20px;
    color:#dbeafe;
    text-decoration:none;
    transition:0.3s;
    font-size:15px;
}
.nav-link-custom i { width:22px; text-align:center; }
.nav-link-custom:hover { background:#1e3a8a; color:white; padding-left:28px; }

/* Job links - golden */
.nav-link-job {
    display:flex;
    align-items:center;
    gap:12px;
    padding:13px 20px;
    color:#fde68a;
    text-decoration:none;
    transition:0.3s;
    font-size:15px;
}
.nav-link-job i { width:22px; text-align:center; }
.nav-link-job:hover { background:#2d1f00; color:#f7c94f; padding-left:28px; }

.menu-title {
    color:#94a3b8;
    font-size:11px;
    padding:16px 20px 6px;
    text-transform:uppercase;
    letter-spacing:1.5px;
    font-weight:700;
}

.menu-title-job {
    color:#f7c94f;
    font-size:11px;
    padding:16px 20px 6px;
    text-transform:uppercase;
    letter-spacing:1.5px;
    font-weight:700;
    border-top:1px solid rgba(255,255,255,0.07);
    margin-top:6px;
}

/* CARDS */
.dashboard-card {
    background:white;
    border-radius:20px;
    padding:20px;
    position:relative;
    overflow:hidden;
    box-shadow:0 5px 15px rgba(0,0,0,0.05);
    transition:0.3s;
    height:100%;
}
.dashboard-card:hover { transform:translateY(-5px); }
.icon-box {
    width:60px; height:60px;
    border-radius:15px;
    display:flex; align-items:center; justify-content:center;
    font-size:24px; margin-bottom:15px;
}
.card-number { font-size:32px; font-weight:bold; }
.card-title { color:#64748b; font-size:15px; }

.bg-blue    { background:#dbeafe; color:#2563eb; }
.bg-green   { background:#dcfce7; color:#16a34a; }
.bg-red     { background:#fee2e2; color:#dc2626; }
.bg-yellow  { background:#fef9c3; color:#ca8a04; }
.bg-purple  { background:#f3e8ff; color:#9333ea; }
.bg-pink    { background:#fce7f3; color:#db2777; }
.bg-orange  { background:#ffedd5; color:#ea580c; }
.bg-gold    { background:#fff8e1; color:#f59e0b; }
.bg-teal    { background:#ccfbf1; color:#0d9488; }
.bg-indigo  { background:#e0e7ff; color:#4338ca; }
.bg-cyan    { background:#cffafe; color:#0891b2; }

@media(max-width:768px){
    .offcanvas { width:230px !important; }
    .navbar-brand { font-size:18px; }
    .nav-link-custom, .nav-link-job { font-size:14px; padding:11px 15px; }
    .dashboard-card { padding:15px; border-radius:16px; }
    .card-number { font-size:24px; }
    .card-title { font-size:13px; }
}
</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar sticky-top">
<div class="container-fluid">
<button class="btn btn-dark" data-bs-toggle="offcanvas" data-bs-target="#sidebar">
    <i class="fa-solid fa-bars"></i>
</button>
<span class="navbar-brand"><?= htmlspecialchars($site_name) ?></span>
</div>
</nav>

<!-- SIDEBAR -->
<div class="offcanvas offcanvas-start" tabindex="-1" id="sidebar">
<div class="sidebar-title">ADMIN PANEL</div>
<div class="offcanvas-body p-0">

    <!-- MAIN MENU -->
    <div class="menu-title">Main Menu</div>

    <a href="index.php" class="nav-link-custom">
        <i class="fa-solid fa-house"></i> Dashboard
    </a>
    <a href="users.php" class="nav-link-custom">
        <i class="fa-solid fa-users"></i> Users
    </a>
    <a href="admin_withdraw.php" class="nav-link-custom">
        <i class="fa-solid fa-wallet"></i> Withdraw Requests
    </a>
    <a href="admin_gift_codes.php" class="nav-link-custom">
        <i class="fa-solid fa-gift"></i> Gift Code Requests
    </a>
    <a href="admin_coin.php" class="nav-link-custom">
        <i class="fa-solid fa-coins"></i> Coins Sell Requests
    </a>

    <!-- SELL SERVICES -->
    <div class="menu-title">Sell Services</div>

    <a href="admin_gmail.php" class="nav-link-custom">
        <i class="fa-solid fa-envelope"></i> Gmail Sell
    </a>
    <a href="admin_facebook.php" class="nav-link-custom">
        <i class="fa-brands fa-facebook"></i> Facebook Sell
    </a>
    <a href="admin_instagram.php" class="nav-link-custom">
        <i class="fa-brands fa-instagram"></i> Instagram Sell
    </a>
    <a href="admin_user_tasks.php" class="nav-link-custom">
        <i class="fa-solid fa-file-alt"></i> Job Submissions
    </a>

    <!-- JOB MANAGEMENT -->
    <div class="menu-title-job">⭐ Job Management</div>

    <a href="manage_plans.php" class="nav-link-job">
        <i class="fa-solid fa-layer-group"></i> Manage Plans
    </a>
    <a href="manage_premium_tasks.php" class="nav-link-job">
        <i class="fa-solid fa-crown"></i> Premium Jobs
    </a>
    <a href="admin_tasks.php" class="nav-link-job">
        <i class="fa-solid fa-briefcase"></i> My Job (Regular)
    </a>
    <a href="admin_typing_job.php" class="nav-link-job">
        <i class="fa-solid fa-keyboard"></i> Typing Job
    </a>
    <a href="vsadd.php" class="nav-link-job">
        <i class="fa-solid fa-globe"></i> Visiting Jobs
    </a>
    <a href="admin_user_tasks.php" class="nav-link-job">
        <i class="fa-solid fa-history"></i> My Job History
    </a>

    <!-- SYSTEM -->
    <div class="menu-title">System</div>

    <a href="settings.php" class="nav-link-custom">
        <i class="fa-solid fa-gear"></i> Settings
    </a>
    <a href="logout.php" class="nav-link-custom text-danger">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>

</div>
</div>

<!-- DASHBOARD CARDS -->
<div class="container py-4">
<div class="row g-3">

    <div class="col-6">
        <a href="users.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-blue"><i class="fa-solid fa-users"></i></div>
            <div class="card-number"><?= $stats['users'] ?></div>
            <div class="card-title">Total Users</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_withdraw.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-green"><i class="fa-solid fa-wallet"></i></div>
            <div class="card-number"><?= $stats['withdraw'] ?></div>
            <div class="card-title">Withdraw Pending</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_user_tasks.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-yellow"><i class="fa-solid fa-briefcase"></i></div>
            <div class="card-number"><?= $stats['jobs'] ?></div>
            <div class="card-title">Job Submit</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="vsadd.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-purple"><i class="fa-solid fa-globe"></i></div>
            <div class="card-number"><?= $stats['v_jobs'] ?></div>
            <div class="card-title">Visiting Jobs</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_gmail.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-red"><i class="fa-solid fa-envelope"></i></div>
            <div class="card-number"><?= $stats['gmail'] ?></div>
            <div class="card-title">Gmail Requests</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_facebook.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-blue"><i class="fa-brands fa-facebook"></i></div>
            <div class="card-number"><?= $stats['facebook'] ?></div>
            <div class="card-title">Facebook Requests</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_instagram.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-pink"><i class="fa-brands fa-instagram"></i></div>
            <div class="card-number"><?= $stats['instagram'] ?></div>
            <div class="card-title">Instagram Requests</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_coin.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-orange"><i class="fa-solid fa-coins"></i></div>
            <div class="card-number"><?= $stats['coins'] ?></div>
            <div class="card-title">Coins Requests</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="manage_plans.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-cyan"><i class="fa-solid fa-layer-group"></i></div>
            <div class="card-number"><?= $stats['plans'] ?></div>
            <div class="card-title">Total Plans</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="manage_premium_tasks.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-gold"><i class="fa-solid fa-crown"></i></div>
            <div class="card-number"><?= $stats['premium'] ?></div>
            <div class="card-title">Premium Jobs</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_tasks.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-teal"><i class="fa-solid fa-list-check"></i></div>
            <div class="card-number"><?= $stats['regular'] ?></div>
            <div class="card-title">Regular Jobs</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_typing_job.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-indigo"><i class="fa-solid fa-keyboard"></i></div>
            <div class="card-number"><?= $stats['typing'] ?></div>
            <div class="card-title">Typing Jobs</div>
        </div></a>
    </div>

    <div class="col-6">
        <a href="admin_gift_codes.php" style="text-decoration:none">
        <div class="dashboard-card">
            <div class="icon-box bg-green"><i class="fa-solid fa-gift"></i></div>
            <div class="card-number"><?= $stats['gift'] ?></div>
            <div class="card-title">Gift Requests</div>
        </div></a>
    </div>

</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
