<?php
include "../config.php";
if(isset($_GET['id']) && isset($_GET['status'])){
  $id=intval($_GET['id']);
  $status=$_GET['status'];

  $q=$conn->query("SELECT user_id,rate,status FROM gmail_sales WHERE id=$id");
  if($q->num_rows>0){
    $d=$q->fetch_assoc();
    if($status=='approved' && $d['status']!='approved'){
      $conn->query("UPDATE gmail_sales SET status='approved' WHERE id=$id");
      $conn->query("UPDATE users SET balance=balance+{$d['rate']} WHERE id={$d['user_id']}");
    }else{
      $conn->query("UPDATE gmail_sales SET status='$status' WHERE id=$id");
    }
  }
}
header("Location: admin_gmail.php");
exit;
?>