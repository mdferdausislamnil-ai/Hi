<?php
// ১. ডাটাবেস কানেকশন (পাথ ঠিক করে নিন, যদি admin ফোল্ডারে থাকে তবে ../config.php হবে)
include "../config.php"; 

// ২. জব ডিলিট করার লজিক
if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    $conn->query("DELETE FROM visiting_jobs WHERE id = '$id'");
    header("Location: vsadd.php");
    exit();
}

// ৩. জব এড করার লজিক
if (isset($_POST['add_job'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $url = mysqli_real_escape_string($conn, $_POST['url']);
    $sec = mysqli_real_escape_string($conn, $_POST['seconds']);
    $reward = mysqli_real_escape_string($conn, $_POST['reward']);

    if ($title && $url && $sec && $reward) {
        $conn->query("INSERT INTO visiting_jobs (title, url, reward, seconds) VALUES ('$title', '$url', '$reward', '$sec')");
        echo "<script>alert('Job Added Successfully!'); window.location.href='vsadd.php';</script>";
    }
}

// ৪. সব জব লিস্ট আনা
$jobs = $conn->query("SELECT * FROM visiting_jobs ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Add Job</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f7f6; padding: 20px; }
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .btn-back { background: #6c757d; color: white; border-radius: 50px; text-decoration: none; padding: 8px 20px; display: inline-block; margin-bottom: 20px; }
        .btn-back:hover { background: #5a6268; color: white; }
    </style>
</head>
<body>

<div class="container">
    <!-- Back Button -->
    <a href="index.php" class="btn-back"><i class="fas fa-arrow-left me-2"></i>Back to Dashboard</a>

    <div class="row">
        <!-- Add Job Form -->
        <div class="col-md-4">
            <div class="card p-4">
                <h4 class="fw-bold mb-4 text-primary">Add New Job</h4>
                <form method="POST">
                    <div class="mb-3">
                        <label>Job Title</label>
                        <input type="text" name="title" class="form-control" placeholder="Enter title" required>
                    </div>
                    <div class="mb-3">
                        <label>Website URL</label>
                        <input type="url" name="url" class="form-control" placeholder="https://..." required>
                    </div>
                    <div class="mb-3">
                        <label>Seconds (Wait Time)</label>
                        <input type="number" name="seconds" class="form-control" placeholder="Ex: 30" required>
                    </div>
                    <div class="mb-3">
                        <label>Reward (Amount)</label>
                        <input type="number" step="0.01" name="reward" class="form-control" placeholder="Ex: 2.50" required>
                    </div>
                    <button type="submit" name="add_job" class="btn btn-primary w-100 fw-bold rounded-pill">Add Job</button>
                </form>
            </div>
        </div>

        <!-- Job List -->
        <div class="col-md-8">
            <div class="card p-4">
                <h4 class="fw-bold mb-4 text-dark">Job List</h4>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Reward</th>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($jobs->num_rows > 0): ?>
                                <?php while($row = $jobs->fetch_assoc()): ?>
                                    <tr>
                                        <td>
                                            <strong><?= htmlspecialchars($row['title']) ?></strong><br>
                                            <small class="text-muted"><?= $row['url'] ?></small>
                                        </td>
                                        <td class="text-success fw-bold">৳ <?= $row['reward'] ?></td>
                                        <td><?= $row['seconds'] ?>s</td>
                                        <td>
                                            <a href="?delete_id=<?= $row['id'] ?>" onclick="return confirm('Delete this job?')" class="text-danger">
                                                <i class="fas fa-trash-alt fa-lg"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" class="text-center">No jobs added yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>