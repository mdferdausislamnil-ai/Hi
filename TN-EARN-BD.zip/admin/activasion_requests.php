<?php
session_start();
// ১. অ্যাডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";

// ২. AJAX হ্যান্ডলার (Approve/Reject/Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $id = intval($_POST['id']);
    $action = $_POST['action'];

    $conn->begin_transaction();
    try {
        // পেমেন্ট মেথড সহ ডাটা আনা হচ্ছে (Plan ID বের করার জন্য)
        $stmt = $conn->prepare("SELECT user_id, status, amount, payment_method FROM activation_requests WHERE id=?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $req = $stmt->get_result()->fetch_assoc();

        if (!$req) throw new Exception("Request not found!");

        if ($action == 'approve' && $req['status'] == 'pending') {
            $user_id = $req['user_id'];
            $payment_info = $req['payment_method']; // যেমন: "bKash - Plan Purchase (ID: 1)"

            // ১. রিকোয়েস্ট স্ট্যাটাস আপডেট
            $conn->query("UPDATE activation_requests SET status='approved', approved_at=NOW() WHERE id=$id");
            
            // ২. প্ল্যান চেক এবং আপডেট লজিক
            // পেমেন্ট মেথড টেক্সট থেকে চেক করা হচ্ছে এটি প্ল্যান কিনা
            if (strpos($payment_info, 'Plan Purchase') !== false) {
                
                // টেক্সট থেকে প্ল্যান আইডি বের করা (Regex ব্যবহার করে)
                if (preg_match('/ID: (\d+)/', $payment_info, $matches)) {
                    $plan_id = intval($matches[1]);

                    // প্ল্যানের মেয়াদ (Duration) ডাটাবেস থেকে আনা
                    $plan_res = $conn->query("SELECT duration_days FROM plans WHERE id='$plan_id'");
                    $days = ($plan_res->num_rows > 0) ? intval($plan_res->fetch_assoc()['duration_days']) : 30;

                    // ইউজার টেবিলে প্ল্যান আপডেট করা
                    $conn->query("UPDATE users SET 
                        status='active', 
                        plan_id='$plan_id', 
                        plan_expire_date = DATE_ADD(NOW(), INTERVAL $days DAY), 
                        daily_task_count = 0 
                        WHERE id='$user_id'");
                }
            } else {
                // যদি প্ল্যান না হয় (শুধু অ্যাক্টিভেশন ফি), তাহলে শুধু স্ট্যাটাস অ্যাক্টিভ হবে
                $conn->query("UPDATE users SET status='active' WHERE id='$user_id'");
            }

            // ৩. রেফারেল বোনাস লজিক
            $user_check = $conn->query("SELECT referred_by_id FROM users WHERE id=$user_id")->fetch_assoc();
            if ($user_check && $user_check['referred_by_id'] > 0) {
                $ref_id = $user_check['referred_by_id'];
                // সেটিংস থেকে বোনাস এমাউন্ট আনা
                $s_res = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='referral_bonus'")->fetch_assoc();
                $bonus = floatval($s_res['setting_value'] ?? 0);
                
                if ($bonus > 0) {
                    $conn->query("UPDATE users SET balance = balance + $bonus, referral_income = referral_income + $bonus WHERE id=$ref_id");
                }
            }
            $msg = "Account & Plan Activated Successfully!";
        } 
        elseif ($action == 'reject') {
            $conn->query("UPDATE activation_requests SET status='rejected' WHERE id=$id");
            $msg = "Request Rejected!";
        }
        elseif ($action == 'delete') {
            $conn->query("DELETE FROM activation_requests WHERE id=$id");
            $msg = "Request Deleted!";
        }

        $conn->commit();
        echo json_encode(['status' => 'success', 'message' => $msg]);
        exit;
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        exit;
    }
}

// ৩. সব রিকোয়েস্ট ডেটা আনা
$results = $conn->query("SELECT ar.*, u.fullname, u.email 
                        FROM activation_requests ar 
                        JOIN users u ON ar.user_id = u.id 
                        ORDER BY ar.id DESC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activation Manager | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; font-family: 'Poppins', sans-serif; }
        .card { border: none; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .table thead { background: #1e293b; color: #fff; font-size: 13px; }
        .status-badge { font-size: 10px; padding: 4px 10px; border-radius: 50px; font-weight: 800; text-transform: uppercase; }
        .st-pending { background: #fef3c7; color: #92400e; }
        .st-approved { background: #dcfce7; color: #166534; }
        .st-rejected { background: #fee2e2; color: #991b1b; }
        .btn-action { width: 32px; height: 32px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; border: none; transition: 0.3s; }
        .btn-approve { background: #dcfce7; color: #166534; }
        .btn-reject { background: #fee2e2; color: #b91c1c; }
        .btn-delete { background: #f1f5f9; color: #64748b; }
        .btn-action:hover { transform: scale(1.1); }
    </style>
</head>
<body class="p-3">

<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-dark m-0"><i class="fa-solid fa-user-shield text-primary me-2"></i>Activation Requests</h4>
        <a href="index.php" class="btn btn-dark btn-sm rounded-pill px-4">Dashboard</a>
    </div>

    <div class="card overflow-hidden">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr class="text-center">
                        <th>ID</th>
                        <th class="text-start">User Info</th>
                        <th>Method / Plan Info</th>
                        <th>Sender / TrxID</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($results->num_rows > 0): while($row = $results->fetch_assoc()): ?>
                    <tr class="text-center" id="row_<?= $row['id'] ?>">
                        <td class="fw-bold text-muted small">#<?= $row['id'] ?></td>
                        <td class="text-start">
                            <div class="fw-bold small text-dark"><?= htmlspecialchars($row['fullname']) ?></div>
                            <div class="text-muted" style="font-size: 11px;"><?= $row['email'] ?></div>
                        </td>
                        <td>
                            <!-- পেমেন্ট মেথড এবং প্ল্যান ইনফো এখানে দেখানো হবে -->
                            <span class="badge bg-light text-dark border small text-wrap" style="max-width: 150px;">
                                <?= $row['payment_method'] ?>
                            </span>
                        </td>
                        <td>
                            <div class="fw-bold small"><?= $row['sender_number'] ?></div>
                            <code class="text-primary" style="font-size: 10px;"><?= $row['trx_id'] ?></code>
                        </td>
                        <td class="fw-bold">৳<?= number_format($row['amount'], 2) ?></td>
                        <td><span class="status-badge st-<?= $row['status'] ?>" id="status_<?= $row['id'] ?>"><?= $row['status'] ?></span></td>
                        <td>
                            <div class="d-flex gap-1 justify-content-center" id="actions_<?= $row['id'] ?>">
                                <?php if($row['status'] == 'pending'): ?>
                                    <button onclick="handleAction(<?= $row['id'] ?>, 'approve')" class="btn-action btn-approve" title="Approve"><i class="fa-solid fa-check"></i></button>
                                    <button onclick="handleAction(<?= $row['id'] ?>, 'reject')" class="btn-action btn-reject" title="Reject"><i class="fa-solid fa-xmark"></i></button>
                                <?php endif; ?>
                                <button onclick="handleAction(<?= $row['id'] ?>, 'delete')" class="btn-action btn-delete" title="Delete"><i class="fa-solid fa-trash-can"></i></button>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; else: ?>
                        <tr><td colspan="7" class="text-center py-5 text-muted">কোনো অ্যাক্টিভেশন রিকোয়েস্ট পাওয়া যায়নি।</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- SweetAlert2 & jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function handleAction(id, action) {
    let confirmText = action === 'delete' ? "আপনি কি এটি ডিলিট করতে চান?" : "আপনি কি নিশ্চিত?";
    
    Swal.fire({
        title: confirmText,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#4f46e5',
        confirmButtonText: 'হ্যাঁ',
        cancelButtonText: 'না'
    }).then((result) => {
        if (result.isConfirmed) {
            // লোডিং দেখাবে
            Swal.showLoading();
            
            $.ajax({
                url: '',
                method: 'POST',
                data: { id: id, action: action },
                success: function(response) {
                    if (response.status === 'success') {
                        if (action === 'delete') {
                            $(`#row_${id}`).fadeOut();
                        } else {
                            $(`#status_${id}`).removeClass('st-pending').addClass('st-' + action).text(action);
                            if (action !== 'pending') {
                                $(`#actions_${id} .btn-approve, #actions_${id} .btn-reject`).remove();
                            }
                        }
                        Swal.fire('সফল!', response.message, 'success');
                    } else {
                        Swal.fire('এরর!', response.message, 'error');
                    }
                },
                error: function() {
                    Swal.fire('এরর!', 'সার্ভারে সমস্যা হয়েছে।', 'error');
                }
            });
        }
    });
}
</script>
</body>
</html>