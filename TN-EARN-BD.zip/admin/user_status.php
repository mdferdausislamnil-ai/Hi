<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
include "../config.php";

if(isset($_GET['id']) && isset($_GET['status'])){
  $id = intval($_GET['id']);
  $status = $_GET['status'];

  $q = $conn->query("SELECT user_id, rate, status FROM gmail_sales WHERE id=$id");
  if($q->num_rows > 0){
    $d = $q->fetch_assoc();
    if($status == 'approved' && $d['status'] != 'approved'){
      $conn->query("UPDATE gmail_sales SET status='approved' WHERE id=$id");
      $conn->query("UPDATE users SET balance=balance+{$d['rate']} WHERE id={$d['user_id']}");
    } else {
      $conn->query("UPDATE gmail_sales SET status='$status' WHERE id=$id");
    }
  }
}
// যে পেজ থেকে এসেছে সেখানে ব্যাক করবে (Referer check), ডিফল্ট admin_gmail
if(isset($_SERVER['HTTP_REFERER'])) {
    header("Location: " . $_SERVER['HTTP_REFERER']);
} else {
    header("Location: admin_gmail.php");
}
exit;
?>