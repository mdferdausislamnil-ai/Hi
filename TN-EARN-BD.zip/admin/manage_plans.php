<?php
session_start();
// এডমিন লগইন চেক
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

include "../config.php";
$msg = "";

// ১. নতুন প্লান যুক্ত করা
if (isset($_POST['add_plan'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $price = floatval($_POST['price']);
    $days = intval($_POST['days']);
    $limit = intval($_POST['limit']);
    $rate = floatval($_POST['rate']);

    $conn->query("INSERT INTO plans (name, price, duration_days, daily_limit, task_rate) VALUES ('$name', '$price', '$days', '$limit', '$rate')");
    $msg = "✅ নতুন প্লান সফলভাবে যুক্ত হয়েছে!";
}

// ২. প্লান ডিলিট করা
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM plans WHERE id=$id");
    header("Location: manage_plans.php");
}

// প্লান লিস্ট আনা
$plans = $conn->query("SELECT * FROM plans ORDER BY price ASC");
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Plans</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body{background:#f4f6f9;padding:20px;}</style>
</head>
<body>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>📦 Membership Plans Manager</h4>
        <a href="index.php" class="btn btn-dark btn-sm">Dashboard</a>
    </div>

    <?php if($msg): ?><div class="alert alert-success"><?= $msg ?></div><?php endif; ?>

    <div class="row">
        <!-- Add Plan Form -->
        <div class="col-md-4">
            <div class="card p-4 border-0 shadow-sm">
                <h6 class="fw-bold mb-3">Add New Plan</h6>
                <form method="POST">
                    <div class="mb-2"><label>Plan Name</label><input type="text" name="name" class="form-control" placeholder="e.g. VIP 1" required></div>
                    <div class="mb-2"><label>Price (৳)</label><input type="number" name="price" class="form-control" placeholder="500" required></div>
                    <div class="mb-2"><label>Validity (Days)</label><input type="number" name="days" class="form-control" placeholder="30" required></div>
                    <div class="mb-2"><label>Daily Task Limit</label><input type="number" name="limit" class="form-control" placeholder="10" required></div>
                    <div class="mb-3"><label>Rate Per Task (৳)</label><input type="text" name="rate" class="form-control" placeholder="5.00" required></div>
                    <button type="submit" name="add_plan" class="btn btn-primary w-100 fw-bold">Create Plan</button>
                </form>
            </div>
        </div>

        <!-- Plan List -->
        <div class="col-md-8">
            <div class="card p-4 border-0 shadow-sm">
                <h6 class="fw-bold mb-3">All Active Plans</h6>
                <table class="table table-bordered text-center">
                    <thead class="table-light">
                        <tr>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Days</th>
                            <th>Limit</th>
                            <th>Rate</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $plans->fetch_assoc()): ?>
                        <tr>
                            <td><?= $row['name'] ?></td>
                            <td class="fw-bold text-success">৳<?= $row['price'] ?></td>
                            <td><?= $row['duration_days'] ?></td>
                            <td><?= $row['daily_limit'] ?></td>
                            <td>৳<?= $row['task_rate'] ?></td>
                            <td>
                                <a href="?delete=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this plan?')">Delete</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>