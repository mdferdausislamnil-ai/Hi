<?php
include "header.php"; 
include "sidebar.php";
$user_id = $u['id'];

// জব ফেচ করা (যেগুলো ইউজার এখনো করেনি)
$jobs_query = "SELECT j.* FROM visiting_jobs j
               LEFT JOIN user_job_logs ujl ON j.id = ujl.job_id AND ujl.user_id = '$user_id'
               WHERE ujl.id IS NULL AND j.status = 'active'
               ORDER BY j.id DESC";
$jobs = $conn->query($jobs_query);

// পরিসংখ্যান
$total_jobs = $conn->query("SELECT COUNT(*) as t FROM visiting_jobs WHERE status='active'")->fetch_assoc()['t'];
$done_jobs = $conn->query("SELECT COUNT(*) as d FROM user_job_logs WHERE user_id = '$user_id'")->fetch_assoc()['d'];
?>

<style>
    .job-card { background: #fff; border-radius: 15px; overflow: hidden; transition: 0.3s; border: 1px solid #eee; margin-bottom: 20px; }
    .job-card img { width: 100%; height: 150px; object-fit: cover; }
    .job-content { padding: 15px; }
    .timer-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.95); z-index: 10000; display: none; flex-direction: column; align-items: center; justify-content: center; color: white; text-align: center; }
    .countdown-circle { width: 100px; height: 100px; border: 4px solid #f39c12; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 35px; margin-bottom: 20px; }
    .pause-msg { color: #ff4757; font-weight: bold; display: none; }
</style>

<div id="jobTimerOverlay" class="timer-overlay">
    <div class="countdown-circle" id="timerBox">0</div>
    <h3 id="timerStatus">কাজটি চলমান...</h3>
    <p class="pause-msg" id="pauseMsg">আপনি ট্যাব পরিবর্তন করেছেন! টাইমার থেমে গেছে।</p>
    <p class="text-warning">পুরো সময় শেষ না হওয়া পর্যন্ত এই পেজ থেকে সরবেন না।</p>
</div>

<div class="container-fluid mt-4">
    <div class="row bg-primary text-white p-3 rounded mb-4 mx-1">
        <div class="col-6">Total Jobs: <b><?= $total_jobs ?></b></div>
        <div class="col-6 text-end">Completed: <b><?= $done_jobs ?></b></div>
    </div>

    <div class="row">
        <?php while($job = $jobs->fetch_assoc()): ?>
            <div class="col-md-4 col-sm-6">
                <div class="job-card shadow-sm">
                    <img src="<?= $job['thumbnail'] ?>" alt="Job Image">
                    <div class="job-content">
                        <h6 class="fw-bold"><?= $job['title'] ?></h6>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-success fw-bold">৳ <?= $job['reward'] ?></span>
                            <span class="badge bg-light text-dark"><?= $job['seconds'] ?> Sec</span>
                        </div>
                        <button onclick="startJob(<?= $job['id'] ?>, '<?= $job['url'] ?>', <?= $job['seconds'] ?>)" class="btn btn-primary btn-sm w-100 rounded-pill">Visit Now</button>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
let timeLeft;
let timerInterval;
let isTabActive = true;
let currentJobId = null;

// ট্যাব পরিবর্তন ডিটেক্ট করা
document.addEventListener("visibilitychange", function() {
    if (document.hidden) {
        isTabActive = false;
        document.getElementById('pauseMsg').style.display = 'block';
        document.getElementById('timerStatus').innerText = "টাইমার স্থগিত!";
    } else {
        isTabActive = true;
        document.getElementById('pauseMsg').style.display = 'none';
        document.getElementById('timerStatus').innerText = "কাজটি চলমান...";
    }
});

function startJob(id, url, seconds) {
    currentJobId = id;
    window.open(url, '_blank'); // নতুন ট্যাবে লিংক ওপেন হবে
    
    let overlay = document.getElementById('jobTimerOverlay');
    let timerBox = document.getElementById('timerBox');
    overlay.style.display = 'flex';
    
    timeLeft = seconds;
    timerBox.innerText = timeLeft;

    timerInterval = setInterval(function() {
        if (isTabActive) { // ইউজার যদি এই ট্যাবে থাকে তবেই কমবে
            timeLeft--;
            timerBox.innerText = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                overlay.style.display = 'none';
                completeJob(id);
            }
        }
    }, 1000);
}

function completeJob(id) {
    fetch('process_jobx.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'job_id=' + id
    })
    .then(res => res.json())
    .then(data => {
        if(data.success) {
            Swal.fire('অভিনন্দন!', 'আপনার রিওয়ার্ড যোগ হয়েছে।', 'success').then(() => location.reload());
        } else {
            Swal.fire('ব্যর্থ!', data.message, 'error');
        }
    });
}
</script>

<?php include "footer.php"; ?>