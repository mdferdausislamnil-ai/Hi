<?php
// Error reporting (for debugging, can be disabled in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);

include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">Facebook ID Sell Locked!</h4>
                <p class="text-muted small px-3">Your account must be active to sell Facebook IDs.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>Activate Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

$user_id = $u['id'];
$dailyPass = $s['fb_sell_pass'] ?? 'Talent@123';
$fbRate = $s['fb_rate'] ?? 10.00;

// Variables for SweetAlert popup
$swal_trigger = ""; 

if (isset($_POST['submit_fb'])) {
    $uid = trim($conn->real_escape_string($_POST['uid']));
    $gmail = trim($conn->real_escape_string($_POST['gmail']));
    $pass = trim($conn->real_escape_string($_POST['password']));
    $two_fa = trim($conn->real_escape_string($_POST['two_fa']));

    if ($uid != "" && $pass != "") {
        // Insert into database
        $sql = "INSERT INTO facebook_sales (user_id, uid, gmail, password, two_fa, rate, status) 
                VALUES ('$user_id', '$uid', '$gmail', '$pass', '$two_fa', '$fbRate', 'pending')";
        
        if ($conn->query($sql)) {
            // Success trigger
            $swal_trigger = "success";
        } else {
            // Database error
            $swal_trigger = "error";
        }
    } else {
        // Empty fields
        $swal_trigger = "empty";
    }
}

// Load recent history
$history = $conn->query("SELECT * FROM facebook_sales WHERE user_id='$user_id' ORDER BY id DESC LIMIT 10");
?>

<!-- ====== FACEBOOK SELL PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 700px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* main sell card – matches dashboard profile/wallet cards */
    .sell-card {
        background: white;
        border-radius: 32px;
        padding: 30px 28px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        margin-top: 20px;
        transition: all 0.25s ease;
    }
    .sell-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* notice box – redesigned with gradient */
    .notice-box-modern {
        background: linear-gradient(145deg, #fff3cd, #fef9e7);
        border-radius: 24px;
        padding: 20px;
        margin-bottom: 25px;
        border: 1px solid #ffd966;
        box-shadow: 0 8px 16px -6px #f59e0b40;
    }
    .notice-box-modern p {
        margin-bottom: 12px;
        font-size: 14px;
        color: #92400e;
        font-weight: 500;
    }
    .pass-display {
        background: white;
        border-radius: 60px;
        padding: 10px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 8px rgba(0,0,0,0.02);
    }
    .pass-display span {
        font-weight: 800;
        color: #dc2626;
        letter-spacing: 0.5px;
        font-size: 16px;
    }
    .pass-display button {
        background: #4b5563;
        border: none;
        color: white;
        font-weight: 600;
        padding: 6px 18px;
        border-radius: 40px;
        font-size: 12px;
        transition: 0.2s;
    }
    .pass-display button:hover {
        background: #1f2937;
    }

    /* form inputs */
    .form-control-modern {
        background: #f1f5f9;
        border: 1px solid #e2e8f0;
        border-radius: 60px;
        padding: 14px 20px;
        font-size: 14px;
        color: #1e293b;
        width: 100%;
        transition: 0.2s;
    }
    .form-control-modern:focus {
        outline: 2px solid #1877F2;
        background: white;
        border-color: transparent;
    }
    textarea.form-control-modern {
        border-radius: 28px;
        resize: vertical;
    }
    label {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        margin-bottom: 6px;
        display: block;
        margin-left: 6px;
    }

    /* submit button – matches dashboard copy button */
    .btn-submit-modern {
        background: linear-gradient(90deg, #1877F2, #0e5a9c);
        border: none;
        color: white;
        font-weight: 800;
        padding: 16px 20px;
        border-radius: 60px;
        width: 100%;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 12px 22px -8px #1877F280;
        transition: 0.15s;
        border: 1px solid #ffffff40;
        margin-top: 10px;
    }
    .btn-submit-modern:hover {
        background: linear-gradient(90deg, #0e5a9c, #0a4270);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #0e5a9c;
        color: white;
    }

    /* history card */
    .history-card {
        background: white;
        border-radius: 32px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        overflow: hidden;
        margin-top: 30px;
    }

    /* table styling (like history page) */
    .table {
        margin-bottom: 0;
    }
    .table thead {
        background: #f8fafc;
        border-bottom: 2px solid #e2e8f0;
    }
    .table thead th {
        color: #64748b;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        padding: 18px 16px;
        border: none;
    }
    .table td {
        vertical-align: middle;
        font-size: 14px;
        color: #334155;
        padding: 16px;
        border-bottom: 1px solid #ecf1f7;
    }
    .table tr:last-child td {
        border-bottom: none;
    }

    /* status badge – gradient (like history page) */
    .status-badge {
        padding: 6px 18px;
        border-radius: 40px;
        font-weight: 700;
        font-size: 12px;
        letter-spacing: 0.3px;
        display: inline-block;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    }
    .status-badge.approved {
        background: linear-gradient(145deg, #10b981, #059669);
        color: white;
    }
    .status-badge.pending {
        background: linear-gradient(145deg, #f59e0b, #d97706);
        color: white;
    }
    .status-badge.rejected {
        background: linear-gradient(145deg, #ef4444, #dc2626);
        color: white;
    }

    /* empty state */
    .empty-state {
        padding: 30px 20px;
        text-align: center;
        color: #94a3b8;
        font-weight: 500;
    }

    /* pulse animation for inactive card (from dashboard) */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* back link */
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 25px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #1877F2;
    }
</style>

<div class="container-custom pb-5">
    <!-- header -->
    <div class="section-title mt-4">
        <i class="fa-brands fa-facebook" style="color: #1877F2;"></i> Sell Facebook IDs
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <!-- main sell card -->
            <div class="sell-card animate-fade-up">
                <h4 class="fw-bold text-center mb-4" style="color: #0b253c;">Submit Your ID</h4>

                <!-- redesigned notice box -->
                <div class="notice-box-modern">
                    <p><i class="fa-solid fa-circle-exclamation me-2" style="color: #f59e0b;"></i> <strong>Important Notice:</strong> You must provide today's password, otherwise it will be rejected.</p>
                    <div class="pass-display">
                        <span id="copyPass"><?= htmlspecialchars($dailyPass) ?></span>
                        <button onclick="copyText('copyPass')"><i class="fa-regular fa-copy me-1"></i> Copy</button>
                    </div>
                </div>

                <form method="POST">
                    <div class="mb-3">
                        <label>UID / Profile Link</label>
                        <input type="text" name="uid" class="form-control-modern" placeholder="ID UID or Link" required>
                    </div>
                    <div class="mb-3">
                        <label>Gmail / Phone</label>
                        <input type="text" name="gmail" class="form-control-modern" placeholder="Login email or phone">
                    </div>
                    <div class="mb-3">
                        <label>Password</label>
                        <input type="text" name="password" class="form-control-modern" placeholder="Account password" required>
                    </div>
                    <div class="mb-3">
                        <label>2FA Key (Optional)</label>
                        <textarea name="two_fa" class="form-control-modern" rows="3" placeholder="Paste 2FA key here..."></textarea>
                    </div>
                    <button type="submit" name="submit_fb" class="btn-submit-modern">
                        Submit <i class="fa-solid fa-paper-plane ms-2"></i>
                    </button>
                </form>
            </div>

            <!-- history card -->
            <div class="history-card">
                <div class="p-3 fw-bold text-dark border-bottom" style="background: #f9f9fc; padding: 18px 20px !important;">
                    <i class="fa-regular fa-clock me-2" style="color: #64748b;"></i> Recent History
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr><th>UID</th><th>Status</th><th>Rate</th></tr>
                        </thead>
                        <tbody>
                            <?php if($history && $history->num_rows > 0): while($h = $history->fetch_assoc()): ?>
                            <tr>
                                <td class="fw-bold text-secondary"><?= htmlspecialchars(substr($h['uid'], 0, 20)) ?>..</td>
                                <td>
                                    <span class="status-badge <?= $h['status'] ?>">
                                        <?= $h['status'] == 'approved' ? 'Approved' : ($h['status'] == 'rejected' ? 'Rejected' : 'Pending') ?>
                                    </span>
                                </td>
                                <td class="fw-bold" style="color: #1877F2;">৳ <?= number_format($h['rate'], 2) ?></td>
                            </tr>
                            <?php endwhile; else: ?>
                            <tr><td colspan="3" class="empty-state">No IDs have been sold yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- back to dashboard link -->
            <div class="text-center">
                <a href="dashboard.php" class="back-link">
                    <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // entrance animation for main card
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.sell-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.6s ease-out';
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
    });

    // copy function for password
    function copyText(id) {
        let text = document.getElementById(id).innerText;
        navigator.clipboard.writeText(text).then(() => {
            Swal.fire({
                icon: 'success',
                title: 'Copied!',
                text: 'Password saved to clipboard.',
                timer: 1500,
                showConfirmButton: false,
                background: '#0f172a',
                color: '#fff',
                iconColor: '#10b981'
            });
        }).catch(() => {
            Swal.fire({
                icon: 'error',
                title: 'Failed!',
                text: 'Unable to copy.',
                background: '#0f172a',
                color: '#fff'
            });
        });
    }

    // submission popup logic (with dark theme)
    <?php if ($swal_trigger == 'success'): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: 'Your Facebook ID has been submitted successfully.',
            confirmButtonText: 'OK',
            confirmButtonColor: '#1877F2',
            background: '#0f172a',
            color: '#fff',
            iconColor: '#10b981'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'facebook.php';
            }
        });
    <?php elseif ($swal_trigger == 'error'): ?>
        Swal.fire({
            icon: 'error',
            title: 'Failed!',
            text: 'Database error occurred, please try again.',
            confirmButtonColor: '#ef4444',
            background: '#0f172a',
            color: '#fff'
        });
    <?php elseif ($swal_trigger == 'empty'): ?>
        Swal.fire({
            icon: 'warning',
            title: 'Incomplete!',
            text: 'Please fill all required fields correctly.',
            confirmButtonColor: '#f59e0b',
            background: '#0f172a',
            color: '#fff'
        });
    <?php endif; ?>
</script>

<?php include "footer.php"; ?>