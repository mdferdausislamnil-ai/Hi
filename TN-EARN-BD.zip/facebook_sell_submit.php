<?php
session_start();
include "config.php";

header('Content-Type: application/json');

if(!isset($_SESSION['fullname'])){
    echo json_encode(['status'=>'error','message'=>'Login required']);
    exit;
}

$user = $_SESSION['fullname'];
$stmt = $conn->prepare("SELECT id FROM users WHERE fullname=?");
$stmt->bind_param("s",$user);
$stmt->execute();
$res = $stmt->get_result();
$userRow = $res->fetch_assoc();
$user_id = $userRow['id'];

$uid = trim($_POST['uid']);
$gmail = trim($_POST['gmail']);
$password = trim($_POST['password']);
$two_fa = trim($_POST['two_fa']);

$rateQuery = $conn->query("SELECT gmail_rate FROM settings ORDER BY id DESC LIMIT 1");
$rateRow = $rateQuery->fetch_assoc();
$current_rate = $rateRow ? $rateRow['gmail_rate'] : 0;

if(empty($uid) || empty($gmail) || empty($password)){
    echo json_encode(['status'=>'error','message'=>'All fields required']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO facebook_sales (user_id, uid, gmail, password, two_fa, rate, status) VALUES (?,?,?,?,?,?, 'pending')");
$stmt->bind_param("issssd", $user_id, $uid, $gmail, $password, $two_fa, $current_rate);
$stmt->execute();

echo json_encode(['status'=>'ok']);