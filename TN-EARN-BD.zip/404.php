<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>পেজ পাওয়া যায়নি - 404 Error</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        body { 
            background: #f1f5f9; 
            font-family: 'Poppins', sans-serif; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            height: 100vh; 
            margin: 0; 
            padding: 20px;
        }
        .error-card { 
            text-align: center; 
            padding: 50px 30px; 
            background: #fff; 
            border-radius: 35px; 
            box-shadow: 0 20px 50px rgba(0,0,0,0.05); 
            max-width: 550px; 
            width: 100%; 
            border: 1px solid #e2e8f0;
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        
        .error-code { 
            font-size: 120px; 
            font-weight: 900; 
            background: linear-gradient(135deg, #6366f1, #4f46e5); 
            -webkit-background-clip: text; 
            -webkit-text-fill-color: transparent; 
            line-height: 1; 
            margin-bottom: 20px;
            letter-spacing: -5px;
        }
        h4 { font-weight: 800; color: #1e293b; margin-bottom: 15px; }
        p { color: #64748b; font-size: 15px; margin-bottom: 35px; line-height: 1.6; }
        
        .btn-group { display: flex; gap: 15px; justify-content: center; flex-wrap: wrap; }
        
        .btn-home { 
            background: #4f46e5; 
            color: #fff; 
            border-radius: 15px; 
            padding: 14px 30px; 
            font-weight: 700; 
            text-decoration: none; 
            transition: 0.3s; 
            box-shadow: 0 10px 20px rgba(79, 70, 229, 0.2);
        }
        .btn-home:hover { background: #3730a3; transform: translateY(-3px); color: #fff; }
        
        .btn-dev { 
            background: #0088cc; 
            color: #fff; 
            border-radius: 15px; 
            padding: 14px 30px; 
            font-weight: 700; 
            text-decoration: none; 
            transition: 0.3s; 
            box-shadow: 0 10px 20px rgba(0, 136, 204, 0.2);
        }
        .btn-dev:hover { background: #006699; transform: translateY(-3px); color: #fff; }
        
        .contact-label { margin-top: 30px; font-size: 12px; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
    </style>
</head>
<body>

    <div class="error-card">
        <div class="error-code">404</div>
        <h4>ওহ! আপনি কি হারিয়ে গেছেন?</h4>
        <p>আপনি যে পেজটি খুঁজছেন সেটি খুঁজে পাওয়া যায়নি অথবা পেজটি সরিয়ে ফেলা হয়েছে। আপনি আমাদের ড্যাশবোর্ডে ফিরে যেতে পারেন অথবা কোনো টেকনিক্যাল সমস্যার জন্য সরাসরি ডেভেলপারের সাথে কথা বলতে পারেন।</p>
        
        <div class="btn-group">
            <a href="dashboard.php" class="btn-home">
                <i class="fa-solid fa-house-chimney me-2"></i> হোমে ফিরে যান
            </a>
            <a href="https://t.meShawon_Bhai_121" target="_blank" class="btn-dev">
                <i class="fa-brands fa-telegram me-2"></i> ডেভেলপারের সাথে যোগাযোগ
            </a>
        </div>

        <div class="contact-label">Developed by AURADEV AI</div>
    </div>

</body>
</html>