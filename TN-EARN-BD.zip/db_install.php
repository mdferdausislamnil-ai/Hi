<?php
include "config.php";

// ডাটাবেস কানেকশন চেক
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$tables = [];

// ১. Facebook Sales Table
$tables[] = "CREATE TABLE IF NOT EXISTS facebook_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    uid VARCHAR(255) NOT NULL,
    gmail VARCHAR(255) NULL, -- এই কলামটি মিসিং ছিল
    password VARCHAR(255) NOT NULL,
    two_fa TEXT NULL,
    rate DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// ২. Gmail Sales Table
$tables[] = "CREATE TABLE IF NOT EXISTS gmail_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    gmail VARCHAR(255) NOT NULL,
    pass VARCHAR(255) NOT NULL,
    rate DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// ৩. Instagram Sales Table
$tables[] = "CREATE TABLE IF NOT EXISTS instagram_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    insta_username VARCHAR(255) NOT NULL,
    insta_password VARCHAR(255) NOT NULL,
    two_fa_key TEXT NULL,
    rate DECIMAL(10,2) DEFAULT 0.00,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

// ৪. Coin Sales Table
$tables[] = "CREATE TABLE IF NOT EXISTS coin_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    coin_type VARCHAR(50) NOT NULL,
    amount INT NOT NULL,
    sender_username VARCHAR(255) NOT NULL,
    screenshot VARCHAR(255) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

echo "<h3>Database Setup Status:</h3>";

foreach ($tables as $sql) {
    if ($conn->query($sql) === TRUE) {
        echo "<p style='color:green;'>✅ টেবিল তৈরি/চেক করা হয়েছে।</p>";
    } else {
        echo "<p style='color:red;'>❌ এরর: " . $conn->error . "</p>";
    }
}

// মিসিং কলাম চেক এবং ফিক্স (যদি টেবিল আগে থেকে থাকে)
$conn->query("ALTER TABLE facebook_sales ADD COLUMN gmail VARCHAR(255) NULL AFTER uid");
$conn->query("ALTER TABLE facebook_sales ADD COLUMN two_fa TEXT NULL AFTER password");
$conn->query("ALTER TABLE instagram_sales ADD COLUMN two_fa_key TEXT NULL AFTER insta_password");

echo "<hr><h3>🎉 সব ঠিক আছে! এখন কাজ করবে।</h3>";
echo "<a href='dashboard.php'>ড্যাশবোর্ডে ফিরে যান</a>";
?>