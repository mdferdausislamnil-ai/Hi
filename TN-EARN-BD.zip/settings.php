<?php
include "header.php"; 
include "sidebar.php";

// ডাটাবেস থেকে ইউজারের লেটেস্ট তথ্য আনা (header.php তে $u অলরেডি আছে, তবুও নিরাপত্তার জন্য পুনরায় চেক)
$user_id = $u['id'];

$success = $error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $email = $conn->real_escape_string($_POST['email']);
    $new_pass = $_POST['password'];
    
    $profile_pic = $u['profile_pic'];

    // ১. প্রোফাইল ছবি আপলোড হ্যান্ডলার
    if (!empty($_FILES['profile_pic']['name'])) {
        $targetDir = "Uploads/profile/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);

        $fileExtension = strtolower(pathinfo($_FILES["profile_pic"]["name"], PATHINFO_EXTENSION));
        $newFileName = "user_" . $user_id . "_" . time() . "." . $fileExtension;
        $targetFilePath = $targetDir . $newFileName;

        $allowTypes = array('jpg', 'jpeg', 'png');
        if (in_array($fileExtension, $allowTypes)) {
            if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $targetFilePath)) {
                // পুরনো ছবি থাকলে ডিলিট করা (ডিফল্ট ছবি না হলে)
                if (!empty($u['profile_pic']) && file_exists($u['profile_pic'])) {
                    unlink($u['profile_pic']);
                }
                $profile_pic = $targetFilePath;
            } else {
                $error = "ছবি আপলোড করতে সমস্যা হয়েছে!";
            }
        } else {
            $error = "শুধুমাত্র JPG, JPEG এবং PNG ছবি অনুমোদিত।";
        }
    }

    // ২. পাসওয়ার্ড আপডেট লজিক
    if (!$error) {
        if (!empty($new_pass)) {
            if (strlen($new_pass) < 6) {
                $error = "পাসওয়ার্ড অন্তত ৬ সংখ্যার হতে হবে।";
            } else {
                $hashed_pass = password_hash($new_pass, PASSWORD_BCRYPT);
                $update_query = "UPDATE users SET fullname='$fullname', email='$email', password='$hashed_pass', profile_pic='$profile_pic' WHERE id='$user_id'";
            }
        } else {
            $update_query = "UPDATE users SET fullname='$fullname', email='$email', profile_pic='$profile_pic' WHERE id='$user_id'";
        }

        // ৩. ফাইনাল আপডেট
        if (empty($error)) {
            if ($conn->query($update_query)) {
                $_SESSION['fullname'] = $fullname; // সেশন আপডেট
                $success = "আপনার প্রোফাইল সফলভাবে আপডেট হয়েছে!";
                // তথ্য রিফ্রেশ করা
                echo "<script>
                    setTimeout(function() {
                        window.location.href = 'settings.php?success=1';
                    }, 500);
                </script>";
            } else {
                $error = "আপডেট ব্যর্থ হয়েছে! আবার চেষ্টা করুন।";
            }
        }
    }
}
?>

<style>
    body { background: #f0f2f5; }
    .profile-card {
        background: #fff;
        border-radius: 25px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        border: none;
        overflow: hidden;
        margin-top: 20px;
    }
    .profile-header-bg {
        height: 120px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    .profile-img-container {
        text-align: center;
        margin-top: -60px;
        position: relative;
        display: inline-block;
        left: 50%;
        transform: translateX(-50%);
    }
    .profile-img-preview {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        object-fit: cover;
        border: 5px solid #fff;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        background: #eee;
    }
    .edit-icon-label {
        position: absolute;
        bottom: 5px;
        right: 5px;
        background: #fff;
        width: 35px;
        height: 35px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        color: #4f46e5;
        transition: 0.3s;
    }
    .edit-icon-label:hover { background: #4f46e5; color: #fff; }
    
    .form-label { font-weight: 700; color: #475569; font-size: 14px; margin-bottom: 8px; }
    .form-control {
        border-radius: 12px;
        padding: 12px 15px;
        border: 1px solid #e2e8f0;
        background: #f8fafc;
        transition: 0.3s;
    }
    .form-control:focus {
        background: #fff;
        border-color: #6366f1;
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.1);
    }
    .btn-update {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
        color: #fff;
        font-weight: 700;
        border: none;
        padding: 14px;
        border-radius: 15px;
        width: 100%;
        margin-top: 20px;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        transition: 0.3s;
    }
    .btn-update:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4); color: #fff; }
</style>

<div class="container pb-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="profile-card animate-fade-up">
                <div class="profile-header-bg"></div>
                
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="profile-img-container">
                        <!-- প্রোফাইল ছবি প্রিভিউ -->
                        <?php 
                            $user_img = (!empty($u['profile_pic']) && file_exists($u['profile_pic'])) 
                                        ? $u['profile_pic'] 
                                        : 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png';
                        ?>
                        <img src="<?= $user_img ?>" id="imgPreview" class="profile-img-preview">
                        
                        <!-- ফাইল আপলোড বাটন (লুকানো) -->
                        <label for="profileInput" class="edit-icon-label">
                            <i class="fa-solid fa-camera"></i>
                        </label>
                        <input type="file" name="profile_pic" id="profileInput" hidden accept="image/*">
                    </div>

                    <div class="p-4 pt-2">
                        <h5 class="text-center fw-bold text-dark mb-4">Edit Profile</h5>

                        <!-- মেসেজ প্রদর্শন -->
                        <?php if($error): ?>
                            <div class="alert alert-danger border-0 rounded-3 small"><?= $error ?></div>
                        <?php endif; ?>
                        <?php if(isset($_GET['success'])): ?>
                            <div class="alert alert-success border-0 rounded-3 small">✅ প্রোফাইল সফলভাবে আপডেট হয়েছে!</div>
                        <?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label"><i class="fa-solid fa-user me-2 text-primary"></i>Full Name</label>
                            <input type="text" name="fullname" class="form-control" value="<?= htmlspecialchars($u['fullname']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><i class="fa-solid fa-envelope me-2 text-primary"></i>Email Address</label>
                            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($u['email']) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label"><i class="fa-solid fa-lock me-2 text-primary"></i>New Password (Optional)</label>
                            <input type="password" name="password" class="form-control" placeholder="পাসওয়ার্ড বদলাতে চাইলে লিখুন">
                            <small class="text-muted" style="font-size: 11px;">পাসওয়ার্ড পরিবর্তন না করতে চাইলে খালি রাখুন।</small>
                        </div>

                        <button type="submit" class="btn-update">
                            <i class="fa-solid fa-cloud-arrow-up me-2"></i> Save Changes
                        </button>

                        <div class="text-center mt-3">
                            <a href="dashboard.php" class="text-decoration-none text-muted small fw-bold">
                                <i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    // ইমেজ প্রিভিউ করার স্ক্রিপ্ট
    document.getElementById('profileInput').onchange = evt => {
        const [file] = document.getElementById('profileInput').files;
        if (file) {
            document.getElementById('imgPreview').src = URL.createObjectURL(file);
        }
    }

    // সুন্দর এনিমেশন
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.profile-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = '0.5s ease-out';
        
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
    });
</script>

<?php include "footer.php"; ?>