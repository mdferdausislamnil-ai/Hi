<?php
// ডাটাবেস কানেকশন ইনক্লুড
include "config.php";

// সেশন স্টার্ট (ইউজার আইডি পাওয়ার জন্য)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// রেসপন্স হেডার সেট করা (যাতে জাভাস্ক্রিপ্ট ঠিকঠাক ডাটা পায়)
header('Content-Type: application/json');

// ইউজার লগইন আছে কিনা চেক করা
// আপনার সাইটের সেশন ভেরিয়েবল অনুযায়ী $_SESSION['user_id'] পরিবর্তন হতে পারে
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in!']);
    exit();
}

$user_id = $_SESSION['user_id'];

// POST মেথডে job_id আসছে কিনা চেক করা
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['job_id'])) {
    
    $job_id = mysqli_real_escape_string($conn, $_POST['job_id']);

    // ১. চেক করা: ইউজার কি এই জবটি আগে করেছে?
    $check_log = $conn->query("SELECT id FROM user_job_logs WHERE user_id = '$user_id' AND job_id = '$job_id'");
    
    if ($check_log->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'আপনি এই কাজটি ইতিমধ্যে সম্পন্ন করেছেন!']);
        exit();
    }

    // ২. জবের তথ্য এবং রিওয়ার্ড অ্যামাউন্ট আনা
    $job_res = $conn->query("SELECT reward FROM visiting_jobs WHERE id = '$job_id' AND status = 'active'");
    
    if ($job_res->num_rows > 0) {
        $job_data = $job_res->fetch_assoc();
        $reward_amount = $job_data['reward'];

        // ৩. ইউজারের ব্যালেন্স আপডেট করা
        // আপনার টেবিলের নাম 'users' এবং কলামের নাম 'balance' ধরে করা হয়েছে
        $update_balance = $conn->query("UPDATE users SET balance = balance + $reward_amount WHERE id = '$user_id'");

        if ($update_balance) {
            // ৪. জব সম্পন্ন হওয়ার লগ সেভ করা
            $insert_log = $conn->query("INSERT INTO user_job_logs (user_id, job_id) VALUES ('$user_id', '$job_id')");

            if ($insert_log) {
                echo json_encode(['success' => true, 'message' => 'অভিনন্দন! আপনার রিওয়ার্ড যোগ হয়েছে।']);
            } else {
                echo json_encode(['success' => false, 'message' => 'Log save failed!']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Balance update failed!']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid Job!']);
    }

} else {
    echo json_encode(['success' => false, 'message' => 'Invalid Request!']);
}
?>