<?php
include "header.php"; 
include "sidebar.php";

$user_id = $u['id'];

// ইমেইল মাস্কিং করার ফাংশন (নিরাপত্তার জন্য)
function maskEmail($email) {
    $parts = explode("@", $email);
    $name = $parts[0];
    $domain = $parts[1];
    $len = strlen($name);
    
    if ($len <= 2) {
        return $name . "***@" . $domain;
    }
    // প্রথম ২টা অক্ষর রেখে বাকিগুলো স্টার করে দেওয়া
    return substr($name, 0, 2) . str_repeat('*', 3) . "@" . $domain;
}

// আপনার রেফার করা ইউজারদের তথ্য আনা
$referredUsersQuery = $conn->query("SELECT fullname, email, created_at, status FROM users WHERE referred_by_id = '$user_id' ORDER BY created_at DESC");
?>

<style>
    body { background: #f4f7fe; }
    
    .ref-container {
        margin-top: 20px;
    }

    /* মোবাইল ফ্রেন্ডলি লিস্ট কার্ড */
    .user-list-card {
        background: #fff;
        border-radius: 20px;
        padding: 5px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.03);
        border: none;
    }

    .user-item {
        display: flex;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #f1f5f9;
        transition: 0.3s;
    }
    
    .user-item:last-child { border-bottom: none; }

    .user-icon {
        width: 45px;
        height: 45px;
        background: #eef2ff;
        color: #4f46e5;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        margin-right: 15px;
        flex-shrink: 0;
    }

    .user-details {
        flex-grow: 1;
        overflow: hidden;
    }

    .user-name {
        font-weight: 700;
        color: #1e293b;
        font-size: 14px;
        margin-bottom: 2px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .user-mail {
        font-size: 12px;
        color: #64748b;
        font-weight: 500;
    }

    .status-area {
        text-align: right;
        flex-shrink: 0;
    }

    .status-badge {
        font-size: 10px;
        font-weight: 800;
        padding: 4px 10px;
        border-radius: 50px;
        text-transform: uppercase;
    }

    .st-active { background: #dcfce7; color: #15803d; }
    .st-inactive { background: #fee2e2; color: #b91c1c; }

    .join-date {
        font-size: 10px;
        color: #94a3b8;
        display: block;
        margin-top: 4px;
    }

    .empty-state {
        text-align: center;
        padding: 50px 20px;
        color: #94a3b8;
    }
</style>

<div class="container pb-5">
    <div class="mt-4 mb-4 d-flex justify-content-between align-items-center">
        <div>
            <h4 class="fw-bold text-dark m-0"><i class="fa-solid fa-users-viewfinder me-2 text-primary"></i>My Team</h4>
            <p class="text-muted small">আপনার আমন্ত্রিত ইউজারদের তালিকা</p>
        </div>
        <div class="badge bg-white text-primary shadow-sm border rounded-pill px-3 py-2">
            Total: <?= $referredUsersQuery->num_rows ?>
        </div>
    </div>

    <div class="user-list-card animate-fade-up">
        <?php if ($referredUsersQuery->num_rows > 0): ?>
            <?php while ($row = $referredUsersQuery->fetch_assoc()): ?>
                <div class="user-item">
                    <div class="user-icon">
                        <i class="fa-solid fa-user-tag"></i>
                    </div>
                    
                    <div class="user-details">
                        <div class="user-name"><?= htmlspecialchars($row['fullname']); ?></div>
                        <div class="user-mail"><?= maskEmail($row['email']); ?></div>
                    </div>

                    <div class="status-area">
                        <?php if ($row['status'] == 'active'): ?>
                            <span class="status-badge st-active">Active</span>
                        <?php else: ?>
                            <span class="status-badge st-inactive">Inactive</span>
                        <?php endif; ?>
                        <span class="join-date"><?= date('d M, y', strtotime($row['created_at'])); ?></span>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="empty-state">
                <i class="fa-solid fa-user-slash fa-3x mb-3 opacity-20"></i>
                <p>আপনি এখনো কাউকে রেফার করেননি!</p>
                <a href="dashboard.php" class="btn btn-primary btn-sm rounded-pill px-4 mt-2">Get Referral Link</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="text-center mt-4">
        <a href="dashboard.php" class="text-decoration-none text-muted small fw-bold">
            <i class="fa-solid fa-arrow-left me-1"></i> Back to Dashboard
        </a>
    </div>
</div>

<?php include "footer.php"; ?>