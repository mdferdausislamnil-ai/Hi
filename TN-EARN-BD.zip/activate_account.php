<?php
session_start();
require_once "config.php";

// লগইন চেক
if (!isset($_SESSION['id']) && !isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// User ID
$user_id = $_SESSION['id'] ?? $_SESSION['user_id'];

// ইউজার তথ্য নাও
$userQuery = $conn->query("SELECT * FROM users WHERE id='$user_id'");
$user = $userQuery->fetch_assoc();

$fullname = $user['fullname'] ?? 'User';
$email = $user['email'] ?? 'user@email.com';

// Activation Fee
$setting = $conn->query("SELECT setting_value FROM admin_settings WHERE setting_key='activation_fee'");
$activation_fee = $setting->fetch_assoc()['setting_value'] ?? 10;

// তোমার RupantorPay API Key
$api_key = "3AOCNLR6mIrHPWgzPkvf8BnQJzNaXfq65kXHVkcMp4ze17S7Fl";

// Domain URL
$domain = "https://earningbdshop.bdlive24.top";

// Payment Data
$postData = [
    "fullname" => $fullname,
    "email" => $email,
    "amount" => (string)$activation_fee,

    "success_url" => $domain . "/payment_success.php",

    "cancel_url" => $domain . "/activate_account.php?error=failed",

    "meta_data" => [
        "user_id" => (string)$user_id,
        "type" => "activation"
    ]
];

// CURL Start
$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_URL => "https://payment.rupantorpay.com/api/payment/checkout",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($postData),
    CURLOPT_HTTPHEADER => [
        "X-API-KEY: " . $api_key,
        "X-CLIENT: " . $_SERVER['HTTP_HOST'],
        "Content-Type: application/json"
    ],
    CURLOPT_SSL_VERIFYPEER => false
]);

$response = curl_exec($ch);
$error = curl_error($ch);
curl_close($ch);

$result = json_decode($response, true);

// Debug (problem হলে দেখতে)
if (!$result) {
    die("API Response Error: " . htmlspecialchars($response));
}

// Payment URL থাকলে Redirect
if (isset($result['payment_url'])) {
    header("Location: " . $result['payment_url']);
    exit();
}

// Error দেখাও
echo "<pre>";
print_r($result);
exit();
?>