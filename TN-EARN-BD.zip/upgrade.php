<?php
include "header.php"; 
include "sidebar.php";

// ডাটাবেস থেকে প্লান আনা
$plans = $conn->query("SELECT * FROM plans WHERE status='active'");

// ইউজার ডাটা
$u_check = $conn->query("SELECT * FROM users WHERE id='{$_SESSION['user_id']}'");
$u = $u_check->fetch_assoc();
?>

<style>
    body { background: #f0f2f5; font-family: 'Poppins', sans-serif; }
    .plan-card {
        background: #fff;
        border-radius: 20px;
        padding: 30px 20px;
        text-align: center;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        transition: 0.3s;
        border: 2px solid transparent;
        position: relative;
        overflow: hidden;
    }
    .plan-card:hover { transform: translateY(-5px); border-color: #6366f1; }
    
    .plan-name { font-size: 22px; font-weight: 800; color: #1e293b; margin-bottom: 10px; }
    .plan-price { font-size: 32px; font-weight: 900; color: #6366f1; margin-bottom: 20px; }
    .plan-price span { font-size: 14px; color: #64748b; font-weight: 500; }
    
    .feature-list { list-style: none; padding: 0; margin-bottom: 25px; }
    .feature-list li { margin-bottom: 10px; color: #475569; font-size: 14px; }
    .feature-list i { color: #10b981; margin-right: 8px; }
    
    .btn-buy {
        background: linear-gradient(135deg, #6366f1, #4f46e5);
        color: #fff; border: none; padding: 12px 30px; border-radius: 50px;
        font-weight: 700; width: 100%; transition: 0.3s; cursor: pointer; text-decoration: none; display: inline-block;
    }
    .btn-buy:hover { box-shadow: 0 5px 15px rgba(99, 102, 241, 0.4); color: #fff; }
    
    .btn-disabled {
        background: #94a3b8; cursor: not-allowed; color: #fff; border: none; padding: 12px 30px; border-radius: 50px; font-weight: 700; width: 100%; display: inline-block;
    }
    
    .current-badge {
        position: absolute; top: 15px; right: 15px; background: #dcfce7; color: #166534; font-size: 10px; padding: 4px 10px; border-radius: 20px; font-weight: 800;
    }
</style>

<div class="container pb-5">
    <div class="mt-4 mb-4 text-center">
        <h3 class="fw-bold text-dark">Premium Membership</h3>
        <p class="text-muted small">বেশি আয়ের জন্য আপনার পছন্দের প্লানটি কিনুন</p>
    </div>

    <div class="row g-4">
        <?php if($plans->num_rows > 0): while($p = $plans->fetch_assoc()): ?>
            <div class="col-md-4">
                <div class="plan-card animate-fade-up">
                    <?php if($u['plan_id'] == $p['id']): ?>
                        <div class="current-badge">ACTIVE PLAN</div>
                    <?php endif; ?>

                    <div class="plan-name"><?= htmlspecialchars($p['name']) ?></div>
                    <div class="plan-price">৳<?= number_format($p['price'], 0) ?> <span>/ <?= $p['validity'] ?? $p['duration_days'] ?> days</span></div>
                    
                    <ul class="feature-list">
                        <li><i class="fa-solid fa-check-circle"></i> Daily Limit: <b><?= $p['daily_limit'] ?? 'N/A' ?></b></li>
                        <li><i class="fa-solid fa-check-circle"></i> Task Rate: <b>৳<?= $p['task_rate'] ?? '0' ?></b></li>
                        <li><i class="fa-solid fa-check-circle"></i> Premium Support</li>
                    </ul>

                    <!-- বাটন লজিক পরিবর্তন করা হয়েছে -->
                    <?php if($u['status'] == 'active'): ?>
                        <!-- সরাসরি pay ফোল্ডারে পাঠানো হচ্ছে plan_id এবং amount সহ -->
                        <a href="pay/index.php?plan_id=<?= $p['id'] ?>&amount=<?= $p['price'] ?>" class="btn-buy">
                            Buy Now <i class="fa-solid fa-arrow-right ms-2"></i>
                        </a>
                    <?php else: ?>
                        <button type="button" class="btn-disabled" onclick="alert('অ্যাকাউন্ট আগে একটিভ করুন!')">
                            Account Inactive
                        </button>
                    <?php endif; ?>
                    
                </div>
            </div>
        <?php endwhile; else: ?>
            <div class="text-center text-muted py-5">কোনো প্লান পাওয়া যায়নি।</div>
        <?php endif; ?>
    </div>
</div>

<?php include "footer.php"; ?>