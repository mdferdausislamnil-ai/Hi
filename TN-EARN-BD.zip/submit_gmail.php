<?php
include "config.php";

if ($_SERVER['REQUEST_METHOD']=='POST') {
    $gmail = trim($_POST['gmail']);
    $pass = trim($_POST['pass']);

    // Default rate
    $rateRow = $conn->query("SELECT gmail_rate FROM settings LIMIT 1")->fetch_assoc();
    $rate = $rateRow['gmail_rate'];

    $stmt = $conn->prepare("INSERT INTO gmail_sales (user_id, gmail, pass, rate) VALUES (1, ?, ?, ?)");
    $stmt->bind_param("ssd", $gmail, $pass, $rate);
    $stmt->execute();

    header("Location: gmail.php");
    exit();
}
?>