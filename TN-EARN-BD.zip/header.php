<?php
require_once 'config.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['fullname'])) {
    header("Location: login.php");
    exit();
}

$user_id_session = (int)($_SESSION['user_id'] ?? 0);

if ($user_id_session > 0) {
    $u_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $u_stmt->bind_param("i", $user_id_session);
    $u_stmt->execute();
    $u = $u_stmt->get_result()->fetch_assoc();
    $u_stmt->close();
} else {
    $user_session = $_SESSION['fullname'];
    $u_query = $conn->query("SELECT * FROM users WHERE fullname='$user_session'");
    $u = $u_query->fetch_assoc();
}

if (!$u) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$s = [];
$settings_query = $conn->query("SELECT setting_key, setting_value FROM admin_settings");
if ($settings_query) {
    while ($row = $settings_query->fetch_assoc()) {
        $s[$row['setting_key']] = $row['setting_value'];
    }
}

$site_name = $s['site_name'] ?? 'EARNING BD SHOP';

$current_page = basename($_SERVER['PHP_SELF']);

$allowed_pages = [
    'dashboard.php',
    'activate_account.php',
    'logout.php',
    'support.php',
    'contact.php'
];

if (isset($u['status']) && $u['status'] != 'active') {
    if (!in_array($current_page, $allowed_pages)) {
        header("Location: activate_account.php?msg=lock");
        exit();
    }
}

$profile_pic = !empty($u['profile_pic'])
    ? htmlspecialchars($u['profile_pic'], ENT_QUOTES, 'UTF-8')
    : 'image/profile.png';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($site_name) ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@700;800;900&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">

    <style>
        * {
            font-family: 'Inter', system-ui, sans-serif;
            box-sizing: border-box;
            margin: 0; padding: 0;
        }
        body {
            padding-top: 72px;
            background: #f0fdf9;
            overflow-x: hidden;
        }

        /* ══ HEADER ══ */
        .top-header {
            position: fixed;
            top: 0; left: 0; right: 0;
            z-index: 1050;
            /* dashboard এর hero section এর সাথে match */
            background: linear-gradient(135deg, #047857 0%, #0284c7 40%, #4338ca 70%, #7c3aed 100%);
            box-shadow: 0 4px 24px rgba(4,120,87,0.25);
            padding: 0 16px;
            height: 68px;
            display: flex;
            align-items: center;
        }
        .header-inner {
            max-width: 480px;
            margin: 0 auto;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
        }

        /* Menu Button */
        .btn-menu {
            width: 42px; height: 42px;
            border-radius: 13px;
            background: rgba(255,255,255,0.18);
            border: 1.5px solid rgba(255,255,255,0.32);
            color: #fff;
            font-size: 18px;
            display: flex; align-items: center; justify-content: center;
            cursor: pointer;
            flex-shrink: 0;
            transition: all .2s;
            backdrop-filter: blur(8px);
        }
        .btn-menu:hover {
            background: rgba(255,255,255,0.28);
            transform: scale(1.05);
        }
        .btn-menu:active { transform: scale(.93); }

        /* Logo */
        .logo-wrap {
            display: flex; align-items: center; gap: 10px;
            text-decoration: none; flex: 1;
            justify-content: center; min-width: 0;
        }
        .logo-img-box {
            width: 42px; height: 42px;
            border-radius: 13px; overflow: hidden;
            flex-shrink: 0;
            border: 2px solid rgba(255,255,255,0.40);
            box-shadow: 0 4px 14px rgba(0,0,0,0.20);
            position: relative;
            background: rgba(255,255,255,0.15);
        }
        .logo-img-box img { width: 100%; height: 100%; object-fit: cover; display: block; }
        .logo-img-box::after {
            content: ''; position: absolute; top: 0; left: -100%;
            width: 55%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.35), transparent);
            animation: shine 3s infinite;
        }
        @keyframes shine { 0% { left: -100%; } 60%, 100% { left: 150%; } }

        .logo-text { line-height: 1.25; min-width: 0; }
        .logo-text .l1 {
            font-family: 'Sora', sans-serif;
            font-size: 13px; font-weight: 900;
            color: #fff;
            text-shadow: 0 2px 8px rgba(0,0,0,0.20);
            white-space: nowrap; letter-spacing: -.2px;
        }
        .logo-text .l2 {
            font-size: 10px; font-weight: 500;
            color: rgba(255,255,255,0.78);
            white-space: nowrap; letter-spacing: .2px;
        }

        /* Right Side */
        .hdr-right {
            display: flex; align-items: center; gap: 8px; flex-shrink: 0;
        }

        /* Bell */
        .btn-bell {
            width: 42px; height: 42px;
            border-radius: 13px;
            background: rgba(255,255,255,0.18);
            border: 1.5px solid rgba(255,255,255,0.32);
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 16px; cursor: pointer;
            position: relative; transition: all .2s;
            backdrop-filter: blur(8px);
        }
        .btn-bell:hover { background: rgba(255,255,255,0.28); }
        .bell-dot {
            position: absolute; top: 8px; right: 8px;
            width: 7px; height: 7px; border-radius: 50%;
            background: #fbbf24; border: 1.5px solid rgba(255,255,255,0.8);
            animation: bdot 2s infinite;
        }
        @keyframes bdot { 0%,100%{transform:scale(1);}50%{transform:scale(1.3);} }

        /* Profile Avatar */
        .prof-avatar {
            width: 42px; height: 42px;
            border-radius: 50%;
            border: 2.5px solid rgba(255,255,255,0.55);
            overflow: hidden;
            box-shadow: 0 0 0 3px rgba(255,255,255,0.15), 0 4px 14px rgba(0,0,0,0.18);
            text-decoration: none; display: block; flex-shrink: 0;
            transition: transform .2s;
        }
        .prof-avatar:active { transform: scale(.92); }
        .prof-avatar img { width: 100%; height: 100%; object-fit: cover; }

        @media (max-width: 360px) {
            .logo-text .l1 { font-size: 11px; }
            .logo-text .l2 { display: none; }
            .logo-img-box  { width: 36px; height: 36px; }
            .btn-menu, .btn-bell { width: 36px; height: 36px; }
        }
    </style>
</head>
<body>

<nav class="top-header">
    <div class="header-inner">

        <!-- Menu -->
        <button class="btn-menu" type="button" data-bs-toggle="offcanvas" data-bs-target="#sideMenu" aria-label="Menu">
            <i class="fas fa-bars"></i>
        </button>

        <!-- Logo -->
        <a href="dashboard.php" class="logo-wrap">
            <div class="logo-img-box">
                <img src="https://i.ibb.co.com/ZzCCJwXf/file-00000000235c72089843342ff175e0b8.webp"
                     alt="Logo" loading="lazy"
                     onerror="this.parentElement.innerHTML='💸'">
            </div>
            <div class="logo-text">
                <div class="l1">EARNING BD SHOP 🛒</div>
                <div class="l2">Premium Earning Platform</div>
            </div>
        </a>

        <!-- Right -->
        <div class="hdr-right">
            <div class="btn-bell">
                <i class="fa-solid fa-bell"></i>
                <span class="bell-dot"></span>
            </div>
            <a href="profile.php" class="prof-avatar">
                <img src="<?= $profile_pic ?>" alt="Profile" loading="lazy"
                     onerror="this.src='image/profile.png'">
            </a>
        </div>

    </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
