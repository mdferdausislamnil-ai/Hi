<?php
include "header.php"; 
include "sidebar.php";

// ডাটাবেস থেকে টপ ১০ জন ইউজার বের করা
$leader_query = $conn->query("SELECT fullname, balance, profile_pic FROM users ORDER BY balance DESC LIMIT 10");
$top_users = [];
while($row = $leader_query->fetch_assoc()) {
    $top_users[] = $row;
}

// প্রোফাইল পিকচার চেক করার উন্নত ফাংশন
function getProfilePic($pic) {
    $default = "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"; // একটি ভালো মানের ডিফল্ট ছবি
    
    if (empty($pic)) {
        return $default;
    }

    // যদি লিংকটি imgbb এর হয় এবং কাজ না করে (আপনার স্ক্রিনশটের সমস্যা ফিক্স)
    if (strpos($pic, 'ibb.co') !== false || strpos($pic, 'imgbb') !== false) {
        // আপনি চাইলে এখানে চেক করতে পারেন, তবে সহজ সমাধান হলো 
        // যদি এটা লোকাল ফাইল না হয় এবং এক্সটার্নাল লিংক হয় যা কাজ করছে না
        // আমরা সরাসরি ডিফল্ট ছবি দেব যদি না ফাইলটি লোকাল হয়।
    }

    // লোকাল ফাইল চেক (Uploads/profile/...)
    if (file_exists($pic)) {
        return $pic;
    } 
    
    // যদি এটি একটি সঠিক URL হয় (http দিয়ে শুরু হয়)
    if (filter_var($pic, FILTER_VALIDATE_URL)) {
        return $pic;
    }

    return $default;
}
?>

<style>
    body { background: #f4f7fe; }
    .podium-container {
        display: flex;
        justify-content: center;
        align-items: flex-end;
        gap: 10px;
        margin-top: 30px;
        margin-bottom: 30px;
        padding: 0 10px;
    }
    
    .podium-box {
        background: #fff;
        border-radius: 20px;
        padding: 20px 10px;
        text-align: center;
        box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        flex: 1;
        position: relative;
    }
    
    .rank-1 { 
        height: 200px; 
        border: 3px solid #ffd700; 
        z-index: 2; 
        transform: scale(1.05);
    }
    .rank-2 { height: 170px; border: 1px solid #e2e8f0; }
    .rank-3 { height: 160px; border: 1px solid #e2e8f0; }

    .podium-img {
        width: 65px;
        height: 65px;
        border-radius: 50%;
        object-fit: cover;
        margin-bottom: 10px;
        background: #f1f5f9;
        border: 2px solid #fff;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    .medal-icon {
        position: absolute;
        top: -18px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 28px;
    }

    .leader-list-card {
        background: #fff;
        border-radius: 25px;
        margin: 0 15px 50px 15px;
        padding: 10px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.04);
    }

    .list-item {
        display: flex;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #f8fafc;
    }
    
    .list-item:last-child { border-bottom: none; }
    
    .user-avatar {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        object-fit: cover;
        margin-right: 15px;
        background: #f1f5f9;
    }
    
    .user-name { flex: 1; font-weight: 700; color: #1e293b; font-size: 15px; }
    .user-balance { font-weight: 800; color: #10b981; font-size: 15px; }
    .rank-label { width: 35px; font-weight: 800; color: #94a3b8; }
</style>

<div class="container">
    <h4 class="text-center mt-5 fw-bold text-dark">
        <span style="font-size: 30px;">🏆</span> Top Leaders
    </h4>

    <div class="podium-container">
        <!-- Rank 2 -->
        <?php if(isset($top_users[1])): ?>
        <div class="podium-box rank-2">
            <span class="medal-icon">🥈</span>
            <img src="<?= getProfilePic($top_users[1]['profile_pic']) ?>" class="podium-img">
            <div class="fw-bold text-dark text-truncate small"><?= htmlspecialchars(explode(' ', $top_users[1]['fullname'])[0]) ?></div>
            <div class="text-success fw-bold">৳<?= number_format($top_users[1]['balance'], 0) ?></div>
        </div>
        <?php endif; ?>

        <!-- Rank 1 -->
        <?php if(isset($top_users[0])): ?>
        <div class="podium-box rank-1">
            <span class="medal-icon">👑</span>
            <img src="<?= getProfilePic($top_users[0]['profile_pic']) ?>" class="podium-img" style="width: 75px; height: 75px;">
            <div class="fw-bold text-dark text-truncate"><?= htmlspecialchars(explode(' ', $top_users[0]['fullname'])[0]) ?></div>
            <div class="text-success fw-bold">৳<?= number_format($top_users[0]['balance'], 0) ?></div>
        </div>
        <?php endif; ?>

        <!-- Rank 3 -->
        <?php if(isset($top_users[2])): ?>
        <div class="podium-box rank-3">
            <span class="medal-icon">🥉</span>
            <img src="<?= getProfilePic($top_users[2]['profile_pic']) ?>" class="podium-img">
            <div class="fw-bold text-dark text-truncate small"><?= htmlspecialchars(explode(' ', $top_users[2]['fullname'])[0]) ?></div>
            <div class="text-success fw-bold">৳<?= number_format($top_users[2]['balance'], 0) ?></div>
        </div>
        <?php endif; ?>
    </div>

    <div class="leader-list-card">
        <?php foreach($top_users as $index => $user): if($index < 3) continue; ?>
            <div class="list-item">
                <div class="rank-label">#<?= $index + 1 ?></div>
                <img src="<?= getProfilePic($user['profile_pic']) ?>" class="user-avatar">
                <div class="user-name"><?= htmlspecialchars($user['fullname']) ?></div>
                <div class="user-balance">৳<?= number_format($user['balance'], 2) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include "footer.php"; ?>