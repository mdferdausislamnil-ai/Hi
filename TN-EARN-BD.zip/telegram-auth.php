<?php
session_start();
include "config.php";

// ডাটা গ্রহণ করা
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['id'])) {
    echo json_encode(['success' => false, 'message' => 'No data received']);
    exit;
}

$telegram_id = mysqli_real_escape_string($conn, $input['id']);
$first_name  = mysqli_real_escape_string($conn, $input['first_name']);
$last_name   = mysqli_real_escape_string($conn, $input['last_name']);
$full_name   = trim($first_name . ' ' . $last_name);
$username    = mysqli_real_escape_string($conn, $input['username'] ?: 'user_'.$telegram_id);

// ১. চেক করুন এই টেলিগ্রাম আইডি দিয়ে ইউজার অলরেডি আছে কি না
$check_user = $conn->query("SELECT * FROM users WHERE telegram_id = '$telegram_id'");

if ($check_user->num_rows > 0) {
    // ইউজার আছে, সেশন সেট করুন
    $user = $check_user->fetch_assoc();
    $_SESSION['fullname'] = $user['fullname'];
    $_SESSION['user_id'] = $user['id']; // আপনার ডাটাবেজের আইডি কলাম অনুযায়ী
    echo json_encode(['success' => true]);
} else {
    // ২. ইউজার নেই, নতুন একাউন্ট তৈরি (Auto Registration)
    // আপনার টেবিলের কলাম অনুযায়ী নিচের INSERT কোয়েরিটি চেক করে নিন
    $sql = "INSERT INTO users (fullname, username, telegram_id, status, created_at) 
            VALUES ('$full_name', '$username', '$telegram_id', 'active', NOW())";
    
    if ($conn->query($sql)) {
        $_SESSION['fullname'] = $full_name;
        $_SESSION['user_id'] = $conn->insert_id;
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    }
}
?>