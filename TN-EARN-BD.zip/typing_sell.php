<?php
session_start();
include "config.php";

if (!isset($_SESSION['fullname'])) {
    echo "❌ সেশন শেষ হয়েছে, দয়া করে লগইন করুন।";
    exit();
}

$user = $_SESSION['fullname'];

// ✅ ইউজার আইডি বের করা
$getUser = $conn->query("SELECT * FROM users WHERE fullname='$user' LIMIT 1");
if ($getUser->num_rows == 0) {
    echo "❌ ইউজার পাওয়া যায়নি!";
    exit();
}

$userData = $getUser->fetch_assoc();
$user_id = $userData['id'];

// ✅ অ্যাডমিনের Typing Job Settings আনো
$settings = $conn->query("SELECT * FROM typing_job_settings WHERE id=1")->fetch_assoc();
$total_lines = $settings['total_lines'];
$rate = $settings['rate_per_line'];

// ✅ আগে ইউজার এই দিনে কাজ করেছে কিনা চেক
$check = $conn->query("SELECT * FROM user_typing WHERE user_id='$user_id' AND DATE(created_at)=CURDATE()");
if ($check->num_rows > 0) {
    echo "⚠️ আজকের লিমিট শেষ! আপনি আজকের কাজ শেষ করেছেন।";
    exit();
}

// ✅ টাকা হিসাব করা
$totalEarn = $total_lines * $rate;

// ✅ ইউজার টেবিলে ব্যালেন্স আপডেট
$update = $conn->query("UPDATE users SET typing_balance = typing_balance + $totalEarn, balance = balance + $totalEarn WHERE id='$user_id'");

// ✅ হিস্টোরি টেবিলে সেভ করা
$conn->query("INSERT INTO user_typing (user_id, lines_completed, earned) VALUES ('$user_id', '$total_lines', '$totalEarn')");

// ✅ সফল বার্তা
if ($update) {
    echo "✅ সফলভাবে সম্পন্ন হয়েছে!<br>💰 আপনার একাউন্টে <b>" . number_format($totalEarn, 2) . "৳</b> যোগ হয়েছে।";
} else {
    echo "❌ ডাটাবেজে সমস্যা হয়েছে, দয়া করে পরে চেষ্টা করুন।";
}
?>