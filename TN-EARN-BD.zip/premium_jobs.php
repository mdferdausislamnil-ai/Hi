<?php
include "header.php"; 
include "sidebar.php";

$user_id = $u['id'];
$plan_id = $u['plan_id'];

// ১. প্লান চেক
if ($plan_id == 0) {
    echo "<script>window.location.href='upgrade.php';</script>";
    exit;
}

// ২. প্লান ডিটেইলস আনা
$planInfo = $conn->query("SELECT * FROM plans WHERE id='$plan_id'")->fetch_assoc();
$daily_limit = $planInfo['daily_limit'];
$task_rate = $planInfo['task_rate'];

// ৩. লিমিট চেক
$limit_over = false;
if ($u['daily_task_count'] >= $daily_limit) {
    $limit_over = true;
}

// ৪. টাস্ক আনা (শুধুমাত্র ইউজারের প্লানের টাস্ক)
$tasks = $conn->query("SELECT * FROM premium_tasks WHERE plan_id='$plan_id' ORDER BY id DESC");
?>

<style>
    body { background: #f8fafc; }
    .pt-card { background: #fff; padding: 15px; border-radius: 15px; border: 1px solid #e2e8f0; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; transition: 0.3s; }
    .pt-card:hover { transform: translateY(-3px); border-color: #6366f1; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
    .limit-box { background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #fff; padding: 20px; border-radius: 15px; text-align: center; margin-bottom: 25px; }
</style>

<div class="container pb-5">
    <div class="mt-4 mb-4">
        <h4 class="fw-bold text-dark"><i class="fa-solid fa-crown text-warning me-2"></i>My Premium Tasks</h4>
    </div>

    <!-- Limit Info -->
    <div class="limit-box animate-fade-up">
        <h4>Current Plan: <?= htmlspecialchars($planInfo['name']) ?></h4>
        <p class="mb-0">Today's Completed: <b><?= $u['daily_task_count'] ?></b> / <?= $daily_limit ?></p>
        <div class="progress mt-2" style="height: 6px;">
            <div class="progress-bar bg-warning" style="width: <?= ($u['daily_task_count'] / $daily_limit) * 100 ?>%"></div>
        </div>
    </div>

    <?php if($limit_over): ?>
        <div class="alert alert-danger text-center rounded-4 py-4">
            <i class="fa-solid fa-ban fa-2x mb-2"></i><br>
            <b>আজকের লিমিট শেষ!</b><br>আগামীকাল আবার চেষ্টা করুন।
        </div>
    <?php else: ?>
        <div class="row">
            <?php if($tasks->num_rows > 0): while($t = $tasks->fetch_assoc()): ?>
                <div class="col-md-12">
                    <div class="pt-card animate-fade-up">
                        <div>
                            <h6 class="fw-bold m-0 text-dark"><?= htmlspecialchars($t['title']) ?></h6>
                            <span class="badge bg-success bg-opacity-10 text-success mt-1">Reward: ৳<?= $task_rate ?></span>
                        </div>
                        <button onclick="claimTask(<?= $t['id'] ?>, '<?= $t['link'] ?>')" class="btn btn-primary btn-sm rounded-pill px-4 fw-bold">
                            View & Claim <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            <?php endwhile; else: ?>
                <div class="text-center text-muted py-5">কোনো টাস্ক নেই।</div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function claimTask(taskId, link) {
    // নতুন উইন্ডোতে লিঙ্ক ওপেন
    window.open(link, '_blank');

    let timerInterval;
    Swal.fire({
        title: 'অপেক্ষা করুন!',
        html: 'টাস্ক ভেরিফাই হচ্ছে... <b>5</b> সেকেন্ড।',
        timer: 5000,
        timerProgressBar: true,
        allowOutsideClick: false,
        didOpen: () => {
            Swal.showLoading();
            const b = Swal.getHtmlContainer().querySelector('b');
            timerInterval = setInterval(() => {
                b.textContent = Math.ceil(Swal.getTimerLeft() / 1000);
            }, 100);
        },
        willClose: () => {
            clearInterval(timerInterval);
        }
    }).then((result) => {
        // AJAX রিকোয়েস্ট পাঠানো টাকা যোগ করার জন্য
        fetch('task_claim_ajax.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'task_id=' + taskId
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                Swal.fire('Success!', data.message, 'success').then(() => location.reload());
            } else {
                Swal.fire('Error!', data.message, 'error');
            }
        });
    });
}
</script>

<?php include "footer.php"; ?>