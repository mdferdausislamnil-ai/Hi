<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
include "header.php";
include "sidebar.php";

if (!isset($u) || empty($u['id'])) {
    header("Location: login.php"); exit;
}

$user_id      = (int)$u['id'];
$main_balance = (float)($u['balance'] ?? 0);

$total_withdraw = 0;
$stmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM withdraws WHERE user_id=? AND status='approved'");
if($stmt){ $stmt->bind_param("i",$user_id); $stmt->execute(); $stmt->bind_result($total_withdraw); $stmt->fetch(); $stmt->close(); }

$pending_withdraw = 0;
$stmt = $conn->prepare("SELECT COALESCE(SUM(amount),0) FROM withdraws WHERE user_id=? AND status='pending'");
if($stmt){ $stmt->bind_param("i",$user_id); $stmt->execute(); $stmt->bind_result($pending_withdraw); $stmt->fetch(); $stmt->close(); }

$total_income    = $main_balance + $total_withdraw + $pending_withdraw;
$notice_text     = $s['notice_text'] ?? 'EARNING BD SHOP-এ আপনাকে স্বাগতম! আজই শুরু করুন।';
$ref_bonus       = $s['referral_bonus'] ?? '25';
$referral_income = (float)($u['referral_income'] ?? 0);
$gmail_income    = (float)($u['gmail_balance'] ?? 0);
$salary_income   = (float)($u['salary_balance'] ?? 0);
$job_income      = (float)($u['job_balance'] ?? 0);
$user_fullname   = htmlspecialchars($u['fullname'] ?? 'User', ENT_QUOTES, 'UTF-8');
$profile_pic     = !empty($u['profile_pic']) ? htmlspecialchars($u['profile_pic'],ENT_QUOTES,'UTF-8') : 'image/profile.png';
$ref_link        = "http://".$_SERVER['HTTP_HOST']."/register.php?ref=".$user_id;
$telegram_group  = $s['telegram_group_link'] ?? '#';
$telegram_channel= $s['telegram_channel_link'] ?? '#';

$user_status = $u['status'] ?? 'inactive';
$is_active   = ($user_status === 'active');
?>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Nunito:wght@400;600;700;800;900&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
/* ════════════════════════════════════════
   ROOT — LIGHT PREMIUM THEME
════════════════════════════════════════ */
:root {
  /* Background */
  --bg-root: #f0f4ff;
  --bg-page: #eef2fb;
  --bg-card: #ffffff;
  --bg-card2: #f7f9ff;
  --bg-input: #f0f4ff;

  /* Primary gradient (hero header) */
  --grad-hero: linear-gradient(135deg, #1a8a6e 0%, #2196a8 40%, #7c3aed 100%);
  --grad-hero2: linear-gradient(135deg, #0f766e, #0e7490, #6d28d9);

  /* Accent colors */
  --c-green:   #10b981;
  --c-teal:    #0891b2;
  --c-purple:  #7c3aed;
  --c-blue:    #2563eb;
  --c-pink:    #ec4899;
  --c-orange:  #f59e0b;
  --c-red:     #ef4444;
  --c-indigo:  #4f46e5;
  --c-cyan:    #06b6d4;
  --c-lime:    #84cc16;

  /* Text */
  --t1: #0f172a;
  --t2: #334155;
  --t3: #64748b;
  --t4: #94a3b8;
  --t-white: #ffffff;

  /* Borders */
  --bord: rgba(148,163,184,0.20);
  --bord2: rgba(148,163,184,0.35);

  /* Shadows */
  --sh-card: 0 2px 20px rgba(15,23,42,0.08), 0 1px 4px rgba(15,23,42,0.04);
  --sh-card-hover: 0 8px 40px rgba(15,23,42,0.14), 0 2px 8px rgba(15,23,42,0.06);
  --sh-btn: 0 4px 16px rgba(124,58,237,0.35);

  /* Radius */
  --r1: 24px;
  --r2: 18px;
  --r3: 14px;
  --r4: 10px;
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'Nunito', 'Hind Siliguri', sans-serif;
  background: var(--bg-page);
  color: var(--t1);
  padding-bottom: 110px;
  min-height: 100vh;
}

/* PAGE LOAD ANIMATION */
.dw { animation: pageIn .45s cubic-bezier(.4,0,.2,1) both; }
@keyframes pageIn { from { opacity:0; transform:translateY(18px); } to { opacity:1; transform:translateY(0); } }

/* CARDS STAGGER */
.ca > * { animation: rise .5s cubic-bezier(.4,0,.2,1) both; }
.ca>*:nth-child(1){animation-delay:.04s} .ca>*:nth-child(2){animation-delay:.08s}
.ca>*:nth-child(3){animation-delay:.12s} .ca>*:nth-child(4){animation-delay:.16s}
.ca>*:nth-child(5){animation-delay:.20s} .ca>*:nth-child(6){animation-delay:.24s}
.ca>*:nth-child(7){animation-delay:.28s} .ca>*:nth-child(8){animation-delay:.32s}
.ca>*:nth-child(9){animation-delay:.36s} .ca>*:nth-child(10){animation-delay:.40s}
@keyframes rise { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }

.dw { max-width: 480px; margin: 0 auto; }

/* ══ PAGE LOADER ══ */
.page-loader {
  position: fixed; top:0; left:0; right:0; height:3px; z-index:9999;
  background: linear-gradient(90deg, var(--c-green), var(--c-teal), var(--c-purple), var(--c-pink));
  background-size: 300% 100%;
  animation: loaderW 1.4s ease forwards, loaderSlide 1s linear infinite;
}
@keyframes loaderW { from{width:0;opacity:1;} to{width:100%;opacity:0;} }
@keyframes loaderSlide { from{background-position:300% 0;} to{background-position:0% 0;} }

/* ══ INACTIVE BANNER ══ */
.inactive-banner {
  margin: 14px 14px 0;
  background: linear-gradient(135deg, #fff1f2, #fef9ee);
  border: 1.5px solid rgba(239,68,68,0.30);
  border-radius: var(--r2);
  padding: 16px 14px;
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  box-shadow: 0 4px 20px rgba(239,68,68,0.12);
  animation: pulseBanner 2.5s ease-in-out infinite;
}
@keyframes pulseBanner {
  0%,100%{ box-shadow:0 4px 20px rgba(239,68,68,0.12); }
  50%{ box-shadow:0 4px 30px rgba(239,68,68,0.28); }
}
.ib-left { display:flex; align-items:center; gap:10px; }
.ib-ico { font-size:24px; flex-shrink:0; }
.ib-txt h4 { font-size:12.5px; font-weight:800; color:#dc2626; margin-bottom:2px; }
.ib-txt p  { font-size:11px; color:#ef4444; opacity:0.8; line-height:1.4; }
.ib-btn {
  flex-shrink:0;
  background: linear-gradient(135deg, #ef4444, #f97316);
  color:#fff; padding:9px 15px; border-radius:50px;
  font-weight:800; font-size:11px; text-decoration:none; white-space:nowrap;
  box-shadow:0 4px 14px rgba(239,68,68,0.40);
  transition:transform .2s, box-shadow .2s;
}
.ib-btn:hover { transform:scale(1.05); box-shadow:0 6px 20px rgba(239,68,68,0.55); }

/* ══ HERO HEADER ══ */
.hero {
  position: relative; overflow: hidden;
  background: var(--grad-hero);
  padding: 26px 18px 90px;
  border-radius: 0 0 40px 40px;
}
.hero::before {
  content:'';position:absolute;inset:0;
  background:
    radial-gradient(ellipse 80% 60% at 0% 0%, rgba(255,255,255,0.12) 0%, transparent 55%),
    radial-gradient(ellipse 60% 50% at 100% 100%, rgba(255,255,255,0.08) 0%, transparent 50%);
}
/* HERO GRID */
.hero::after {
  content:'';position:absolute;inset:0;
  background-image:
    linear-gradient(rgba(255,255,255,0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,0.06) 1px, transparent 1px);
  background-size:36px 36px;
  mask-image:linear-gradient(180deg,transparent,rgba(0,0,0,0.5) 60%,transparent);
}

/* HERO ORBS */
.hero-orb { position:absolute; border-radius:50%; pointer-events:none; }
.hero-orb.o1 {
  width:160px;height:160px;bottom:-70px;left:-50px;
  background:radial-gradient(circle,rgba(255,255,255,0.14),transparent 70%);
}
.hero-orb.o2 {
  width:100px;height:100px;top:-20px;right:8%;
  background:radial-gradient(circle,rgba(255,255,255,0.10),transparent 70%);
}

.hero-inner { position:relative;z-index:2; display:flex;align-items:center;justify-content:space-between;gap:12px; }
.hero-user { display:flex;align-items:center;gap:13px; }

.h-ava {
  width:60px;height:60px;border-radius:50%;flex-shrink:0;
  border:3px solid rgba(255,255,255,0.50);
  overflow:hidden;
  box-shadow:0 0 0 5px rgba(255,255,255,0.15), 0 4px 20px rgba(0,0,0,0.25);
  animation:avaPulse 3s ease-in-out infinite;
}
@keyframes avaPulse {
  0%,100%{box-shadow:0 0 0 5px rgba(255,255,255,0.15),0 4px 20px rgba(0,0,0,0.25);}
  50%{box-shadow:0 0 0 8px rgba(255,255,255,0.08),0 4px 28px rgba(0,0,0,0.35);}
}
.h-ava img { width:100%;height:100%;object-fit:cover; }

.h-greet { font-size:10px;color:rgba(255,255,255,0.80);font-weight:700;letter-spacing:.8px;text-transform:uppercase; }
.h-name  { font-size:18px;font-weight:900;color:#fff;line-height:1.2;margin-top:3px;letter-spacing:.3px; }
.s-pill {
  display:inline-flex;align-items:center;gap:5px;margin-top:5px;
  padding:3px 11px;border-radius:30px;font-size:10px;font-weight:800;
  background:rgba(255,255,255,0.20);border:1px solid rgba(255,255,255,0.35);
  color:#fff;backdrop-filter:blur(8px);
}
.s-pill.inactive-pill { background:rgba(239,68,68,0.25);border-color:rgba(239,68,68,0.50);color:#fca5a5; }
.s-pill .dot { width:6px;height:6px;border-radius:50%;background:#4ade80;animation:dotPulse 1.4s infinite; }
.s-pill.inactive-pill .dot { background:#fca5a5; }
@keyframes dotPulse { 0%,100%{opacity:1;transform:scale(1);} 50%{opacity:.4;transform:scale(.8);} }

.hero-bal {
  display:flex;flex-direction:column;align-items:flex-end;
  background:rgba(255,255,255,0.18);
  border:1.5px solid rgba(255,255,255,0.35);
  border-radius:18px;padding:12px 16px;
  backdrop-filter:blur(20px);
  text-decoration:none;flex-shrink:0;
  transition:all .3s;
  box-shadow:0 4px 20px rgba(0,0,0,0.15),inset 0 1px 0 rgba(255,255,255,0.25);
}
.hero-bal:hover { background:rgba(255,255,255,0.28); transform:translateY(-2px); box-shadow:0 8px 30px rgba(0,0,0,0.20); }
.hb-lbl { font-size:9px;color:rgba(255,255,255,0.80);font-weight:800;letter-spacing:.7px;text-transform:uppercase; }
.hb-val { font-size:22px;font-weight:900;color:#fff;line-height:1.2;margin-top:3px;text-shadow:0 2px 10px rgba(0,0,0,0.20); }

/* ══ CARDS AREA ══ */
.ca { padding:0 14px 4px; margin-top:-65px; position:relative;z-index:10; overflow:visible; }

/* BASE CARD */
.gp {
  background:var(--bg-card);
  border:1.5px solid var(--bord);
  border-radius:var(--r1);
  box-shadow:var(--sh-card);
  margin-bottom:14px;
  overflow:hidden;
  transition:box-shadow .3s, border-color .3s;
}
.gp:hover { box-shadow:var(--sh-card-hover); border-color:var(--bord2); }

/* ══ SITE AGE ══ */
.age-wrap { padding:18px 18px 16px; }
.age-row { display:flex;align-items:center;justify-content:space-between;margin-bottom:14px; }
.age-lbl { display:flex;align-items:center;gap:7px;font-size:13px;font-weight:800;color:var(--t1); }
.age-lbl i { color:var(--c-teal); }
.live-badge {
  display:flex;align-items:center;gap:5px;
  background:linear-gradient(135deg,#d1fae5,#a7f3d0);
  color:#065f46;font-size:10px;font-weight:800;
  padding:3px 11px;border-radius:30px;
  border:1px solid rgba(16,185,129,0.30);
}
.live-badge::before { content:'';width:6px;height:6px;border-radius:50%;background:#10b981;animation:dotPulse 1.4s infinite; }

.age-units { display:flex;gap:7px;align-items:center; }
.au {
  flex:1;text-align:center;
  background:linear-gradient(145deg,#f0f9ff,#e0f2fe);
  border:1.5px solid rgba(14,165,233,0.20);
  border-radius:14px;padding:12px 4px 10px;
  transition:transform .2s, box-shadow .2s;
}
.au:hover { transform:translateY(-3px); box-shadow:0 6px 20px rgba(14,165,233,0.20); }
.au-n { display:block;font-size:22px;font-weight:900;color:var(--c-teal);line-height:1; }
.au-l { display:block;font-size:9px;font-weight:700;color:var(--t3);margin-top:4px;text-transform:uppercase;letter-spacing:.4px; }
.au-sep { font-size:18px;font-weight:900;color:var(--c-teal);margin-bottom:16px;flex-shrink:0;opacity:0.5; }

/* ══ NOTICE BAR ══ */
.notice-bar {
  display:flex;align-items:center;gap:10px;
  background:linear-gradient(135deg,#fffbeb,#fef3c7);
  border:1.5px solid rgba(245,158,11,0.30);
  border-radius:16px;padding:11px 14px;
  margin-bottom:14px;
  box-shadow:0 2px 12px rgba(245,158,11,0.12);
  position:relative;overflow:hidden;
  animation:noticePulse 3s ease-in-out infinite;
}
@keyframes noticePulse {
  0%,100%{box-shadow:0 2px 12px rgba(245,158,11,0.12);}
  50%{box-shadow:0 2px 24px rgba(245,158,11,0.28);}
}
/* animated border shimmer */
.notice-bar::before {
  content:'';position:absolute;top:0;left:-100%;width:60%;height:2px;
  background:linear-gradient(90deg,transparent,rgba(245,158,11,0.80),transparent);
  animation:shimmer 2.5s linear infinite;
}
@keyframes shimmer { to{left:160%;} }
.n-ico {
  width:38px;height:38px;flex-shrink:0;border-radius:12px;
  background:linear-gradient(135deg,#f59e0b,#d97706);
  display:flex;align-items:center;justify-content:center;font-size:15px;color:#fff;
  box-shadow:0 4px 14px rgba(245,158,11,0.40);
  animation:speakerGlow 2s ease-in-out infinite;
}
@keyframes speakerGlow {
  0%,100%{box-shadow:0 4px 14px rgba(245,158,11,0.40);}
  50%{box-shadow:0 4px 24px rgba(245,158,11,0.70),0 0 40px rgba(245,158,11,0.20);}
}
.notice-bar marquee { font-size:12.5px;font-weight:700;color:#92400e; }

/* ══ SLIDER ══ */
.slider {
  height:190px;border-radius:var(--r1);overflow:hidden;position:relative;
  margin-bottom:14px;
  box-shadow:0 6px 30px rgba(15,23,42,0.14);
}
.slide { width:100%;height:100%;position:absolute;top:0;left:0;opacity:0;transition:opacity .9s ease;object-fit:cover; }
.slide.on { opacity:1; }
.slider-ov {
  position:absolute;inset:0;z-index:1;
  background:linear-gradient(180deg,transparent 40%,rgba(15,23,42,0.40) 100%);
  pointer-events:none;
}
.sdots { position:absolute;bottom:12px;left:50%;transform:translateX(-50%);display:flex;gap:6px;z-index:2; }
.sd {
  height:4px;width:6px;border-radius:3px;
  background:rgba(255,255,255,0.45);transition:all .35s;cursor:pointer;
}
.sd.a { width:22px;background:#fff;box-shadow:0 0 8px rgba(255,255,255,0.8); }

/* ══ SECTION TITLE ══ */
.sec-title {
  display:flex;align-items:center;gap:9px;
  font-size:14px;font-weight:900;color:var(--t1);
  margin-bottom:16px;letter-spacing:.2px;
}
.sec-title i { color:var(--c-purple);font-size:14px; }
.sec-title .line { flex:1;height:1.5px;background:linear-gradient(90deg,rgba(124,58,237,0.20),transparent); }

/* ══ EARNINGS OVERVIEW ══ */

/* OUTER WRAPPER — animated rainbow glow border */
.earn-section-wrap {
  position: relative;
  border-radius: 22px;
  padding: 3px; /* border thickness */
  background: linear-gradient(135deg,#10b981,#3b82f6,#8b5cf6,#f59e0b,#ef4444,#10b981);
  background-size: 300% 300%;
  animation: earnGlow 4s linear infinite;
  box-shadow:
    0 0 18px rgba(16,185,129,0.30),
    0 0 36px rgba(59,130,246,0.18),
    0 0 54px rgba(139,92,246,0.12);
  margin-bottom: 14px;
}
@keyframes earnGlow {
  0%   { background-position:0% 50%;   box-shadow:0 0 20px rgba(16,185,129,0.45),0 0 40px rgba(16,185,129,0.18); }
  25%  { background-position:50% 0%;   box-shadow:0 0 20px rgba(59,130,246,0.45),0 0 40px rgba(59,130,246,0.18); }
  50%  { background-position:100% 50%; box-shadow:0 0 20px rgba(139,92,246,0.45),0 0 40px rgba(139,92,246,0.18); }
  75%  { background-position:50% 100%; box-shadow:0 0 20px rgba(245,158,11,0.45),0 0 40px rgba(245,158,11,0.18); }
  100% { background-position:0% 50%;   box-shadow:0 0 20px rgba(16,185,129,0.45),0 0 40px rgba(16,185,129,0.18); }
}
.earn-section-wrap .gp {
  border-radius: 20px;
  margin-bottom: 0; /* remove double margin */
  border: none;     /* border is handled by wrapper */
}

/* GRID — 2 column, no overflow */
.earn-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 12px 14px 16px;
}

.ec {
  border-radius: 14px;
  padding: 12px 10px;
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;        /* CRITICAL: prevents overflow */
  overflow: hidden;
  transition: transform .25s, box-shadow .25s;
  cursor: default;
  position: relative;
}
.ec:hover { transform: translateY(-3px); }

.ec.e1 { background:linear-gradient(135deg,#ecfdf5,#d1fae5); border:1.5px solid rgba(16,185,129,0.30); }
.ec.e1:hover { box-shadow:0 8px 28px rgba(16,185,129,0.30); }
.ec.e2 { background:linear-gradient(135deg,#eff6ff,#dbeafe); border:1.5px solid rgba(37,99,235,0.25); }
.ec.e2:hover { box-shadow:0 8px 28px rgba(37,99,235,0.25); }
.ec.e3 { background:linear-gradient(135deg,#fffbeb,#fef3c7); border:1.5px solid rgba(245,158,11,0.30); }
.ec.e3:hover { box-shadow:0 8px 28px rgba(245,158,11,0.28); }
.ec.e4 { background:linear-gradient(135deg,#faf5ff,#ede9fe); border:1.5px solid rgba(124,58,237,0.25); }
.ec.e4:hover { box-shadow:0 8px 28px rgba(124,58,237,0.25); }

/* Animated top shimmer line per card */
.ec::before {
  content:''; position:absolute; top:0; left:-100%; width:60%; height:2px;
  animation: ecShimmer 3s linear infinite;
}
.ec.e1::before { background:linear-gradient(90deg,transparent,rgba(16,185,129,0.80),transparent); }
.ec.e2::before { background:linear-gradient(90deg,transparent,rgba(37,99,235,0.80),transparent); animation-delay:.8s; }
.ec.e3::before { background:linear-gradient(90deg,transparent,rgba(245,158,11,0.80),transparent); animation-delay:1.6s; }
.ec.e4::before { background:linear-gradient(90deg,transparent,rgba(139,92,246,0.80),transparent); animation-delay:2.4s; }
@keyframes ecShimmer { to { left: 160%; } }

.ec-ico {
  width: 40px; height: 40px;
  flex-shrink: 0;
  border-radius: 12px;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px; color: #fff;
}
.e1 .ec-ico{background:linear-gradient(135deg,#10b981,#059669);box-shadow:0 4px 14px rgba(16,185,129,0.45);}
.e2 .ec-ico{background:linear-gradient(135deg,#3b82f6,#1d4ed8);box-shadow:0 4px 14px rgba(59,130,246,0.45);}
.e3 .ec-ico{background:linear-gradient(135deg,#f59e0b,#d97706);box-shadow:0 4px 14px rgba(245,158,11,0.45);}
.e4 .ec-ico{background:linear-gradient(135deg,#8b5cf6,#6d28d9);box-shadow:0 4px 14px rgba(139,92,246,0.45);}

/* Text container — must shrink */
.ec-txt { min-width:0; overflow:hidden; }
.ec-val {
  font-size: 13px; font-weight: 800; color: var(--t1);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.ec-lbl {
  font-size: 10px; font-weight: 600; color: var(--t3);
  margin-top: 1px; white-space: nowrap;
}

/* ══ MENU GLOW WRAPPER ══ */
.menu-glow-wrap {
  position: relative;
  border-radius: 26px;
  padding: 3px;
  background: linear-gradient(135deg, #1877f2, #a855f7, #10b981, #f59e0b, #ef4444, #06b6d4, #1877f2);
  background-size: 400% 400%;
  animation: menuGlow 5s linear infinite;
  box-shadow:
    0 0 22px rgba(24,119,242,0.28),
    0 0 44px rgba(168,85,247,0.15),
    0 0 66px rgba(16,185,129,0.10);
  margin-bottom: 14px;
}
@keyframes menuGlow {
  0%   { background-position:0% 50%;   box-shadow:0 0 24px rgba(24,119,242,0.40),0 0 48px rgba(24,119,242,0.15); }
  20%  { background-position:25% 0%;   box-shadow:0 0 24px rgba(168,85,247,0.40),0 0 48px rgba(168,85,247,0.15); }
  40%  { background-position:75% 25%;  box-shadow:0 0 24px rgba(16,185,129,0.40),0 0 48px rgba(16,185,129,0.15); }
  60%  { background-position:100% 50%; box-shadow:0 0 24px rgba(245,158,11,0.40),0 0 48px rgba(245,158,11,0.15); }
  80%  { background-position:50% 100%; box-shadow:0 0 24px rgba(239,68,68,0.40),0 0 48px rgba(239,68,68,0.15); }
  100% { background-position:0% 50%;   box-shadow:0 0 24px rgba(24,119,242,0.40),0 0 48px rgba(24,119,242,0.15); }
}
.menu-glow-wrap .gp {
  border-radius: 24px;
  margin-bottom: 0;
  border: none;
}

/* ══ MENU GRID ══ */
.mg-wrap { padding:20px 16px 22px; }
.mg { display:grid;grid-template-columns:repeat(4,1fr);gap:18px 8px; }

.mi {
  display:flex;flex-direction:column;align-items:center;gap:8px;
  text-decoration:none;
  transition:transform .22s cubic-bezier(.34,1.56,.64,1);
}
.mi:active { transform:scale(.86); }

.mi-ico {
  width:58px;height:58px;border-radius:18px;
  display:flex;align-items:center;justify-content:center;
  font-size:23px;color:#fff;position:relative;
  transition:transform .28s cubic-bezier(.34,1.56,.64,1), box-shadow .28s;
}
/* Glass shine overlay */
.mi-ico::after {
  content:'';position:absolute;inset:0;border-radius:18px;
  background:linear-gradient(145deg,rgba(255,255,255,0.30) 0%,transparent 55%);
  z-index:1;pointer-events:none;
}
.mi:hover .mi-ico { transform:translateY(-6px) scale(1.12); }
.mi-lbl { font-size:10px;font-weight:700;color:var(--t2);text-align:center;line-height:1.3; }

/* BADGE */
.cbadge {
  position:absolute;top:-7px;right:-10px;z-index:10;
  background:linear-gradient(135deg,#f59e0b,#ef4444);
  color:#fff;font-size:7px;font-weight:900;
  padding:2px 5px;border-radius:7px;white-space:nowrap;
  box-shadow:0 2px 8px rgba(239,68,68,0.45);line-height:1.4;
  animation:badgePop .5s cubic-bezier(.34,1.56,.64,1);
}
@keyframes badgePop{from{transform:scale(0);}to{transform:scale(1);}}

/* ─── ICON GRADIENTS ─── */
.g-fb{background:linear-gradient(145deg,#1877f2,#0d4fc7);box-shadow:0 6px 22px rgba(24,119,242,0.45);}
.g-mail{background:linear-gradient(145deg,#ea4335,#c0392b);box-shadow:0 6px 22px rgba(234,67,53,0.45);}
.g-insta{background:linear-gradient(145deg,#f9175c,#a855f7,#4f46e5);box-shadow:0 6px 22px rgba(168,85,247,0.45);}
.g-coin{background:linear-gradient(145deg,#f59e0b,#b45309);box-shadow:0 6px 22px rgba(245,158,11,0.45);}
.g-sal{background:linear-gradient(145deg,#10b981,#059669);box-shadow:0 6px 22px rgba(16,185,129,0.40);}
.g-tgt{background:linear-gradient(145deg,#7c3aed,#1d4ed8);box-shadow:0 6px 22px rgba(124,58,237,0.45);}
.g-visit{background:linear-gradient(145deg,#06b6d4,#0284c7);box-shadow:0 6px 22px rgba(6,182,212,0.45);}
.g-type{background:linear-gradient(145deg,#475569,#1e293b);box-shadow:0 6px 22px rgba(71,85,105,0.40);}
.g-upgrade{background:linear-gradient(145deg,#8b5cf6,#4c1d95);box-shadow:0 6px 22px rgba(139,92,246,0.45);}
.g-pjob{background:linear-gradient(145deg,#f59e0b,#92400e);box-shadow:0 6px 22px rgba(245,158,11,0.45);}
.g-rjob{background:linear-gradient(145deg,#38bdf8,#0369a1);box-shadow:0 6px 22px rgba(56,189,248,0.45);}
.g-jhist{background:linear-gradient(145deg,#06b6d4,#0c4a6e);box-shadow:0 6px 22px rgba(6,182,212,0.45);}
.g-gift{background:linear-gradient(145deg,#f43f5e,#be123c);box-shadow:0 6px 22px rgba(244,63,94,0.45);}
.g-wd{background:linear-gradient(145deg,#ef4444,#991b1b);box-shadow:0 6px 22px rgba(239,68,68,0.45);}
.g-payhist{background:linear-gradient(145deg,#10b981,#0891b2);box-shadow:0 6px 22px rgba(16,185,129,0.40);}
.g-ref{background:linear-gradient(145deg,#3b82f6,#1d4ed8);box-shadow:0 6px 22px rgba(59,130,246,0.45);}
.g-sal2{background:linear-gradient(145deg,#06b6d4,#0369a1);box-shadow:0 6px 22px rgba(6,182,212,0.45);}
.g-lead{background:linear-gradient(145deg,#f59e0b,#b45309);box-shadow:0 6px 22px rgba(245,158,11,0.45);}
.g-prof{background:linear-gradient(145deg,#0891b2,#0e7490);box-shadow:0 6px 22px rgba(8,145,178,0.45);}
.g-sup{background:linear-gradient(145deg,#10b981,#0d9488);box-shadow:0 6px 22px rgba(16,185,129,0.40);}
.g-ads{background:linear-gradient(145deg,#f43f5e,#be123c);box-shadow:0 6px 22px rgba(244,63,94,0.45);}
.g-calc{background:linear-gradient(145deg,#3b82f6,#1e3a8a);box-shadow:0 6px 22px rgba(59,130,246,0.45);}
.g-myjob{background:linear-gradient(145deg,#22c55e,#15803d);box-shadow:0 6px 22px rgba(34,197,94,0.45);}

/* HOVER GLOW — LIGHT VERSION */
.mi:hover .g-fb{box-shadow:0 10px 32px rgba(24,119,242,0.55);}
.mi:hover .g-mail{box-shadow:0 10px 32px rgba(234,67,53,0.55);}
.mi:hover .g-insta{box-shadow:0 10px 32px rgba(168,85,247,0.55);}
.mi:hover .g-coin{box-shadow:0 10px 32px rgba(245,158,11,0.55);}
.mi:hover .g-sal{box-shadow:0 10px 32px rgba(16,185,129,0.50);}
.mi:hover .g-upgrade{box-shadow:0 10px 32px rgba(139,92,246,0.55);}
.mi:hover .g-wd{box-shadow:0 10px 32px rgba(239,68,68,0.55);}
.mi:hover .g-gift{box-shadow:0 10px 32px rgba(244,63,94,0.55);}
.mi:hover .g-lead{box-shadow:0 10px 32px rgba(245,158,11,0.55);}
.mi:hover .g-sup{box-shadow:0 10px 32px rgba(16,185,129,0.50);}
.mi:hover .g-myjob{box-shadow:0 10px 32px rgba(34,197,94,0.50);}
.mi:hover .g-pjob{box-shadow:0 10px 32px rgba(245,158,11,0.55);}
.mi:hover .g-rjob{box-shadow:0 10px 32px rgba(56,189,248,0.55);}

/* ══ PACKAGE GLOW WRAPPER ══ */
.pkg-glow-wrap {
  position: relative;
  border-radius: 26px;
  padding: 3px;
  background: linear-gradient(135deg, #10b981, #3b82f6, #8b5cf6, #f59e0b, #10b981);
  background-size: 300% 300%;
  animation: pkgGlow 4.5s linear infinite;
  box-shadow:
    0 0 22px rgba(16,185,129,0.30),
    0 0 44px rgba(59,130,246,0.15),
    0 0 66px rgba(139,92,246,0.10);
  margin-bottom: 14px;
}
@keyframes pkgGlow {
  0%   { background-position:0% 50%;   box-shadow:0 0 24px rgba(16,185,129,0.45),0 0 48px rgba(16,185,129,0.18); }
  33%  { background-position:100% 0%;  box-shadow:0 0 24px rgba(59,130,246,0.45),0 0 48px rgba(59,130,246,0.18); }
  66%  { background-position:50% 100%; box-shadow:0 0 24px rgba(139,92,246,0.45),0 0 48px rgba(139,92,246,0.18); }
  100% { background-position:0% 50%;   box-shadow:0 0 24px rgba(245,158,11,0.45),0 0 48px rgba(245,158,11,0.18); }
}
.pkg-glow-wrap .gp {
  border-radius: 24px;
  margin-bottom: 0;
  border: none;
}

/* ══ PACKAGE ══ */
.pkg-wrap { padding:20px 16px 22px; }
.pkg-grid { display:grid;grid-template-columns:1fr 1fr;gap:12px; }
.pkg {
  border-radius:var(--r2);padding:18px 14px;
  position:relative;overflow:hidden;cursor:pointer;
  text-decoration:none;
  transition:transform .26s,box-shadow .26s;
  background:var(--bg-card2);
  border:1.5px solid var(--bord);
  box-shadow:var(--sh-card);
}
.pkg:hover { transform:translateY(-5px);box-shadow:var(--sh-card-hover); }
.pkg.p1{background:linear-gradient(145deg,#ecfdf5,#d1fae5);border-color:rgba(16,185,129,0.25);}
.pkg.p2{background:linear-gradient(145deg,#eff6ff,#dbeafe);border-color:rgba(37,99,235,0.20);}
.pkg.p3{background:linear-gradient(145deg,#fdf4ff,#f3e8ff);border-color:rgba(139,92,246,0.20);}
.pkg.p4{background:linear-gradient(145deg,#fffbeb,#fef3c7);border-color:rgba(245,158,11,0.25);}
.pkg:hover::before {
  content:'';position:absolute;inset:0;border-radius:var(--r2);
  background:rgba(255,255,255,0.40);pointer-events:none;
}
.pkg-inner { position:relative;z-index:2; }
.pkg-ico {
  width:44px;height:44px;border-radius:14px;
  display:flex;align-items:center;justify-content:center;
  font-size:19px;color:#fff;margin-bottom:10px;
}
.p1 .pkg-ico{background:linear-gradient(135deg,#10b981,#059669);box-shadow:0 4px 14px rgba(16,185,129,0.40);}
.p2 .pkg-ico{background:linear-gradient(135deg,#3b82f6,#1d4ed8);box-shadow:0 4px 14px rgba(59,130,246,0.40);}
.p3 .pkg-ico{background:linear-gradient(135deg,#8b5cf6,#6d28d9);box-shadow:0 4px 14px rgba(139,92,246,0.40);}
.p4 .pkg-ico{background:linear-gradient(135deg,#f59e0b,#d97706);box-shadow:0 4px 14px rgba(245,158,11,0.45);}
.pkg-title{font-size:13px;font-weight:800;color:var(--t1);margin-bottom:3px;}
.pkg-earn{font-size:11px;font-weight:600;color:var(--t3);margin-bottom:9px;}
.pkg-btn{display:inline-block;padding:5px 13px;border-radius:30px;font-size:10px;font-weight:800;color:#fff;background:linear-gradient(135deg,#10b981,#059669);}
.p2 .pkg-btn{background:linear-gradient(135deg,#3b82f6,#1d4ed8);}
.p3 .pkg-btn{background:linear-gradient(135deg,#8b5cf6,#6d28d9);}
.p4 .pkg-btn{background:linear-gradient(135deg,#f59e0b,#d97706);}

/* ══ REFERRAL CARD ══ */
.ref-card {
  background:var(--bg-card);
  border:1.5px solid var(--bord);
  border-radius:var(--r1);padding:22px 20px;margin-bottom:14px;
  position:relative;overflow:hidden;
  box-shadow:var(--sh-card);
}
.ref-card::before {
  content:'';position:absolute;top:0;left:0;right:0;height:3px;
  background:linear-gradient(90deg,var(--c-green),var(--c-teal),var(--c-purple),var(--c-pink),var(--c-orange));
  background-size:200% 100%;
  animation:shimmer2 3s linear infinite;
}
@keyframes shimmer2{from{background-position:200% 0;}to{background-position:-200% 0;}}
.ref-hd{display:flex;align-items:center;gap:8px;margin-bottom:4px;}
.ref-hd h3{font-size:14px;font-weight:900;color:var(--t1);}
.ref-hd i{color:var(--c-pink);}
.ref-sub{font-size:12.5px;color:var(--t3);margin-bottom:14px;line-height:1.6;}
.ref-bonus{
  display:inline-block;
  background:linear-gradient(135deg,#fffbeb,#fef3c7);
  color:#92400e;font-size:12.5px;font-weight:900;
  padding:1px 10px;border-radius:20px;margin-left:3px;
  border:1px solid rgba(245,158,11,0.35);
}
.ref-inp-row{
  display:flex;
  background:var(--bg-input);
  border:1.5px solid rgba(14,165,233,0.25);
  border-radius:12px;overflow:hidden;margin-bottom:12px;
}
.ref-inp-row input{
  flex:1;border:none;background:transparent;
  padding:11px 13px;font-size:11.5px;font-weight:700;
  color:var(--c-teal);outline:none;font-family:'Nunito',sans-serif;
}
.ref-copy-btn{
  background:linear-gradient(135deg,#06b6d4,#10b981);
  color:#fff;border:none;padding:0 17px;font-size:15px;cursor:pointer;
  transition:filter .2s;
}
.ref-copy-btn:hover{filter:brightness(1.12);}
.ref-btns{display:flex;gap:9px;}
.rbtn{
  flex:1;display:flex;align-items:center;justify-content:center;gap:6px;
  padding:11px 8px;border-radius:12px;font-size:11.5px;font-weight:800;
  color:#fff;text-decoration:none;border:none;cursor:pointer;
  transition:transform .18s,box-shadow .2s;font-family:'Nunito',sans-serif;
}
.rbtn:active{transform:scale(.94);}
.rbtn-cp{background:linear-gradient(135deg,#06b6d4,#8b5cf6);box-shadow:0 4px 14px rgba(6,182,212,0.30);}
.rbtn-cp:hover{box-shadow:0 6px 22px rgba(6,182,212,0.50);}
.rbtn-tg{background:linear-gradient(135deg,#0088cc,#0369a1);box-shadow:0 4px 14px rgba(0,136,204,0.30);}
.rbtn-team{background:linear-gradient(135deg,#10b981,#06b6d4);box-shadow:0 4px 14px rgba(16,185,129,0.30);}
.rbtn-team:hover{box-shadow:0 6px 22px rgba(16,185,129,0.45);}

/* ══ LEADERBOARD ══ */
.lb-card {
  background:var(--bg-card);
  border:1.5px solid rgba(245,158,11,0.20);
  border-radius:var(--r1);padding:22px 20px;margin-bottom:14px;
  box-shadow:var(--sh-card);
  position:relative;overflow:hidden;
}
.lb-card::before {
  content:'';position:absolute;inset:0;
  background:linear-gradient(135deg,rgba(255,251,235,0.60),rgba(255,255,255,0.30));
  pointer-events:none;
}
.lb-head{display:flex;align-items:center;gap:12px;margin-bottom:20px;position:relative;}
.lb-crown{
  width:48px;height:48px;flex-shrink:0;border-radius:50%;
  background:linear-gradient(135deg,#fbbf24,#f59e0b);
  display:flex;align-items:center;justify-content:center;font-size:22px;
  box-shadow:0 4px 18px rgba(245,158,11,0.45);
  animation:crownGlow 2.5s infinite;
}
@keyframes crownGlow {
  0%,100%{box-shadow:0 4px 18px rgba(245,158,11,0.45);}
  50%{box-shadow:0 4px 32px rgba(245,158,11,0.75),0 0 50px rgba(245,158,11,0.25);}
}
.lb-head-t h3{font-size:15px;font-weight:900;color:var(--t1);}
.lb-head-t p{font-size:12px;color:var(--t3);margin-top:2px;}
.lb-podium{display:flex;align-items:flex-end;justify-content:center;gap:12px;margin-bottom:18px;position:relative;}
.lp{display:flex;flex-direction:column;align-items:center;gap:6px;}
.lp-medal{font-size:16px;}
.lp-ava{border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;border:2px solid;}
.lp1 .lp-ava{width:58px;height:58px;background:linear-gradient(135deg,#fef9c3,#fef3c7);border-color:rgba(245,158,11,0.60);box-shadow:0 4px 18px rgba(245,158,11,0.30);}
.lp2 .lp-ava{width:48px;height:48px;background:#f1f5f9;border-color:rgba(148,163,184,0.40);}
.lp3 .lp-ava{width:44px;height:44px;background:#fff7ed;border-color:rgba(180,83,9,0.35);}
.lp-bar{width:100%;border-radius:6px 6px 0 0;min-width:52px;}
.lp1 .lp-bar{height:52px;background:linear-gradient(180deg,rgba(253,230,138,0.70),rgba(253,230,138,0.10));}
.lp2 .lp-bar{height:36px;background:linear-gradient(180deg,rgba(203,213,225,0.60),rgba(203,213,225,0.05));}
.lp3 .lp-bar{height:30px;background:linear-gradient(180deg,rgba(253,186,116,0.60),rgba(253,186,116,0.05));}
.lp-name{font-size:10px;font-weight:700;color:var(--t2);}
.lp-amt{font-size:11px;font-weight:900;}
.lp1 .lp-amt{color:#d97706;}
.lp2 .lp-amt{color:#64748b;}
.lp3 .lp-amt{color:#b45309;}
.lb-link{
  display:flex;align-items:center;justify-content:center;gap:8px;
  background:linear-gradient(135deg,#fffbeb,#fef3c7);
  border:1.5px solid rgba(245,158,11,0.30);
  color:#92400e;text-decoration:none;
  padding:13px;border-radius:14px;font-size:13px;font-weight:800;
  transition:all .25s;position:relative;
}
.lb-link:hover{box-shadow:0 6px 22px rgba(245,158,11,0.30);border-color:rgba(245,158,11,0.55);}

/* ══ TELEGRAM ══ */
.tg-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;}
.tgc{
  background:var(--bg-card);
  border:1.5px solid rgba(0,136,204,0.18);
  border-radius:var(--r1);padding:20px 14px;
  text-align:center;text-decoration:none;display:block;
  box-shadow:var(--sh-card);
  transition:transform .25s,box-shadow .25s,border-color .25s;
}
.tgc:hover{transform:translateY(-5px);box-shadow:0 10px 32px rgba(0,136,204,0.22);border-color:rgba(0,136,204,0.40);}
.tg-ico{
  width:50px;height:50px;
  background:linear-gradient(135deg,#0088cc,#0369a1);
  border-radius:16px;display:flex;align-items:center;justify-content:center;
  font-size:22px;color:#fff;margin:0 auto 10px;
  box-shadow:0 5px 18px rgba(0,136,204,0.40);
  transition:box-shadow .25s;
}
.tgc:hover .tg-ico{box-shadow:0 5px 26px rgba(0,136,204,0.60);}
.tg-name{font-weight:800;color:var(--t1);font-size:13px;margin-bottom:8px;}
.tg-btn{background:linear-gradient(135deg,#0088cc,#0369a1);color:#fff;padding:6px 18px;border-radius:30px;font-weight:700;font-size:11px;display:inline-block;}

/* ══ MODALS ══ */
.overlay{
  position:fixed;inset:0;
  background:rgba(15,23,42,0.60);
  backdrop-filter:blur(16px);
  z-index:999;display:none;align-items:center;justify-content:center;padding:20px;
}
.overlay.show{display:flex;animation:fadein .25s ease;}
@keyframes fadein{from{opacity:0;}to{opacity:1;}}

.tg-popup{
  background:#fff;border:1.5px solid rgba(0,136,204,0.20);
  border-radius:28px;max-width:340px;width:100%;overflow:hidden;
  box-shadow:0 24px 70px rgba(15,23,42,0.25);
  animation:popbounce .42s cubic-bezier(.34,1.56,.64,1);
}
@keyframes popbounce{from{transform:translateY(44px) scale(.87);opacity:0;}to{transform:translateY(0) scale(1);opacity:1;}}

.tg-popup-top{
  background:linear-gradient(135deg,#0f766e,#0e7490,#6d28d9);
  padding:30px 24px 22px;text-align:center;position:relative;overflow:hidden;
  border-bottom:1px solid rgba(255,255,255,0.15);
}
.tg-popup-top::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(ellipse 80% 60% at 50% 0%,rgba(255,255,255,0.18),transparent);
}
.tp-ico{
  width:66px;height:66px;
  background:rgba(255,255,255,0.20);
  border:2px solid rgba(255,255,255,0.40);
  border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-size:30px;margin:0 auto 13px;position:relative;z-index:1;
}
.tg-popup-top h2{font-size:17px;font-weight:900;color:#fff;line-height:1.4;position:relative;z-index:1;}
.tg-popup-top p{font-size:12px;color:rgba(255,255,255,0.75);margin-top:5px;position:relative;z-index:1;}
.tg-popup-body{padding:22px 20px 20px;}
.tg-popup-body p{font-size:13px;color:var(--t3);text-align:center;line-height:1.7;margin-bottom:18px;}
.ptg-btn{
  display:flex;align-items:center;justify-content:center;gap:10px;
  background:linear-gradient(135deg,#0088cc,#0369a1);
  color:#fff;text-decoration:none;padding:14px;border-radius:15px;
  font-size:14px;font-weight:800;margin-bottom:10px;
  box-shadow:0 4px 18px rgba(0,136,204,0.35);transition:box-shadow .2s;
}
.ptg-btn:hover{box-shadow:0 4px 28px rgba(0,136,204,0.55);}
.ptg-btn i{font-size:20px;}
.pskip{
  width:100%;padding:12px;
  background:var(--bg-input);
  border:1.5px solid var(--bord);
  border-radius:13px;font-size:13px;font-weight:700;
  color:var(--t3);cursor:pointer;font-family:'Nunito',sans-serif;
  transition:border-color .2s;
}
.pskip:hover{border-color:var(--bord2);}

/* SUPPORT SHEET */
.supp-overlay{
  position:fixed;inset:0;
  background:rgba(15,23,42,0.55);
  backdrop-filter:blur(14px);
  z-index:998;display:none;align-items:flex-end;justify-content:center;
}
.supp-overlay.show{display:flex;animation:fadein .22s ease;}
.supp-sheet{
  background:#fff;
  border:1.5px solid var(--bord);
  border-radius:28px 28px 0 0;width:100%;max-width:480px;
  padding:18px 18px 36px;
  box-shadow:0 -8px 40px rgba(15,23,42,0.18);
  animation:slideup .3s cubic-bezier(.4,0,.2,1);
}
@keyframes slideup{from{transform:translateY(100%);}to{transform:translateY(0);}}
.s-handle{width:38px;height:4px;background:#e2e8f0;border-radius:2px;margin:0 auto 20px;}
.s-title{font-size:16px;font-weight:900;color:var(--t1);margin-bottom:16px;text-align:center;}
.s-btn{
  display:flex;align-items:center;gap:13px;padding:14px;border-radius:16px;
  background:linear-gradient(135deg,#f0f9ff,#e0f2fe);
  border:1.5px solid rgba(0,136,204,0.18);
  text-decoration:none;margin-bottom:10px;
  transition:border-color .2s,box-shadow .2s;
}
.s-btn:hover{border-color:rgba(0,136,204,0.40);box-shadow:0 4px 18px rgba(0,136,204,0.15);}
.s-ico{width:46px;height:46px;flex-shrink:0;border-radius:50%;background:linear-gradient(135deg,#0088cc,#0369a1);display:flex;align-items:center;justify-content:center;font-size:20px;color:#fff;}
.s-txt h4{font-size:14px;font-weight:800;color:#0369a1;}
.s-txt p{font-size:11px;color:var(--t3);margin-top:2px;}
.s-close{
  width:100%;padding:13px;
  background:var(--bg-input);border:1.5px solid var(--bord);
  border-radius:14px;font-size:13px;font-weight:700;
  color:var(--t3);cursor:pointer;font-family:'Nunito',sans-serif;margin-top:5px;
}

/* COMING SOON */
.cs-overlay{
  position:fixed;inset:0;
  background:rgba(15,23,42,0.55);backdrop-filter:blur(14px);
  z-index:997;display:none;align-items:center;justify-content:center;padding:24px;
}
.cs-overlay.show{display:flex;animation:fadein .22s ease;}
.cs-box{
  background:#fff;
  border:1.5px solid rgba(245,158,11,0.25);
  border-radius:26px;max-width:300px;width:100%;
  padding:32px 22px;text-align:center;
  box-shadow:0 20px 60px rgba(15,23,42,0.20);
  animation:popbounce .32s cubic-bezier(.34,1.56,.64,1);
}
.cs-em{font-size:48px;display:block;margin-bottom:14px;animation:shake .5s ease;}
@keyframes shake{0%,100%{transform:rotate(0);}25%{transform:rotate(-5deg);}75%{transform:rotate(5deg);}}
.cs-box h3{font-size:17px;font-weight:900;color:var(--t1);margin-bottom:9px;}
.cs-box p{font-size:12.5px;color:var(--t3);line-height:1.7;margin-bottom:20px;}
.cs-ok{
  width:100%;padding:13px;
  background:linear-gradient(135deg,#f59e0b,#d97706);
  color:#fff;border:none;border-radius:14px;
  font-size:14px;font-weight:900;cursor:pointer;font-family:'Nunito',sans-serif;
  box-shadow:0 4px 18px rgba(245,158,11,0.40);transition:box-shadow .2s;
}
.cs-ok:hover{box-shadow:0 6px 28px rgba(245,158,11,0.60);}

/* ══ CLICK RIPPLE ══ */
.ripple{
  position:fixed;pointer-events:none;
  width:50px;height:50px;margin:-25px;
  border-radius:50%;
  background:radial-gradient(circle,rgba(124,58,237,0.25),transparent 70%);
  animation:rippleAnim .6s ease-out forwards;
  z-index:9998;
}
@keyframes rippleAnim{from{transform:scale(0);opacity:1;}to{transform:scale(3.5);opacity:0;}}
</style>

<!-- PAGE LOADER -->
<div class="page-loader" id="pageLoader"></div>

<!-- TELEGRAM POPUP -->
<div class="overlay" id="tgPopup">
  <div class="tg-popup">
    <div class="tg-popup-top">
      <div class="tp-ico">📣</div>
      <h2>অফিসিয়াল Telegram-এ<br>যোগ দিন!</h2>
      <p>সর্বশেষ আপডেট ও পেমেন্ট প্রুফ পেতে</p>
    </div>
    <div class="tg-popup-body">
      <p>হাজার সদস্য ইতিমধ্যে আমাদের সাথে আয় করছেন।</p>
      <a href="<?=htmlspecialchars($telegram_channel)?>" target="_blank" class="ptg-btn" onclick="closePopup()">
        <i class="fa-brands fa-telegram"></i> Join Telegram Channel
      </a>
      <button class="pskip" onclick="closePopup()">পরে যোগ দেব</button>
    </div>
  </div>
</div>

<!-- SUPPORT SHEET -->
<div class="supp-overlay" id="suppModal">
  <div class="supp-sheet">
    <div class="s-handle"></div>
    <div class="s-title">📞 সাপোর্ট সেন্টার</div>
    <a href="<?=htmlspecialchars($telegram_group)?>" target="_blank" class="s-btn">
      <div class="s-ico"><i class="fa-brands fa-telegram"></i></div>
      <div class="s-txt"><h4>Telegram Admin</h4><p>Admin-এর সাথে সরাসরি কথা বলুন</p></div>
    </a>
    <a href="<?=htmlspecialchars($telegram_channel)?>" target="_blank" class="s-btn">
      <div class="s-ico"><i class="fa-brands fa-telegram"></i></div>
      <div class="s-txt"><h4>Official Channel</h4><p>আপডেট ও পেমেন্ট প্রুফ দেখুন</p></div>
    </a>
    <button class="s-close" onclick="closeSuppModal()">বন্ধ করুন</button>
  </div>
</div>

<!-- COMING SOON -->
<div class="cs-overlay" id="csModal">
  <div class="cs-box">
    <span class="cs-em">🚧</span>
    <h3>আপডেট চলতেছে...</h3>
    <p>এই ফিচারটি খুব দ্রুত যুক্ত হবে!<br>Telegram Channel-এ চোখ রাখুন।</p>
    <button class="cs-ok" onclick="closeCS()">ঠিক আছে</button>
  </div>
</div>

<!-- ══ MAIN ══ -->
<div class="dw">

  <!-- INACTIVE BANNER -->
  <?php if (!$is_active): ?>
  <div class="inactive-banner">
    <div class="ib-left">
      <div class="ib-ico">⚠️</div>
      <div class="ib-txt">
        <h4>আপনার একাউন্ট ইনঅ্যাক্টিভ!</h4>
        <p>সকল সার্ভিস ব্যবহার করতে একাউন্ট একটিভ করুন।</p>
      </div>
    </div>
    <a href="activate_account.php" class="ib-btn">⚡ একটিভ করুন</a>
  </div>
  <?php endif; ?>

  <!-- HERO -->
  <div class="hero">
    <div class="hero-orb o1"></div>
    <div class="hero-orb o2"></div>
    <div class="hero-inner">
      <div class="hero-user">
        <div class="h-ava"><img src="<?=$profile_pic?>" alt="avatar" loading="lazy"></div>
        <div>
          <div class="h-greet">Welcome Back 👋</div>
          <div class="h-name"><?=strtoupper($user_fullname)?></div>
          <div class="s-pill <?= $is_active ? '' : 'inactive-pill' ?>">
            <span class="dot"></span>
            <?= $is_active ? 'Active Account' : '⚠️ Inactive' ?>
          </div>
        </div>
      </div>
      <a href="withdraw.php" class="hero-bal">
        <span class="hb-lbl">Main Balance</span>
        <span class="hb-val">৳<?=number_format($main_balance,2)?></span>
      </a>
    </div>
  </div>

  <!-- CARDS AREA -->
  <div class="ca">

    <!-- SITE AGE -->
    <div class="gp">
      <div class="age-wrap">
        <div class="age-row">
          <div class="age-lbl"><i class="fa-regular fa-clock"></i> সাইটের বয়স</div>
          <div class="live-badge">Live</div>
        </div>
        <div class="age-units">
          <div class="au"><span class="au-n" id="age-d">0</span><span class="au-l">দিন</span></div>
          <div class="au-sep">:</div>
          <div class="au"><span class="au-n" id="age-h">0</span><span class="au-l">ঘন্টা</span></div>
          <div class="au-sep">:</div>
          <div class="au"><span class="au-n" id="age-min">0</span><span class="au-l">মিনিট</span></div>
          <div class="au-sep">:</div>
          <div class="au"><span class="au-n" id="age-s">0</span><span class="au-l">সেকেন্ড</span></div>
        </div>
      </div>
    </div>

    <!-- NOTICE -->
    <div class="notice-bar">
      <div class="n-ico"><i class="fa-solid fa-bullhorn"></i></div>
      <marquee behavior="scroll" direction="left" scrollamount="4">
        <?= htmlspecialchars($notice_text) ?>
      </marquee>
    </div>

    <!-- BANNER SLIDER -->
    <div class="slider">
      <img src="https://i.ibb.co.com/X04j2WL/file-0000000026307208b42e6cd243164d14.webp" class="slide on" alt="Banner 1">
      <img src="https://i.ibb.co.com/C5nCFQPG/file-0000000091fc7208b6c749c85428080c.webp" class="slide" alt="Banner 2">
      <img src="https://i.ibb.co.com/fjt975M/Gemini-Generated-Image-ms8zucms8zucms8z.webp" class="slide" alt="Banner 3">
      <div class="slider-ov"></div>
      <div class="sdots">
        <div class="sd a" id="sd0"></div>
        <div class="sd" id="sd1"></div>
        <div class="sd" id="sd2"></div>
      </div>
    </div>

    <!-- EARNINGS OVERVIEW -->
    <div class="earn-section-wrap">
      <div class="gp">
        <div class="sec-title" style="padding:18px 16px 0;">
          <i class="fa-solid fa-chart-pie"></i> আয়ের বিবরণ
          <div class="line"></div>
        </div>
        <div class="earn-grid">
          <div class="ec e1">
            <div class="ec-ico"><i class="fa-solid fa-sack-dollar"></i></div>
            <div class="ec-txt">
              <div class="ec-val">৳<?=number_format($total_income,2)?></div>
              <div class="ec-lbl">মোট আয়</div>
            </div>
          </div>
          <div class="ec e2">
            <div class="ec-ico"><i class="fa-solid fa-money-bill-transfer"></i></div>
            <div class="ec-txt">
              <div class="ec-val">৳<?=number_format($total_withdraw,2)?></div>
              <div class="ec-lbl">মোট উইথড্রো</div>
            </div>
          </div>
          <div class="ec e3">
            <div class="ec-ico"><i class="fa-solid fa-money-bill-wave"></i></div>
            <div class="ec-txt">
              <div class="ec-val">৳<?=number_format($salary_income,2)?></div>
              <div class="ec-lbl">স্যালারি আয়</div>
            </div>
          </div>
          <div class="ec e4">
            <div class="ec-ico"><i class="fa-solid fa-users"></i></div>
            <div class="ec-txt">
              <div class="ec-val">৳<?=number_format($referral_income,2)?></div>
              <div class="ec-lbl">রেফার আয়</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- MENU GRID -->
    <div class="menu-glow-wrap">
    <div class="gp">
      <div class="mg-wrap">
        <div class="sec-title">
          <i class="fa-solid fa-rocket"></i>
          আমাদের প্রিমিয়াম প্রজেক্ট
          <div class="line"></div>
        </div>
        <div class="mg">

          <a href="facebook.php" class="mi">
            <div class="mi-ico g-fb"><i class="fa-brands fa-facebook-f"></i></div>
            <span class="mi-lbl">ফেসবুক সেল</span>
          </a>

          <a href="gmail.php" class="mi">
            <div class="mi-ico g-mail"><i class="fa-solid fa-envelope-open-text"></i></div>
            <span class="mi-lbl">জিমেইল সেল</span>
          </a>

          <a href="instagram.php" class="mi">
            <div class="mi-ico g-insta"><i class="fa-brands fa-instagram"></i></div>
            <span class="mi-lbl">ইনস্টা সেল</span>
          </a>

          <a href="coins_sell.php" class="mi">
            <div class="mi-ico g-coin"><i class="fa-solid fa-coins"></i></div>
            <span class="mi-lbl">কয়েন সেল</span>
          </a>
          
<a href="tasks.php" class="mi">
            <div class="mi-ico g-rjob"><i class="fa-solid fa-briefcase"></i></div>
            <span class="mi-lbl">My Job</span>
          </a>
          
          <a href="premium_jobs.php" class="mi">
            <div class="mi-ico g-pjob"><i class="fa-solid fa-crown"></i></div>
            <span class="mi-lbl">প্রিমিয়াম জব</span>
          </a>
          
          <a href="visiting_job.php" class="mi">
            <div class="mi-ico g-visit"><i class="fa-solid fa-location-dot"></i></div>
            <span class="mi-lbl">ভিজিটিং জব</span>
          </a>
          <a href="upgrade.php" class="mi">
            <div class="mi-ico g-upgrade"><i class="fa-solid fa-gem"></i></div>
            <span class="mi-lbl">VIP প্ল্যান</span>
          </a>
          <a href="task_history.php" class="mi">
            <div class="mi-ico g-jhist"><i class="fa-solid fa-clock-rotate-left"></i></div>
            <span class="mi-lbl">জব হিস্ট্রি</span>
          </a>
          <a href="referral_users.php" class="mi">
            <div class="mi-ico g-ref"><i class="fa-solid fa-people-group"></i></div>
            <span class="mi-lbl">রেফার হিস্ট্রি</span>
          </a>
          <a href="withdraw_history.php" class="mi">
            <div class="mi-ico g-payhist"><i class="fa-solid fa-receipt"></i></div>
            <span class="mi-lbl">  উইথড্র হিস্ট্রি</span>
          </a>
          <a href="my_team.php" class="mi">
            <div class="mi-ico g-sal2"><i class="fa-solid fa-users-between-lines"></i></div>
            <span class="mi-lbl">My Team</span>
          </a>
          <a href="withdraw.php" class="mi">
            <div class="mi-ico g-wd"><i class="fa-solid fa-money-bill-transfer"></i></div>
            <span class="mi-lbl">Withdraw</span>
          </a>
          <a href="gift_code.php" class="mi">
            <div class="mi-ico g-gift"><i class="fa-solid fa-gift"></i></div>
            <span class="mi-lbl">গিফট কোড</span>
          </a>
          <a href="leaderboard.php" class="mi">
            <div class="mi-ico g-lead"><i class="fa-solid fa-trophy"></i></div>
            <span class="mi-lbl">লিডারবোর্ড</span>
          </a>
          <a href="javascript:void(0)" onclick="showCS()" class="mi">
            <div class="mi-ico g-tgt" style="position:relative;">
              <i class="fa-solid fa-bullseye"></i>
              <span class="cbadge"></span>
            </div>
            <span class="mi-lbl">টার্গেট বোনাস</span>
          </a>
          
          <a href="salary.php" class="mi">
            <div class="mi-ico g-sal"><i class="fa-solid fa-money-bill-wave"></i></div>
            <span class="mi-lbl">স্যালারি</span>
          </a>

          


         <a href="javascript:void(0);" class="mi" onclick="showUpdateMessage()">
    <div class="mi-ico g-type">
        <i class="fa-solid fa-keyboard"></i>
    </div>
    <span class="mi-lbl">টাইপিং জব</span>
</a>

<script>
function showUpdateMessage() {
    alert("⚠️ টাইপিং জব আপডেট চলতাছে, পরে আবার চেষ্টা করুন!");
}
</script>

       

          <a href="settings.php" class="mi">
            <div class="mi-ico g-prof"><i class="fa-solid fa-user-gear"></i></div>
            <span class="mi-lbl">প্রোফাইল</span>
          </a>

          <a href="javascript:void(0)" onclick="openSuppModal(event)" class="mi">
            <div class="mi-ico g-sup"><i class="fa-solid fa-headset"></i></div>
            <span class="mi-lbl">সাপোর্ট</span>
          </a>

         

        </div>
      </div>
    </div>
    </div><!-- /.menu-glow-wrap -->

    <!-- PACKAGE -->
    <div class="pkg-glow-wrap">
    <div class="gp">
      <div class="pkg-wrap">
        <div class="sec-title">
          <i class="fa-solid fa-star"></i> আমাদের প্যাকেজ সমূহ
          <div class="line"></div>
        </div>
        <div class="pkg-grid">
          <a href="gmail.php" class="pkg p1">
            <div class="pkg-inner">
              <div class="pkg-ico"><i class="fa-solid fa-envelope-open-text"></i></div>
              <div class="pkg-title">Gmail Sell</div>
              <div class="pkg-earn">প্রতিটিতে আয়</div>
              <span class="pkg-btn">শুরু করুন →</span>
            </div>
          </a>
          <a href="facebook.php" class="pkg p2">
            <div class="pkg-inner">
              <div class="pkg-ico"><i class="fa-brands fa-facebook-f"></i></div>
              <div class="pkg-title">Facebook Sell</div>
              <div class="pkg-earn">প্রতিটিতে আয়</div>
              <span class="pkg-btn">শুরু করুন →</span>
            </div>
          </a>
          <a href="instagram.php" class="pkg p3">
            <div class="pkg-inner">
              <div class="pkg-ico"><i class="fa-brands fa-instagram"></i></div>
              <div class="pkg-title">Instagram Sell</div>
              <div class="pkg-earn">প্রতিটিতে আয়</div>
              <span class="pkg-btn">শুরু করুন →</span>
            </div>
          </a>
          <a href="coins_sell.php" class="pkg p4">
            <div class="pkg-inner">
              <div class="pkg-ico"><i class="fa-solid fa-coins"></i></div>
              <div class="pkg-title">Coin Sell</div>
              <div class="pkg-earn">প্রতিটিতে আয়</div>
              <span class="pkg-btn">শুরু করুন →</span>
            </div>
          </a>
        </div>
      </div>
    </div>
    </div><!-- /.pkg-glow-wrap -->

    <!-- REFERRAL -->
    <div class="ref-card">
      <div class="ref-hd">
        <i class="fa-solid fa-share-nodes"></i>
        <h3>Refer করুন, আয় করুন 🤝</h3>
      </div>
      <p class="ref-sub">প্রতিটি সফল রেফারেলে আয় করুন <span class="ref-bonus">৳<?=$ref_bonus?></span></p>
      <div class="ref-inp-row">
        <input type="text" id="refLink" value="<?=htmlspecialchars($ref_link)?>" readonly>
        <button class="ref-copy-btn" onclick="copyRef()"><i class="fa-solid fa-copy"></i></button>
      </div>
      <div class="ref-btns">
        <button class="rbtn rbtn-cp" onclick="copyRef()"><i class="fa-solid fa-copy"></i> কপি</button>
        <a href="https://t.me/share/url?url=<?=urlencode($ref_link)?>&text=Join+EARNING+BD+SHOP+and+earn!" target="_blank" class="rbtn rbtn-tg">
          <i class="fa-brands fa-telegram"></i> শেয়ার
        </a>
        <a href="my_team.php" class="rbtn rbtn-team"><i class="fa-solid fa-users"></i> My Team</a>
      </div>
    </div>

    <!-- LEADERBOARD -->
    <div class="lb-card">
      <div class="lb-head">
        <div class="lb-crown">👑</div>
        <div class="lb-head-t">
          <h3>লিডারবোর্ড</h3>
          <p>সর্বোচ্চ আয়কারীদের তালিকা</p>
        </div>
      </div>
      <div class="lb-podium">
        <div class="lp lp2"><div class="lp-medal">🥈</div><div class="lp-ava">🧑</div><div class="lp-bar"></div><div class="lp-name">2nd Place</div><div class="lp-amt">৳ ---</div></div>
        <div class="lp lp1"><div class="lp-medal">🥇</div><div class="lp-ava">👑</div><div class="lp-bar"></div><div class="lp-name">1st Place</div><div class="lp-amt">৳ ---</div></div>
        <div class="lp lp3"><div class="lp-medal">🥉</div><div class="lp-ava">🧑</div><div class="lp-bar"></div><div class="lp-name">3rd Place</div><div class="lp-amt">৳ ---</div></div>
      </div>
      <a href="leaderboard.php" class="lb-link"><i class="fa-solid fa-trophy"></i> সম্পূর্ণ লিডারবোর্ড দেখুন</a>
    </div>

    <!-- TELEGRAM -->
    <div class="tg-grid">
      <a href="<?=htmlspecialchars($telegram_group)?>" target="_blank" class="tgc">
        <div class="tg-ico"><i class="fa-brands fa-telegram"></i></div>
        <div class="tg-name">Developer Channel</div>
        <div class="tg-btn">Join Now</div>
      </a>
      <a href="<?=htmlspecialchars($telegram_channel)?>" target="_blank" class="tgc">
        <div class="tg-ico"><i class="fa-brands fa-telegram"></i></div>
        <div class="tg-name">Official Channel</div>
        <div class="tg-btn">Join Now</div>
      </a>
    </div>

  </div><!-- /.ca -->
</div><!-- /.dw -->

<script>
/* ─── AUDIO (Web Audio API) ─── */
const _AC = new (window.AudioContext || window.webkitAudioContext)();

function playClick(){
  try{
    const osc=_AC.createOscillator(), gain=_AC.createGain();
    osc.connect(gain); gain.connect(_AC.destination);
    osc.type='sine';
    osc.frequency.setValueAtTime(900,_AC.currentTime);
    osc.frequency.exponentialRampToValueAtTime(500,_AC.currentTime+0.09);
    gain.gain.setValueAtTime(0.16,_AC.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001,_AC.currentTime+0.12);
    osc.start(_AC.currentTime); osc.stop(_AC.currentTime+0.12);
  }catch(e){}
}
function playHover(){
  try{
    const osc=_AC.createOscillator(), gain=_AC.createGain();
    osc.connect(gain); gain.connect(_AC.destination);
    osc.type='sine';
    osc.frequency.setValueAtTime(700,_AC.currentTime);
    gain.gain.setValueAtTime(0.05,_AC.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001,_AC.currentTime+0.07);
    osc.start(_AC.currentTime); osc.stop(_AC.currentTime+0.07);
  }catch(e){}
}
document.addEventListener('click',()=>{ if(_AC.state==='suspended') _AC.resume(); },{once:true});

/* Add sounds to all interactive elements */
document.querySelectorAll('a, button, .mi, .pkg, .ec, .au').forEach(el=>{
  el.addEventListener('click', e=>{ playClick(); spawnRipple(e); });
  el.addEventListener('mouseenter', ()=>playHover());
});

/* ─── RIPPLE ─── */
function spawnRipple(e){
  const r=document.createElement('div');
  r.className='ripple';
  r.style.left=(e.clientX||e.touches?.[0]?.clientX||0)+'px';
  r.style.top=(e.clientY||e.touches?.[0]?.clientY||0)+'px';
  document.body.appendChild(r);
  r.addEventListener('animationend',()=>r.remove());
}

/* ─── TELEGRAM POPUP ─── */
<?php if ($is_active): ?>
window.addEventListener('load',()=>{
  setTimeout(()=>document.getElementById('tgPopup').classList.add('show'),1200);
});
<?php endif; ?>

function closePopup(){ document.getElementById('tgPopup').classList.remove('show'); }
document.getElementById('tgPopup').addEventListener('click',function(e){if(e.target===this)closePopup();});

function openSuppModal(e){ if(e)e.preventDefault(); document.getElementById('suppModal').classList.add('show'); }
function closeSuppModal(){ document.getElementById('suppModal').classList.remove('show'); }
document.getElementById('suppModal').addEventListener('click',function(e){if(e.target===this)closeSuppModal();});

function showCS(){ document.getElementById('csModal').classList.add('show'); }
function closeCS(){ document.getElementById('csModal').classList.remove('show'); }
document.getElementById('csModal').addEventListener('click',function(e){if(e.target===this)closeCS();});

/* ─── INACTIVE BLOCK ─── */
<?php if (!$is_active): ?>
document.addEventListener('click',function(e){
  const a=e.target.closest('a');
  if(!a) return;
  const href=a.getAttribute('href')||'';
  const allowed=['activate_account.php','logout.php','javascript:'];
  if(!allowed.some(p=>href.includes(p))&&href&&href!=='#'){
    e.preventDefault(); e.stopPropagation();
    Swal.fire({
      icon:'warning',
      title:'⚠️ একাউন্ট একটিভ নয়!',
      html:'এই সার্ভিসটি ব্যবহার করতে<br>আগে একাউন্ট একটিভ করুন।',
      confirmButtonText:'⚡ একটিভ করুন',
      confirmButtonColor:'#ef4444',
      showCancelButton:true,
      cancelButtonText:'পরে করব',
      background:'#ffffff',
      color:'#0f172a',
    }).then(r=>{ if(r.isConfirmed) window.location.href='activate_account.php'; });
  }
},true);
<?php endif; ?>

/* ─── SLIDER ─── */
let si=0;
const sls=document.querySelectorAll('.slide'), sds=document.querySelectorAll('.sd');
setInterval(()=>{
  sls[si].classList.remove('on'); sds[si].classList.remove('a');
  si=(si+1)%sls.length;
  sls[si].classList.add('on'); sds[si].classList.add('a');
},3500);
sds.forEach((d,i)=>d.addEventListener('click',()=>{
  sls[si].classList.remove('on'); sds[si].classList.remove('a');
  si=i; sls[si].classList.add('on'); sds[si].classList.add('a');
}));

/* ─── COPY REFERRAL ─── */
function copyRef(){
  const inp=document.getElementById('refLink');
  inp.select(); inp.setSelectionRange(0,99999);
  const done=()=>Swal.fire({
    icon:'success',title:'✅ Copied!',text:'রেফারেল লিংক কপি হয়েছে!',
    showConfirmButton:false,timer:1600,
    background:'#ffffff',color:'#0f172a',iconColor:'#10b981',
    backdrop:'rgba(15,23,42,0.4)'
  });
  if(navigator.clipboard){ navigator.clipboard.writeText(inp.value).then(done).catch(()=>{document.execCommand('copy');done();}); }
  else{ document.execCommand('copy'); done(); }
}

/* ─── SITE AGE COUNTER ─── */
const launch=new Date(Date.now()-1*24*60*60*1000);
function tick(){
  const diff=Math.max(0,Date.now()-launch.getTime());
  const t=Math.floor(diff/1000);
  document.getElementById('age-s').innerText=String(t%60).padStart(2,'0');
  document.getElementById('age-min').innerText=String(Math.floor(t/60)%60).padStart(2,'0');
  document.getElementById('age-h').innerText=String(Math.floor(t/3600)%24).padStart(2,'0');
  document.getElementById('age-d').innerText=Math.floor(t/86400);
}
setInterval(tick,1000); tick();

/* ─── PAGE LOADER ─── */
window.addEventListener('load',()=>{
  const l=document.getElementById('pageLoader');
  if(l) setTimeout(()=>{ l.style.opacity='0'; setTimeout(()=>l.remove(),500); },800);
});
</script>

<?php include "footer.php"; ?>
