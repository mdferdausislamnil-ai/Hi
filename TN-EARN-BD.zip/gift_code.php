<?php
// Error checking
ini_set('display_errors', 1);
error_reporting(E_ALL);

include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">Gift Code Locked!</h4>
                <p class="text-muted small px-3">Your account must be active to redeem gift codes.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>Activate Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

// Database connection check
if (!$conn) {
    die("Database connection failed.");
}

$user_id = $u['id'];
$swal_title = "";
$swal_text = "";
$swal_icon = "";

// Gift code submission
if (isset($_POST['apply_code'])) {
    $input_code = strtoupper(trim($conn->real_escape_string($_POST['gift_code'])));

    if (empty($input_code)) {
        $swal_title = "Sorry!";
        $swal_text = "Please enter a gift code.";
        $swal_icon = "warning";
    } else {
        // 1. Check code
        $code_res = $conn->query("SELECT * FROM gift_codes WHERE code = '$input_code' AND status = 'active' LIMIT 1");
        
        if ($code_res && $code_res->num_rows > 0) {
            $gift = $code_res->fetch_assoc();
            $gift_id = $gift['id'];
            $amount = $gift['amount'];

            // 2. Check if already used
            $check_usage = $conn->query("SELECT id FROM gift_code_usage WHERE user_id = '$user_id' AND gift_id = '$gift_id'");

            if ($check_usage && $check_usage->num_rows > 0) {
                $swal_title = "Sorry!";
                $swal_text = "You have already used this code.";
                $swal_icon = "error";
            } else {
                // 3. Update balance
                $update_bal = $conn->query("UPDATE users SET balance = balance + $amount WHERE id = '$user_id'");
                $insert_usage = $conn->query("INSERT INTO gift_code_usage (user_id, gift_id) VALUES ('$user_id', '$gift_id')");

                if ($update_bal && $insert_usage) {
                    $swal_title = "Congratulations!";
                    $swal_text = "You have successfully received ৳$amount gift.";
                    $swal_icon = "success";
                } else {
                    $swal_title = "Error!";
                    $swal_text = "Database error occurred.";
                    $swal_icon = "error";
                }
            }
        } else {
            $swal_title = "Sorry!";
            $swal_text = "Invalid or expired gift code.";
            $swal_icon = "error";
        }
    }
}

// Fetch history
$history = $conn->query("SELECT gc.code, gc.amount FROM gift_code_usage gu JOIN gift_codes gc ON gu.gift_id = gc.id WHERE gu.user_id = '$user_id' ORDER BY gu.id DESC");
?>

<!-- ====== GIFT CODE PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 600px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* main gift card – matches dashboard profile/wallet cards */
    .gift-card {
        background: white;
        border-radius: 32px;
        padding: 40px 24px;
        text-align: center;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        margin-top: 20px;
        transition: all 0.25s ease;
    }
    .gift-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* gift icon circle */
    .gift-icon-circle {
        width: 100px;
        height: 100px;
        background: linear-gradient(145deg, #fff9eb, #fef3c7);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        color: #f59e0b;
        font-size: 48px;
        box-shadow: 0 15px 25px -8px #f59e0b80;
        border: 2px solid rgba(255,255,255,0.5);
    }

    /* input field – matches dashboard referral input */
    .code-input {
        background: #f1f5f9;
        border: 2px dashed #cbd5e1;
        border-radius: 60px;
        padding: 16px 20px;
        font-size: 22px;
        font-weight: 800;
        letter-spacing: 4px;
        color: #1e293b;
        text-align: center;
        width: 100%;
        margin-bottom: 20px;
        transition: 0.2s;
    }
    .code-input:focus {
        outline: 2px solid #a855f7;
        background: white;
        border-color: transparent;
    }

    /* redeem button – matches dashboard copy button */
    .btn-redeem {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        border: none;
        color: white;
        font-weight: 800;
        padding: 16px 20px;
        border-radius: 60px;
        width: 100%;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 12px 22px -8px #7c3aed80;
        transition: 0.15s;
        border: 1px solid #ffffff40;
    }
    .btn-redeem:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #5b21b6;
    }

    /* history card */
    .history-card {
        background: white;
        border-radius: 32px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        overflow: hidden;
        margin-top: 30px;
    }

    /* table styling (like history page) */
    .table {
        margin-bottom: 0;
    }
    .table thead {
        background: #f8fafc;
        border-bottom: 2px solid #e2e8f0;
    }
    .table thead th {
        color: #64748b;
        font-size: 12px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.3px;
        padding: 18px 16px;
        border: none;
    }
    .table td {
        vertical-align: middle;
        font-size: 14px;
        color: #334155;
        padding: 16px;
        border-bottom: 1px solid #ecf1f7;
    }
    .table tr:last-child td {
        border-bottom: none;
    }

    /* status badge – gradient */
    .status-badge {
        background: linear-gradient(145deg, #10b981, #059669);
        color: white;
        padding: 6px 18px;
        border-radius: 40px;
        font-weight: 700;
        font-size: 12px;
        letter-spacing: 0.3px;
        display: inline-block;
        box-shadow: 0 4px 8px rgba(0,0,0,0.05);
    }

    /* empty state */
    .empty-state {
        padding: 30px 20px;
        text-align: center;
        color: #94a3b8;
        font-weight: 500;
    }

    /* pulse animation for inactive card (from dashboard) */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* back link */
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 25px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #3b82f6;
    }
</style>

<div class="container-custom pb-5">
    <!-- header -->
    <div class="section-title mt-4">
        <i class="fa-solid fa-gift"></i> Redeem Gift Code
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <!-- main gift card -->
            <div class="gift-card animate-fade-up">
                <div class="gift-icon-circle">
                    <i class="fa-solid fa-gift"></i>
                </div>
                <h4 class="fw-bold text-dark mb-4">Redeem</h4>
                
                <form method="POST">
                    <input type="text" name="gift_code" class="code-input" placeholder="XXXXXX" required>
                    <button type="submit" name="apply_code" class="btn-redeem">
                        <i class="fa-solid fa-check-circle me-2"></i> Redeem Now
                    </button>
                </form>
            </div>

            <!-- history card -->
            <div class="history-card">
                <div class="p-3 fw-bold text-dark border-bottom" style="background: #f9f9fc; padding: 18px 20px !important;">History</div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr><th>Code</th><th>Amount</th><th>Status</th></tr>
                        </thead>
                        <tbody>
                            <?php if($history && $history->num_rows > 0): while($row = $history->fetch_assoc()): ?>
                            <tr>
                                <td class="fw-bold" style="color: #4f46e5;"><?= htmlspecialchars($row['code']) ?></td>
                                <td class="fw-bold">৳ <?= number_format($row['amount'], 2) ?></td>
                                <td><span class="status-badge">Claimed</span></td>
                            </tr>
                            <?php endwhile; else: ?>
                            <tr><td colspan="3" class="empty-state">No gift codes used yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- back to dashboard link -->
            <div class="text-center">
                <a href="dashboard.php" class="back-link">
                    <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 script (already included in header, but ensure it's loaded) -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    // entrance animation for main card
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.gift-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.6s ease-out';
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
    });

    <?php if($swal_title != ""): ?>
        Swal.fire({
            title: '<?= $swal_title ?>',
            text: '<?= $swal_text ?>',
            icon: '<?= $swal_icon ?>',
            confirmButtonText: 'OK',
            confirmButtonColor: '#4f46e5',
            background: '#0f172a',
            color: '#fff',
            iconColor: '<?= $swal_icon === "success" ? "#10b981" : ($swal_icon === "error" ? "#ef4444" : "#f59e0b") ?>'
        }).then((result) => {
            if ('<?= $swal_icon ?>' === 'success') { 
                window.location.href = 'gift_code.php'; 
            }
        });
    <?php endif; ?>
</script>

<?php include "footer.php"; ?>