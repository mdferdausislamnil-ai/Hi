<?php
// 1. Error reporting enabled (to avoid white screen)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">Withdraw Access Denied!</h4>
                <p class="text-muted small px-3">Your account must be active to withdraw funds.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>Activate Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

$user_id = $u['id'];
$swal_json = ""; // Variable for popup

// Fetch admin settings for limits
$min_withdraw = isset($s['min_withdraw']) ? floatval($s['min_withdraw']) : 50;
$max_withdraw = isset($s['max_withdraw']) ? floatval($s['max_withdraw']) : 10000;

// Fetch active withdraw methods
$methods_query = $conn->query("SELECT * FROM withdraw_methods WHERE status='active'");

// --- Withdraw processing logic ---
if (isset($_POST['withdraw_now'])) {
    $method = $conn->real_escape_string($_POST['method']);
    $amount = floatval($_POST['amount']);
    $number = $conn->real_escape_string($_POST['number']);

    // Real-time balance check
    $bal_q = $conn->query("SELECT balance FROM users WHERE id='$user_id'");
    $cur_bal = ($bal_q->num_rows > 0) ? floatval($bal_q->fetch_assoc()['balance']) : 0;

    // Validation
    if (empty($method) || empty($amount) || empty($number)) {
        $swal_json = json_encode(['status'=>'warning', 'title'=>'Incomplete!', 'text'=>'Please fill in all fields correctly.']);
    } elseif ($amount < $min_withdraw) {
        $swal_json = json_encode(['status'=>'error', 'title'=>'Sorry!', 'text'=>"Minimum withdraw amount is ৳$min_withdraw."]);
    } elseif ($amount > $max_withdraw) {
        $swal_json = json_encode(['status'=>'error', 'title'=>'Sorry!', 'text'=>"Maximum withdraw amount per request is ৳$max_withdraw."]);
    } elseif ($amount > $cur_bal) {
        $swal_json = json_encode(['status'=>'error', 'title'=>'Insufficient Balance!', 'text'=>"Your current balance is ৳$cur_bal, but you requested ৳$amount"]);
    } else {
        // --- Transaction process ---

        // 1. Deduct balance first (to avoid double withdraw)
        $new_bal = $cur_bal - $amount;
        $update = $conn->query("UPDATE users SET balance = '$new_bal' WHERE id = '$user_id'");

        if ($update) {
            // 2. Save withdraw request
            $insert = $conn->query("INSERT INTO withdraws (user_id, amount, method, number, status) 
                                    VALUES ('$user_id', '$amount', '$method', '$number', 'pending')");
            
            if ($insert) {
                // Success!
                $swal_json = json_encode(['status'=>'success', 'title'=>'Success!', 'text'=>'Your withdraw request has been submitted to admin.', 'redirect'=>true]);
            } else {
                // If insert fails, refund the balance
                $conn->query("UPDATE users SET balance = balance + $amount WHERE id = '$user_id'");
                $swal_json = json_encode(['status'=>'error', 'title'=>'Database Error!', 'text'=>'Request could not be saved: ' . $conn->error]);
            }
        } else {
            $swal_json = json_encode(['status'=>'error', 'title'=>'Failed!', 'text'=>'Balance could not be updated.']);
        }
    }
}

// Fetch fresh balance to display
$fresh_user = $conn->query("SELECT balance FROM users WHERE id='$user_id'")->fetch_assoc();
$display_balance = $fresh_user['balance'];
?>

<!-- ====== WITHDRAW PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 700px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* main card – matches dashboard profile/wallet cards */
    .withdraw-card {
        background: white;
        border-radius: 32px;
        padding: 30px 28px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        margin-top: 20px;
        transition: all 0.25s ease;
    }
    .withdraw-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* balance badge – gradient (like dashboard wallet cards) */
    .balance-badge-modern {
        background: linear-gradient(145deg, #10b981, #059669);
        color: white;
        padding: 20px;
        border-radius: 28px;
        text-align: center;
        margin-bottom: 25px;
        box-shadow: 0 15px 25px -8px #10b98180;
        border: 1px solid rgba(255,255,255,0.2);
    }
    .balance-badge-modern .small {
        font-size: 13px;
        font-weight: 600;
        opacity: 0.9;
        letter-spacing: 0.3px;
    }
    .balance-badge-modern .h3 {
        font-size: 32px;
        font-weight: 800;
        margin: 5px 0 0;
        text-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    /* limit info – redesigned as two pills */
    .limit-info-modern {
        background: #f8fafc;
        border-radius: 60px;
        padding: 12px 20px;
        display: flex;
        justify-content: space-around;
        margin-bottom: 25px;
        border: 1px solid #eef2f6;
    }
    .limit-info-modern div {
        text-align: center;
    }
    .limit-info-modern .small {
        font-size: 11px;
        font-weight: 700;
        color: #64748b;
        text-transform: uppercase;
        letter-spacing: 0.3px;
    }
    .limit-info-modern .fw-bold {
        font-size: 18px;
        color: #0b253c;
    }

    /* form inputs (method & number) */
    .form-control-modern, .form-select-modern {
        background: #f1f5f9;
        border: 1px solid #e2e8f0;
        border-radius: 60px;
        padding: 14px 20px;
        font-size: 14px;
        color: #1e293b;
        width: 100%;
        transition: 0.2s;
    }
    .form-control-modern:focus, .form-select-modern:focus {
        outline: 2px solid #4f46e5;
        background: white;
        border-color: transparent;
    }
    label {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        margin-bottom: 6px;
        display: block;
        margin-left: 6px;
    }

    /* amount cards grid */
    .amount-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 12px;
        margin: 20px 0;
    }
    .amount-card {
        background: #f8fafc;
        border: 2px solid #e2e8f0;
        border-radius: 20px;
        padding: 12px 5px;
        text-align: center;
        cursor: pointer;
        transition: all 0.2s ease;
        box-shadow: 0 4px 8px rgba(0,0,0,0.02);
    }
    .amount-card:hover {
        border-color: #4f46e5;
        background: #eef2ff;
        transform: translateY(-2px);
    }
    .amount-card.active {
        border-color: #4f46e5;
        background: #eef2ff;
        box-shadow: 0 10px 15px -5px #4f46e580;
    }
    .amount-card .amount {
        font-size: 18px;
        font-weight: 800;
        color: #0b253c;
    }
    .amount-card .charge {
        font-size: 11px;
        color: #ef4444;
        font-weight: 600;
        background: #fee2e2;
        display: inline-block;
        padding: 3px 12px;
        border-radius: 30px;
        margin-top: 6px;
    }

    /* submit button */
    .btn-withdraw-modern {
        background: linear-gradient(90deg, #4f46e5, #7c3aed);
        border: none;
        color: white;
        font-weight: 800;
        padding: 16px 20px;
        border-radius: 60px;
        width: 100%;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 12px 22px -8px #7c3aed80;
        transition: 0.15s;
        border: 1px solid #ffffff40;
        margin-top: 20px;
    }
    .btn-withdraw-modern:hover {
        background: linear-gradient(90deg, #4338ca, #6d28d9);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #5b21b6;
        color: white;
    }

    /* pulse animation for inactive card */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* links */
    .history-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 20px;
    }
    .history-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #4f46e5;
    }
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 15px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #4f46e5;
    }
</style>

<div class="container-custom pb-5">
    <!-- header -->
    <div class="section-title mt-4">
        <i class="fa-solid fa-money-bill-transfer" style="color: #4f46e5;"></i> Withdraw Funds
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <!-- main withdraw card -->
            <div class="withdraw-card animate-fade-up">
                <h4 class="fw-bold text-dark text-center mb-4" style="color: #0b253c;">Withdraw Money</h4>

                <!-- balance badge -->
                <div class="balance-badge-modern">
                    <div class="small">Your Current Balance</div>
                    <div class="h3">৳ <?= number_format($display_balance, 2) ?></div>
                </div>

                <!-- limit info -->
                <div class="limit-info-modern">
                    <div>
                        <div class="small">Minimum</div>
                        <div class="fw-bold">৳<?= $min_withdraw ?></div>
                    </div>
                    <div class="border-start ps-3">
                        <div class="small">Maximum</div>
                        <div class="fw-bold">৳<?= $max_withdraw ?></div>
                    </div>
                </div>

                <form method="POST" id="withdrawForm">
                    <div class="mb-3">
                        <label>Select Method</label>
                        <select name="method" class="form-select-modern" required>
                            <option value="">-- Choose method --</option>
                            <?php if($methods_query && $methods_query->num_rows > 0): ?>
                                <?php while($m = $methods_query->fetch_assoc()): ?>
                                    <option value="<?= htmlspecialchars($m['method_name']) ?>"><?= htmlspecialchars($m['method_name']) ?></option>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <option value="Bkash">Bkash</option>
                                <option value="Nagad">Nagad</option>
                                <option value="Rocket">Rocket</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <!-- Hidden amount field (set by card click) -->
                    <input type="hidden" name="amount" id="selectedAmount" value="">

                    <!-- Amount cards (7 preset amounts with cosmetic charge) -->
                    <div class="mb-3">
                        <label>Select Amount</label>
                        <div class="amount-grid">
                            <!-- 7 cards with data-amount attributes -->
                            <div class="amount-card" data-amount="25">
                                <div class="amount">৳25</div>
                                <div class="charge">charge ৳5</div>
                            </div>
                            <div class="amount-card" data-amount="60">
                                <div class="amount">৳60</div>
                                <div class="charge">charge ৳10</div>
                            </div>
                            <div class="amount-card" data-amount="115">
                                <div class="amount">৳115</div>
                                <div class="charge">charge ৳15</div>
                            </div>
                            <div class="amount-card" data-amount="220">
                                <div class="amount">৳220</div>
                                <div class="charge">charge ৳20</div>
                            </div>
                            <div class="amount-card" data-amount="330">
                                <div class="amount">৳330</div>
                                <div class="charge">charge ৳30</div>
                            </div>
                            <div class="amount-card" data-amount="440">
                                <div class="amount">৳440</div>
                                <div class="charge">charge ৳40</div>
                            </div>
                            <div class="amount-card" data-amount="550">
                                <div class="amount">৳550</div>
                                <div class="charge">charge ৳50</div>
                            </div>
                        </div>
                        <!-- Optional: show selected amount (can be removed) -->
                        <div class="text-center small text-muted mt-2" id="selectedAmountDisplay"></div>
                    </div>

                    <div class="mb-3">
                        <label>Account Number</label>
                        <input type="number" name="number" class="form-control-modern" placeholder="01XXXXXXXXX" required>
                    </div>

                    <button type="submit" name="withdraw_now" class="btn-withdraw-modern">
                        Withdraw Now <i class="fa-solid fa-paper-plane ms-2"></i>
                    </button>
                </form>

                <!-- history link -->
                <div class="text-center">
                    <a href="withdraw_history.php" class="history-link">
                        <i class="fa-regular fa-clock me-1"></i> View History
                    </a>
                </div>
            </div>

            <!-- back to dashboard link -->
            <div class="text-center">
                <a href="dashboard.php" class="back-link">
                    <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert Library -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // entrance animation for main card
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.withdraw-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.6s ease-out';
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);

        // Amount card selection logic
        const amountCards = document.querySelectorAll('.amount-card');
        const hiddenAmount = document.getElementById('selectedAmount');
        const displayDiv = document.getElementById('selectedAmountDisplay');

        amountCards.forEach(card => {
            card.addEventListener('click', function() {
                // Remove active class from all cards
                amountCards.forEach(c => c.classList.remove('active'));
                // Add active class to this card
                this.classList.add('active');
                // Set hidden input value
                const amount = this.getAttribute('data-amount');
                hiddenAmount.value = amount;
                // Update optional display text
                if (displayDiv) {
                    displayDiv.innerText = 'Selected amount: ৳' + amount;
                }
            });
        });

        // Form validation before submit
        const form = document.getElementById('withdrawForm');
        form.addEventListener('submit', function(e) {
            if (!hiddenAmount.value) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Select Amount',
                    text: 'Please choose a withdraw card.',
                    confirmButtonColor: '#4f46e5',
                    background: '#0f172a',
                    color: '#fff'
                });
            }
        });
    });

    // Show popup with PHP data
    <?php if (!empty($swal_json)): ?>
        const alertData = <?= $swal_json ?>;
        
        Swal.fire({
            icon: alertData.status,
            title: alertData.title,
            text: alertData.text,
            confirmButtonColor: '#4f46e5',
            confirmButtonText: 'OK',
            background: '#0f172a',
            color: '#fff',
            iconColor: alertData.status === 'success' ? '#10b981' : (alertData.status === 'error' ? '#ef4444' : '#f59e0b')
        }).then((result) => {
            // If success, reload page
            if (result.isConfirmed && alertData.redirect) {
                window.location.href = 'withdraw.php';
            }
        });
    <?php endif; ?>
</script>

<?php include "footer.php"; ?>