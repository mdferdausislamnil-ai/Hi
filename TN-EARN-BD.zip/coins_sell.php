<?php
include "header.php"; 
include "sidebar.php";

// --- [START] INACTIVE ACCOUNT CHECK (redesigned message) ---
$current_status = isset($u['status']) ? strtolower(trim($u['status'])) : 'inactive';

if ($current_status !== 'active') {
    echo '
    <div class="container-custom d-flex align-items-center justify-content-center" style="min-height: 60vh;">
        <div class="pulse-red" style="max-width: 450px; width: 100%;">
            <div class="text-center">
                <div style="display: inline-block; background: #ef4444; width: 20px; height: 20px; border-radius: 50%; margin-bottom: 15px;"></div>
                <h4 class="fw-bold text-danger">Coin Sell Access Denied!</h4>
                <p class="text-muted small px-3">You need premium membership or account activation to sell coins.</p>
                <a href="activate_account.php" class="btn btn-danger rounded-pill fw-bold px-5 py-2 shadow-sm mt-3" style="background: #ef4444; border: none;">
                    <i class="fa-solid fa-unlock me-2"></i>Unlock Account
                </a>
            </div>
        </div>
    </div>';
    include "footer.php";
    exit();
}
// --- [END] INACTIVE ACCOUNT CHECK ---

$user_id = $u['id'];
$swal_msg = "";

$coins_data = [
    'NIVA' => ['status' => $s['niva_status'] ?? 'inactive', 'username' => $s['niva_username'] ?? ''],
    'TOP'  => ['status' => $s['top_status'] ?? 'inactive', 'username' => $s['top_username'] ?? ''],
    'RIVA' => ['status' => $s['riva_status'] ?? 'inactive', 'username' => $s['riva_username'] ?? ''],
    'NS'   => ['status' => $s['ns_status'] ?? 'inactive', 'username' => $s['ns_username'] ?? '']
];

if (isset($_POST['sell_confirm'])) {
    $coin_type = $_POST['coin_type'];
    $amount = $_POST['amount'];
    $sender_username = $conn->real_escape_string($_POST['sender_username']);
    
    if ($coins_data[$coin_type]['status'] !== 'active') {
        $swal_msg = "error|Sorry!|This coin is currently not available for selling.";
    } elseif (!empty($_FILES['screenshot']['name'])) {
        $targetDir = "uploads/coins/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        
        $fileName = "coin_".time()."_".basename($_FILES["screenshot"]["name"]);
        $targetFilePath = $targetDir . $fileName;
        
        if (move_uploaded_file($_FILES["screenshot"]["tmp_name"], $targetFilePath)) {
            $sql = "INSERT INTO coin_sales (user_id, coin_type, amount, sender_username, screenshot) 
                    VALUES ('$user_id', '$coin_type', '$amount', '$sender_username', '$fileName')";
            if ($conn->query($sql)) {
                $swal_msg = "success|Success!|Your request is pending, will be checked soon.";
            } else {
                $swal_msg = "error|Failed!|Database error occurred.";
            }
        }
    } else {
        $swal_msg = "warning|Incomplete!|Please provide a screenshot.";
    }
}
?>

<!-- ====== COIN SELL PAGE STYLES (aligned with dashboard) ====== -->
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap');
    * { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
    body { background: #f4f7fc; }

    /* reuse dashboard container */
    .container-custom {
        padding-left: 1rem;
        padding-right: 1rem;
        padding-bottom: 2rem;
        max-width: 700px;
        margin: 0 auto;
    }

    /* section title */
    .section-title {
        font-weight: 700;
        font-size: 20px;
        color: #0b253c;
        margin: 20px 0 10px;
        padding-left: 6px;
        letter-spacing: -0.2px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title i {
        color: #3b82f6;
        font-size: 24px;
    }

    /* main card – matches dashboard profile/wallet cards */
    .coin-card {
        background: white;
        border-radius: 32px;
        padding: 30px 28px;
        box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        border: 1px solid #f0f4fa;
        margin-top: 20px;
        transition: all 0.25s ease;
    }
    .coin-card:hover {
        box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
        border-color: #cbd5e1;
    }

    /* coin selection buttons – redesigned as pill-shaped cards */
    .method-btn {
        border: 2px solid #e2e8f0;
        border-radius: 32px;
        padding: 20px 10px;
        text-align: center;
        cursor: pointer;
        transition: 0.2s;
        background: white;
        position: relative;
        height: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
    }
    .method-btn:hover {
        border-color: #f59e0b;
        background: #fffbeb;
    }
    .method-btn.active {
        border-color: #f59e0b;
        background: #fef3c7;
        box-shadow: 0 8px 16px -6px #f59e0b80;
    }
    .method-btn img {
        width: 40px;
        height: 40px;
        object-fit: contain;
    }
    .method-btn span {
        font-weight: 700;
        font-size: 14px;
        color: #1e293b;
    }

    /* sell stop overlay */
    .sell-stop {
        opacity: 0.6;
        cursor: not-allowed !important;
        background: #f1f5f9;
        border-color: #cbd5e1;
    }
    .stop-badge {
        position: absolute;
        top: 12px;
        right: 12px;
        background: linear-gradient(145deg, #ef4444, #dc2626);
        color: white;
        font-size: 10px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: 40px;
        letter-spacing: 0.3px;
        box-shadow: 0 4px 8px #ef444480;
    }

    /* target info box – matches dashboard notice box */
    .target-box {
        background: linear-gradient(145deg, #fffbeb, #fef3c7);
        border-radius: 24px;
        padding: 20px;
        margin: 20px 0 15px;
        border: 1px solid #fcd34d;
        box-shadow: 0 8px 16px -6px #f59e0b40;
        display: none;
    }
    .target-box .small {
        color: #92400e;
        font-weight: 500;
        margin-bottom: 8px;
    }
    .target-username {
        font-weight: 800;
        color: #b45309;
        font-size: 20px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 60px;
        border: 1px solid #e2e8f0;
    }
    .target-username i {
        color: #f59e0b;
        font-size: 14px;
    }

    /* form inputs */
    .form-control-modern {
        background: #f1f5f9;
        border: 1px solid #e2e8f0;
        border-radius: 60px;
        padding: 14px 20px;
        font-size: 14px;
        color: #1e293b;
        width: 100%;
        transition: 0.2s;
    }
    .form-control-modern:focus {
        outline: 2px solid #f59e0b;
        background: white;
        border-color: transparent;
    }
    textarea.form-control-modern {
        border-radius: 28px;
        resize: vertical;
    }
    label {
        font-size: 13px;
        font-weight: 700;
        color: #64748b;
        margin-bottom: 6px;
        display: block;
        margin-left: 6px;
    }

    /* file input – custom style */
    .file-input-modern {
        background: #f1f5f9;
        border: 1px solid #e2e8f0;
        border-radius: 60px;
        padding: 10px 20px;
        width: 100%;
        font-size: 14px;
        color: #1e293b;
    }
    .file-input-modern::-webkit-file-upload-button {
        background: #4b5563;
        border: none;
        color: white;
        font-weight: 600;
        padding: 6px 18px;
        border-radius: 40px;
        font-size: 12px;
        margin-right: 10px;
        cursor: pointer;
        border: 1px solid #ffffff40;
    }

    /* submit button – matches dashboard copy button but orange */
    .btn-submit-modern {
        background: linear-gradient(90deg, #f59e0b, #d97706);
        border: none;
        color: white;
        font-weight: 800;
        padding: 16px 20px;
        border-radius: 60px;
        width: 100%;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        box-shadow: 0 12px 22px -8px #f59e0b80;
        transition: 0.15s;
        border: 1px solid #ffffff40;
        margin-top: 20px;
    }
    .btn-submit-modern:hover {
        background: linear-gradient(90deg, #d97706, #b45309);
        transform: scale(1.02);
        box-shadow: 0 16px 26px -6px #b45309;
        color: white;
    }

    /* pulse animation for inactive card (from dashboard) */
    .pulse-red {
        animation: pulse-red 2s infinite;
        background: #fff;
        border: 2px solid #ef4444;
        border-radius: 32px;
        padding: 32px 20px;
        text-align: center;
        box-shadow: 0 20px 30px -10px rgba(239,68,68,0.15);
    }
    @keyframes pulse-red {
        0% { box-shadow: 0 0 0 0 rgba(239,68,68,0.5); }
        70% { box-shadow: 0 0 0 15px rgba(239,68,68,0); }
        100% { box-shadow: 0 0 0 0 rgba(239,68,68,0); }
    }

    /* back link */
    .back-link {
        color: #64748b;
        font-weight: 600;
        text-decoration: none;
        transition: 0.2s;
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: white;
        padding: 8px 20px;
        border-radius: 40px;
        border: 1px solid #e2e8f0;
        font-size: 14px;
        margin-top: 25px;
    }
    .back-link:hover {
        background: #f1f5f9;
        color: #0b253c;
        border-color: #f59e0b;
    }

    /* hidden form fields animation */
    .animate-fade-up {
        animation: fadeUp 0.5s ease-out;
    }
    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>

<div class="container-custom pb-5">
    <!-- header -->
    <div class="section-title mt-4">
        <i class="fa-solid fa-coins" style="color: #f59e0b;"></i> Coin Sell
    </div>

    <div class="row justify-content-center">
        <div class="col-12">
            <!-- main card -->
            <div class="coin-card animate-fade-up">
                <h4 class="fw-bold text-center text-dark mb-3" style="color: #0b253c;">Sell Your Coins</h4>
                <p class="text-center text-muted small mb-4">Sell coins that are activated by admin</p>

                <form method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="coin_type" id="selected_coin" required>

                    <!-- coin selection grid -->
                    <div class="row g-3 mb-4">
                        <?php foreach($coins_data as $name => $info): ?>
                        <div class="col-6">
                            <?php if($info['status'] == 'active'): ?>
                                <div class="method-btn" onclick="selectCoin('<?= $name ?>', '<?= $info['username'] ?>', this)">
                                    <img src="https://cdn-icons-png.flaticon.com/512/1490/1490817.png" alt="<?= $name ?>">
                                    <span><?= $name ?> COIN</span>
                                </div>
                            <?php else: ?>
                                <div class="method-btn sell-stop">
                                    <span class="stop-badge">Sell Closed</span>
                                    <img src="https://cdn-icons-png.flaticon.com/512/1490/1490817.png" alt="<?= $name ?>">
                                    <span class="text-muted"><?= $name ?> COIN</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- target info box (initially hidden) -->
                    <div id="target_info" class="target-box animate-fade-up">
                        <div class="small"><i class="fa-solid fa-circle-exclamation me-1" style="color: #f59e0b;"></i> Coin sending address:</div>
                        <div class="d-flex align-items-center justify-content-between mt-2">
                            <span id="target_username" class="target-username" onclick="copyText()">...</span>
                            <span class="text-muted small">(Click to copy)</span>
                        </div>
                    </div>

                    <!-- form fields (initially hidden) -->
                    <div id="form_fields" style="display:none;" class="animate-fade-up">
                        <div class="mb-3">
                            <label>How many coins did you transfer?</label>
                            <input type="number" name="amount" class="form-control-modern" placeholder="e.g., 10000" required>
                        </div>
                        <div class="mb-3">
                            <label>Your coin account username</label>
                            <input type="text" name="sender_username" class="form-control-modern" placeholder="Enter your username" required>
                        </div>
                        <div class="mb-3">
                            <label>Transfer screenshot</label>
                            <input type="file" name="screenshot" class="file-input-modern" required accept="image/*">
                        </div>
                        <button type="submit" name="sell_confirm" class="btn-submit-modern">
                            Confirm Sell <i class="fa-solid fa-paper-plane ms-2"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- back to dashboard link -->
            <div class="text-center">
                <a href="dashboard.php" class="back-link">
                    <i class="fa-solid fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
    </div>
</div>

<!-- SweetAlert2 CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // entrance animation for main card
    document.addEventListener('DOMContentLoaded', function() {
        const card = document.querySelector('.coin-card');
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'all 0.6s ease-out';
        setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, 100);
    });

    // select coin function
    function selectCoin(type, username, el) {
        document.querySelectorAll('.method-btn').forEach(btn => btn.classList.remove('active'));
        el.classList.add('active');
        document.getElementById('selected_coin').value = type;
        document.getElementById('target_username').innerText = username;
        document.getElementById('target_info').style.display = 'block';
        document.getElementById('form_fields').style.display = 'block';
    }

    // copy username to clipboard
    function copyText() {
        let user = document.getElementById('target_username').innerText;
        if (user && user !== '...') {
            navigator.clipboard.writeText(user).then(() => {
                Swal.fire({
                    icon: 'success',
                    title: 'Copied!',
                    text: user + ' saved to clipboard.',
                    timer: 1500,
                    showConfirmButton: false,
                    background: '#0f172a',
                    color: '#fff',
                    iconColor: '#10b981'
                });
            }).catch(() => {
                Swal.fire({
                    icon: 'error',
                    title: 'Failed!',
                    text: 'Unable to copy.',
                    background: '#0f172a',
                    color: '#fff'
                });
            });
        } else {
            Swal.fire({
                icon: 'warning',
                title: 'Sorry!',
                text: 'Please select a coin first.',
                background: '#0f172a',
                color: '#fff'
            });
        }
    }

    // SweetAlert for form submission messages
    <?php if ($swal_msg != ""): 
        $parts = explode('|', $swal_msg);
        $icon = $parts[0];
        $title = $parts[1];
        $text = $parts[2];
    ?>
        Swal.fire({
            icon: '<?= $icon ?>',
            title: '<?= $title ?>',
            text: '<?= $text ?>',
            confirmButtonColor: '#f59e0b',
            background: '#0f172a',
            color: '#fff',
            iconColor: '<?= $icon === 'success' ? '#10b981' : ($icon === 'error' ? '#ef4444' : '#f59e0b') ?>'
        });
    <?php endif; ?>
</script>

<?php include "footer.php"; ?>