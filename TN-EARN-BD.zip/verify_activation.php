<?php 
ob_start();
session_start();
require_once "config.php"; 

// ডিবাগ ফাংশন (সমস্যা হলে লগ চেক করার জন্য)
function write_to_log($message) {
    $log_file = __DIR__ . '/activation_errors.txt';
    $time = date("Y-m-d H:i:s");
    file_put_contents($log_file, "[$time] $message" . PHP_EOL, FILE_APPEND);
}

$user_id = $_GET['user_id'] ?? null;
$status = "error";
$message = "অবৈধ রিকোয়েস্ট!";

// ১. ডাটাবেস থেকে রেফার বোনাস এমাউন্ট আনা (আপনার স্ক্রিনশট অনুযায়ী 'referral_bonus')
$ref_bonus = 0;
$sql_bonus = "SELECT setting_value FROM admin_settings WHERE setting_key = 'referral_bonus' LIMIT 1";
$res_bonus = $conn->query($sql_bonus);

if ($res_bonus && $res_bonus->num_rows > 0) {
    $row_bonus = $res_bonus->fetch_assoc();
    $ref_bonus = floatval($row_bonus['setting_value']); // যেমন: 50
}

// যদি ডাটাবেস থেকে না পায়, ডিফল্ট ভ্যালু সেট করা (সেফটি)
if ($ref_bonus <= 0) {
    $ref_bonus = 25.00; 
}

if ($user_id) {
    try {
        // ২. ইউজার এবং তার আপলাইনের তথ্য বের করা
        // নোট: এখানে referred_by_id ব্যবহার করা হয়েছে
        $stmt_user = $conn->prepare("SELECT id, status, referred_by_id FROM users WHERE id = ?");
        $stmt_user->bind_param("i", $user_id);
        $stmt_user->execute();
        $result_user = $stmt_user->get_result();
        $user_data = $result_user->fetch_assoc();
        $stmt_user->close();

        if ($user_data) {
            // যদি ইউজার ইতিমধ্যে একটিভ না থাকে
            if ($user_data['status'] !== 'active') {
                
                $conn->begin_transaction(); // ট্রানজেকশন শুরু

                // ৩. ইউজারকে একটিভ করা
                $stmt_active = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                $stmt_active->bind_param("i", $user_id);
                $res_active = $stmt_active->execute();
                $stmt_active->close();

                if ($res_active) {
                    
                    // ৪. আপলাইন (যিনি রেফার করেছেন) তাকে বোনাস দেওয়া
                    // নোট: referred_by_id থেকে আইডি নেওয়া হচ্ছে
                    $upline_id = $user_data['referred_by_id'];

                    // চেক: আপলাইন আইডি ভ্যালিড কিনা (0 বা null না হয়)
                    if (!empty($upline_id) && $upline_id > 0) {
                        
                        // বোনাস যোগ করা হচ্ছে (আপলাইনের ব্যালেন্স + রেফার ইনকাম + কাউন্ট)
                        $stmt_upline = $conn->prepare("UPDATE users SET balance = balance + ?, referral_income = referral_income + ?, referral_count = referral_count + 1 WHERE id = ?");
                        $stmt_upline->bind_param("ddi", $ref_bonus, $ref_bonus, $upline_id);
                        $res_upline = $stmt_upline->execute();
                        $stmt_upline->close();

                        if(!$res_upline) {
                            write_to_log("Upline Update Failed for User: $upline_id");
                        }
                    }

                    $conn->commit(); // সব ঠিক থাকলে সেভ

                    // ৫. সেশন আপডেট (যাতে ড্যাশবোর্ডে সাথে সাথে রিফ্লেক্ট করে)
                    $stmt_refresh = $conn->prepare("SELECT * FROM users WHERE id = ?");
                    $stmt_refresh->bind_param("i", $user_id);
                    $stmt_refresh->execute();
                    $new_user_data = $stmt_refresh->get_result()->fetch_assoc();
                    $_SESSION['u'] = $new_user_data;
                    $stmt_refresh->close();

                    $status = "success";
                    $message = "অ্যাকাউন্ট অ্যাক্টিভ হয়েছে! রেফার বোনাস প্রদান করা হয়েছে।";

                } else {
                    throw new Exception("Status Update Failed");
                }
            } else {
                $status = "info";
                $message = "অ্যাকাউন্ট আগে থেকেই অ্যাক্টিভ আছে।";
            }
        } else {
            $message = "ইউজার পাওয়া যায়নি।";
        }

    } catch (Exception $e) {
        $conn->rollback();
        $status = "error";
        $message = "এরর: " . $e->getMessage();
        write_to_log($e->getMessage());
    }
} else {
    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>প্রসেসিং...</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-100 flex items-center justify-center h-screen">
    <div class="bg-white p-8 rounded-2xl shadow-xl max-w-sm w-full text-center">
        
        <?php if ($status === "success"): ?>
            <div class="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-green-100 mb-4 animate-pulse">
                <svg class="h-10 w-10 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                </svg>
            </div>
            <h2 class="text-2xl font-bold text-gray-800 mb-2">সফল হয়েছে!</h2>
            <p class="text-gray-600 mb-2"><?php echo $message; ?></p>
            <p class="text-sm font-bold text-blue-600">রেফার বোনাস রেট: ৳<?php echo $ref_bonus; ?></p>
        
        <?php elseif ($status === "info"): ?>
            <div class="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-blue-100 mb-4">
                <svg class="h-10 w-10 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <h2 class="text-xl font-bold text-gray-800 mb-2">নোটিশ</h2>
            <p class="text-gray-600"><?php echo $message; ?></p>

        <?php else: ?>
            <div class="mx-auto flex items-center justify-center h-20 w-20 rounded-full bg-red-100 mb-4">
                <svg class="h-10 w-10 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <h2 class="text-xl font-bold text-gray-800 mb-2">সমস্যা হয়েছে</h2>
            <p class="text-red-500"><?php echo $message; ?></p>
        <?php endif; ?>

        <div class="mt-6">
            <p class="text-gray-500 text-sm mb-2">ড্যাশবোর্ডে ফিরে যাচ্ছি: <span id="timer" class="font-bold text-blue-600">3</span> সেকেন্ড</p>
            <div class="w-full bg-gray-200 rounded-full h-1.5">
                <div class="bg-blue-600 h-1.5 rounded-full transition-all duration-1000" style="width: 100%" id="progress"></div>
            </div>
        </div>
    </div>

    <script>
        let seconds = 3;
        const timerEl = document.getElementById('timer');
        const progressEl = document.getElementById('progress');
        
        const interval = setInterval(() => {
            seconds--;
            timerEl.innerText = seconds;
            progressEl.style.width = (seconds / 3 * 100) + "%";

            if (seconds <= 0) {
                clearInterval(interval);
                window.location.href = 'dashboard.php';
            }
        }, 1000);
    </script>
</body>
</html>
<?php ob_end_flush(); ?>