<?php
// ===============================
// 🗄 DATABASE CONNECTION
// ===============================
$servername = "localhost";
$username = "bdlive24_robin2";
$password = "bdlive24_robin2";
$dbname = "bdlive24_robin2";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Database Connection failed");
}

// ===============================
// 💳 PAYMENT GATEWAY - RUPANTORPAY
// ===============================
define('RUPANTOR_API_KEY', '3AOCNLR6mIrHPWgzPkvf8BnQJzNaXf');
define('RUPANTOR_CALLBACK_URL', 'https://earningbdshop.bdlive24.top/payment_success.php');
define('ACTIVATION_FEE', 20);
?>