<?php
session_start();
include "config.php";

// ১. ডাটাবেস থেকে সাইট সেটিংস ফেচ করা
$s = [];
$settings_query = $conn->query("SELECT setting_key, setting_value FROM admin_settings");
if ($settings_query) {
    while ($row = $settings_query->fetch_assoc()) {
        $s[$row['setting_key']] = $row['setting_value'];
    }
}

// ডিফল্ট ভ্যালু যদি ডাটাবেসে না থাকে
$site_name = $s['site_name'] ?? 'Unique Earn BD';
// লোগো পাথ ঠিক করা (অ্যাডমিন প্যানেলে '../' থাকে, মেইন ফাইলে সেটা সরাতে হবে)
$site_logo = !empty($s['site_logo']) ? str_replace("../", "", $s['site_logo']) : '';

// ইউজার লগইন চেক
$is_logged_in = isset($_SESSION['fullname']);
$user_name = $is_logged_in ? $_SESSION['fullname'] : '';
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="monetag" content="bb3f84d3c33dc18bdd43e29e3147e9a6">
    <title><?= htmlspecialchars($site_name) ?> - হোম</title>
    
    <!-- Fonts & Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz@14..32&display=swap" rel="stylesheet">

    <style>
        :root {
            --primary: #4f46e5;
            --primary-dark: #4338ca;
            --secondary: #7c3aed;
            --light-bg: #f4f7fc;
            --card-bg: #ffffff;
            --text-dark: #0b253c;
            --text-muted: #64748b;
        }
        * {
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        body {
            background-color: var(--light-bg);
            color: var(--text-dark);
            overflow-x: hidden;
        }

        /* --- Navbar Styles (light, rounded) --- */
        .navbar {
            background: white;
            padding: 12px 0;
            box-shadow: 0 4px 20px rgba(0,50,100,0.05);
            border-bottom: 1px solid #eef2f6;
        }
        .navbar-brand {
            font-weight: 800;
            color: var(--text-dark) !important;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.4rem;
        }
        .nav-logo {
            height: 42px;
            width: 42px;
            object-fit: contain;
            border-radius: 12px;
            background: #eef2ff;
            padding: 4px;
        }
        .nav-link {
            color: var(--text-muted) !important;
            font-weight: 600;
            transition: 0.2s;
            padding: 8px 16px !important;
        }
        .nav-link:hover {
            color: var(--primary) !important;
        }
        .btn-nav {
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            color: white !important;
            border-radius: 60px;
            padding: 10px 28px;
            font-weight: 700;
            box-shadow: 0 8px 18px -6px var(--primary);
            border: none;
            transition: 0.2s;
        }
        .btn-nav:hover {
            background: linear-gradient(90deg, var(--primary-dark), #6d28d9);
            transform: scale(1.02);
            box-shadow: 0 12px 22px -8px var(--primary-dark);
        }
        .navbar-toggler {
            border: none;
            background: transparent;
            padding: 0;
        }
        .navbar-toggler:focus { box-shadow: none; }
        .fa-bars { font-size: 24px; color: var(--text-dark); }

        /* --- Hero Section --- */
        .hero-section {
            padding: 120px 0 80px;
            text-align: center;
            background: linear-gradient(145deg, #ffffff, #f8fafc);
            border-bottom: 1px solid #eef2f6;
        }
        .hero-badge {
            background: #eef2ff;
            color: var(--primary);
            padding: 8px 22px;
            border-radius: 60px;
            font-weight: 700;
            font-size: 14px;
            display: inline-block;
            margin-bottom: 20px;
            border: 1px solid #cbd5e1;
            box-shadow: 0 4px 10px rgba(79,70,229,0.08);
        }
        .hero-title {
            font-size: 48px;
            font-weight: 800;
            color: var(--text-dark);
            margin-bottom: 20px;
            line-height: 1.2;
            letter-spacing: -1px;
        }
        .hero-text {
            color: var(--text-muted);
            font-size: 18px;
            max-width: 600px;
            margin: 0 auto 30px;
        }
        .hero-btns .btn {
            padding: 14px 36px;
            border-radius: 60px;
            font-weight: 700;
            margin: 5px 8px;
            transition: 0.2s;
        }
        .btn-start {
            background: white;
            color: var(--primary);
            border: 2px solid #e2e8f0;
        }
        .btn-start:hover {
            background: #f8fafc;
            border-color: var(--primary);
            transform: translateY(-2px);
        }
        
        /* --- Features --- */
        .section-title {
            font-weight: 800;
            font-size: 32px;
            color: var(--text-dark);
            text-align: center;
            margin-bottom: 50px;
        }
        .feature-card {
            background: var(--card-bg);
            border: 1px solid #f0f4fa;
            border-radius: 32px;
            padding: 32px 24px;
            transition: all 0.25s ease;
            height: 100%;
            box-shadow: 0 15px 30px -10px rgba(0,50,100,0.08);
        }
        .feature-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 25px 40px -12px rgba(0,80,160,0.15);
            border-color: var(--primary);
        }
        .icon-box {
            width: 70px;
            height: 70px;
            background: linear-gradient(145deg, #eef2ff, #e0e7ff);
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            color: var(--primary);
            margin-bottom: 20px;
            border: 1px solid #cbd5e1;
        }
        .feature-card h4 {
            font-weight: 700;
            font-size: 20px;
            color: var(--text-dark);
            margin-bottom: 10px;
        }
        .feature-card p {
            color: var(--text-muted);
            font-size: 14px;
        }

        /* --- Stats Section --- */
        .stats-section {
            background: white;
            border-radius: 60px;
            padding: 40px 20px;
            margin: 50px 0;
            box-shadow: 0 20px 40px -10px rgba(0,50,100,0.08);
            border: 1px solid #f0f4fa;
        }
        .stat-item {
            text-align: center;
        }
        .stat-number {
            font-weight: 800;
            font-size: 36px;
            color: var(--primary);
            margin-bottom: 5px;
        }
        .stat-label {
            color: var(--text-muted);
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        /* --- Footer --- */
        footer {
            background: white;
            border-top: 1px solid #eef2f6;
            padding: 30px 0;
            margin-top: 60px;
            text-align: center;
            color: var(--text-muted);
            font-size: 14px;
        }
        footer a {
            color: var(--primary);
            font-weight: 700;
            text-decoration: none;
        }
        footer a:hover {
            text-decoration: underline;
        }

        /* Animation */
        .animate-fade-up {
            animation: fadeUp 0.8s ease-out forwards;
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <!-- Navbar (light, modern) -->
    <nav class="navbar navbar-expand-lg fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <?php if($site_logo && file_exists($site_logo)): ?>
                    <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo" class="nav-logo">
                <?php else: ?>
                    <div class="nav-logo d-flex align-items-center justify-content-center bg-light">
                        <i class="fa-solid fa-coins text-warning"></i>
                    </div>
                <?php endif; ?>
                <span><?= htmlspecialchars($site_name) ?></span>
            </a>
            
            <!-- Mobile Toggle -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto align-items-center">
                    <li class="nav-item"><a class="nav-link" href="index.php">হোম</a></li>
                    <li class="nav-item"><a class="nav-link" href="#features">বৈশিষ্ট্য</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">যোগাযোগ</a></li>
                    
                    <li class="nav-item ms-lg-3 mt-2 mt-lg-0">
                        <?php if($is_logged_in): ?>
                            <a href="dashboard.php" class="btn btn-nav">
                                <i class="fa-regular fa-user me-2"></i> <?= htmlspecialchars(explode(' ', $user_name)[0]) ?>
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="btn btn-nav">
                                লগইন / রেজিস্টার <i class="fa-solid fa-arrow-right ms-2"></i>
                            </a>
                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-badge animate-fade-up">
                <i class="fa-solid fa-bolt me-2"></i> সেরা আয়ের প্ল্যাটফর্ম 2026
            </div>
            <h1 class="hero-title animate-fade-up" style="animation-delay: 0.1s;">সহজ কাজ করুন,<br>ঘরে বসে আয় করুন</h1>
            <p class="hero-text animate-fade-up" style="animation-delay: 0.2s;">
                আমাদের প্ল্যাটফর্মে আপনি খুব সহজেই মাইক্রোজব, ভিডিও দেখা এবং রেফার করার মাধ্যমে প্রতিদিন ভালো পরিমাণ টাকা আয় করতে পারবেন। পেমেন্ট নিন বিকাশ বা নগদে।
            </p>
            <div class="hero-btns animate-fade-up" style="animation-delay: 0.3s;">
                <?php if($is_logged_in): ?>
                    <a href="dashboard.php" class="btn btn-nav">ড্যাশবোর্ড</a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-nav">একাউন্ট খুলুন</a>
                    <a href="login.php" class="btn btn-start">লগইন করুন</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="py-5">
        <div class="container">
            <h2 class="section-title animate-fade-up">কেন আমাদের বেছে নেবেন?</h2>
            <div class="row g-4">
                <div class="col-md-4 animate-fade-up" style="animation-delay: 0.1s;">
                    <div class="feature-card">
                        <div class="icon-box"><i class="fa-solid fa-briefcase"></i></div>
                        <h4>সহজ কাজ</h4>
                        <p class="text-muted">ফেসবুক, ইউটিউব, টাইপিং এবং অ্যাপ ডাউনলোডের মত সহজ কাজ করে আয় করুন।</p>
                    </div>
                </div>
                <div class="col-md-4 animate-fade-up" style="animation-delay: 0.2s;">
                    <div class="feature-card">
                        <div class="icon-box"><i class="fa-solid fa-money-bill-transfer"></i></div>
                        <h4>দ্রুত পেমেন্ট</h4>
                        <p class="text-muted">আপনার আয়ের টাকা বিকাশ অথবা নগদের মাধ্যমে খুব সহজেই উত্তোলন করতে পারবেন।</p>
                    </div>
                </div>
                <div class="col-md-4 animate-fade-up" style="animation-delay: 0.3s;">
                    <div class="feature-card">
                        <div class="icon-box"><i class="fa-solid fa-headset"></i></div>
                        <h4>২৪/৭ সাপোর্ট</h4>
                        <p class="text-muted">যেকোনো সমস্যায় আমাদের টেলিগ্রাম সাপোর্ট গ্রুপে সবসময় সাহায্য পাবেন।</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Section (redesigned as rounded card) -->
    <section class="container">
        <div class="stats-section animate-fade-up">
            <div class="row">
                <div class="col-4 stat-item">
                    <div class="stat-number">1.9K+</div>
                    <div class="stat-label">ব্যবহারকারী</div>
                </div>
                <div class="col-4 stat-item">
                    <div class="stat-number">1.3K+</div>
                    <div class="stat-label">কাজ</div>
                </div>
                <div class="col-4 stat-item">
                    <div class="stat-number">24/7</div>
                    <div class="stat-label">সাপোর্ট</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <p class="mb-2">&copy; ২০২৬ <strong><?= htmlspecialchars($site_name) ?></strong>। সর্বস্বত্ব সংরক্ষিত।</p>
            <p class="mb-0">Developed by <a href="https://t.me/DevAtik69" target="_blank">DEV ATIK</a></p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- (optional) any other scripts -->
</body>
</html>