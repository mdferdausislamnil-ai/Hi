<?php
session_start();
require_once '../config.php'; 

// লগইন চেক
if (!isset($_SESSION['fullname'])) {
    header("Location: ../login.php");
    exit();
}

// প্ল্যান আইডি এবং এমাউন্ট চেক
$plan_id = isset($_GET['plan_id']) ? intval($_GET['plan_id']) : 0;
$amount = isset($_GET['amount']) ? floatval($_GET['amount']) : 0;

if ($plan_id == 0 && $amount == 0) {
    echo "<script>window.location='../dashboard.php';</script>";
    exit();
}

// ডাটাবেজ থেকে সেটিংস আনা
$settings_query = $conn->query("SELECT setting_key, setting_value FROM admin_settings");
$s = [];
while ($row = $settings_query->fetch_assoc()) {
    $s[$row['setting_key']] = $row['setting_value'];
}

// সাইট নাম (ডাটাবেজ থেকে)
$site_name = $s['site_name'] ?? "BASE EARN";

// লোগো লজিক: 
// ১. প্রথমে ডাটাবেজে 'site_logo' কি (key) আছে কি না চেক করবে।
// ২. থাকলে সেই নামের ফাইলটি '../image/' ফোল্ডার থেকে নিবে।
// ৩. না থাকলে ডিফল্ট 'logo.png' নিবে।
$db_logo = $s['site_logo'] ?? 'logo.png'; 
$site_logo = "../image/" . $db_logo;

?>

<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payment Method | <?= htmlspecialchars($site_name) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Hind Siliguri', sans-serif; }
    body { background-color: #f2f7fb; display: flex; justify-content: center; min-height: 100vh; align-items: center; padding: 15px; }
    
    .container {
        background: #fff; width: 100%; max-width: 400px; border-radius: 15px;
        box-shadow: 0 5px 20px rgba(0,0,0,0.05); padding-bottom: 30px; text-align: center; overflow: hidden;
    }

    .header { padding: 30px 20px 10px; }
    .logo-box {
        width: 85px; height: 85px; border-radius: 50%; border: 2px solid #f0f0f0;
        margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; padding: 5px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.08); background: #fff;
    }
    .logo-box img { width: 100%; height: 100%; object-fit: contain; border-radius: 50%; }
    
    .brand-name { font-size: 22px; font-weight: 700; color: #333; margin-bottom: 5px; text-transform: uppercase; }
    .payable-text { color: #666; font-size: 14px; margin-bottom: 20px; }

    .title-bar {
        background: #4f46e5; color: white; padding: 12px; font-size: 16px;
        font-weight: 600; border-radius: 8px; margin: 0 25px 25px;
    }

    .grid-container {
        display: grid; grid-template-columns: 1fr 1fr; gap: 15px; padding: 0 25px;
    }
    .pay-card {
        background: #fff; border: 1px solid #eee; border-radius: 12px;
        padding: 15px; display: flex; align-items: center; justify-content: center;
        transition: 0.3s; cursor: pointer; box-shadow: 0 3px 6px rgba(0,0,0,0.03);
        text-decoration: none; height: 100px;
    }
    .pay-card:hover { border-color: #4f46e5; transform: translateY(-3px); box-shadow: 0 5px 15px rgba(79, 70, 229, 0.1); }
    .pay-card img { height: 55px; width: auto; }

    .cancel-link {
        display: inline-block; margin-top: 25px; text-decoration: none; 
        color: #ef4444; font-weight: 600; font-size: 14px; transition: 0.2s;
    }
    .cancel-link:hover { color: #dc2626; text-decoration: underline; }
</style>
</head>
<body>

<div class="container">
    <div class="header">
        <div class="logo-box">
            <!-- এখানে লোগো পাথ চেক করা হচ্ছে -->
            <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo" onerror="this.src='../image/logo.png';">
        </div>
        <div class="brand-name"><?= htmlspecialchars($site_name) ?></div>
        <p class="payable-text">প্রদেয় পরিমাণ: <b style="color: #4f46e5;">৳<?= number_format($amount, 2); ?></b></p>
    </div>

    <div class="title-bar">পেমেন্ট মেথড সিলেক্ট করুন</div>

    <div class="grid-container">
        <!-- Bkash -->
        <a href="payment.php?method=bkash&plan_id=<?= $plan_id ?>&amount=<?= $amount ?>" class="pay-card">
            <img src="../image/bkash.png" alt="bKash">
        </a>

        <!-- Nagad -->
        <a href="payment.php?method=nagad&plan_id=<?= $plan_id ?>&amount=<?= $amount ?>" class="pay-card">
            <img src="../image/nagad.png" alt="Nagad">
        </a>
    </div>
    
    <div>
        <a href="../dashboard.php" class="cancel-link">পেমেন্ট বাতিল করুন</a>
    </div>
</div>

</body>
</html>