<?php
session_start();
require_once '../config.php';

// লগইন চেক
if (!isset($_SESSION['fullname']) || !isset($_GET['method']) || !isset($_GET['amount'])) {
    header("Location: ../login.php");
    exit();
}

// ডাটাবেজ থেকে সেটিংস আনা
$s = [];
$settings_query = $conn->query("SELECT setting_key, setting_value FROM admin_settings");
while ($row = $settings_query->fetch_assoc()) {
    $s[$row['setting_key']] = $row['setting_value'];
}

// সাইট ইনফরমেশন
$site_name = $s['site_name'] ?? "BASE EARN";
$site_logo = "../image/logo.png"; 

$user_id = $_SESSION['user_id'] ?? 0;
if($user_id == 0){
    $u_stmt = $conn->prepare("SELECT id FROM users WHERE fullname=?");
    $u_stmt->bind_param("s", $_SESSION['fullname']);
    $u_stmt->execute();
    $user_id = $u_stmt->get_result()->fetch_assoc()['id'];
}

$method = $_GET['method'];
$amount = floatval($_GET['amount']);
$plan_id = isset($_GET['plan_id']) ? intval($_GET['plan_id']) : 0;

// মেথড কনফিগারেশন
switch ($method) {
    case 'bkash':
        $color = "#e2136e"; 
        $method_name = "bKash"; 
        $number = $s['bkash_number'] ?? 'Not Set'; 
        $logo_img = "../image/bkash.png"; 
        break;
    case 'nagad':
        $color = "#f6921e"; 
        $method_name = "Nagad"; 
        $number = $s['nagad_number'] ?? 'Not Set'; 
        $logo_img = "../image/nagad.png"; 
        break;
    default:
        header("Location: index.php");
        exit();
}

$success = false;
$error_msg = "";

// পেমেন্ট সাবমিশন লজিক
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $trx_id = trim($_POST['trx_id']);
    $sender_num = trim($_POST['sender_num']);
    
    if(!empty($trx_id) && !empty($sender_num)){
        $chk = $conn->query("SELECT id FROM activation_requests WHERE trx_id='$trx_id'");
        if($chk->num_rows == 0){
            $payment_type = ($plan_id > 0) ? "Plan Purchase (ID: $plan_id)" : "Account Activation";
            $method_info = "$method_name - $payment_type";
            
            $stmt = $conn->prepare("INSERT INTO activation_requests (user_id, payment_method, sender_number, trx_id, amount, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->bind_param("isssd", $user_id, $method_info, $sender_num, $trx_id, $amount);
            
            if($stmt->execute()){
                $success = true;
            } else {
                $error_msg = "ডাটাবেজ ত্রুটি! আবার চেষ্টা করুন।";
            }
        } else {
            $error_msg = "এই TrxID টি ইতিমধ্যে ব্যবহৃত হয়েছে!";
        }
    } else {
        $error_msg = "সব তথ্য সঠিকভাবে পূরণ করুন!";
    }
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay with <?= $method_name ?> | <?= $site_name ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <!-- SweetAlert2 CSS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Hind Siliguri', sans-serif; }
        body { background-color: #f2f7fb; display: flex; justify-content: center; align-items: center; min-height: 100vh; padding: 10px; }
        .container { background: #fff; width: 100%; max-width: 400px; border-radius: 15px; box-shadow: 0 5px 25px rgba(0,0,0,0.1); overflow: hidden; }
        
        .top-bar { background: #fff; padding: 12px 15px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #eee; }
        .top-bar img { height: 30px; }
        
        .brand-header { background: <?= $color ?>; padding: 25px 20px; text-align: center; color: white; position: relative; }
        .brand-logo { width: 65px; height: 65px; background: #fff; border-radius: 50%; padding: 5px; margin: 0 auto 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .brand-logo img { width: 100%; height: 100%; object-fit: contain; border-radius: 50%; }
        .brand-title { font-size: 18px; font-weight: 600; }

        .trx-box { background: #fff; margin: -25px 20px 0; border-radius: 12px; padding: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); position: relative; z-index: 10; border: 1px solid #eee; }
        .input-field { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; margin-top: 10px; text-align: center; outline: none; font-size: 15px; transition: 0.3s; }
        .input-field:focus { border-color: <?= $color ?>; box-shadow: 0 0 5px <?= $color ?>44; }

        .instructions { padding: 15px; font-size: 13px; color: #fff; background: <?= $color ?>; margin: 15px 20px; border-radius: 10px; opacity: 0.95; line-height: 1.6; }
        
        .details-box { padding: 0 20px 20px; }
        .detail-row { background: #f8f9fa; border: 1px solid #eee; border-radius: 8px; padding: 12px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; font-size: 14px; }
        .copy-btn { background: <?= $color ?>; color: #fff; border: none; padding: 5px 12px; border-radius: 5px; cursor: pointer; font-weight: 600; font-size: 12px; transition: 0.2s; }
        .copy-btn:active { transform: scale(0.9); }

        .verify-btn { width: 100%; background: #1e293b; color: white; border: none; padding: 16px; font-size: 16px; font-weight: 700; cursor: pointer; transition: 0.3s; text-transform: uppercase; letter-spacing: 1px; }
        .verify-btn:hover { background: #000; }
    </style>
</head>
<body>

<form method="POST" id="paymentForm" class="container">
    <div class="top-bar">
        <a href="index.php?plan_id=<?= $plan_id ?>&amount=<?= $amount ?>" style="color: #666;"><i class="fas fa-arrow-left"></i></a>
        <img src="<?= $logo_img ?>" alt="<?= $method_name ?>">
        <a href="../dashboard.php" style="color: #666;"><i class="fas fa-times"></i></a>
    </div>

    <div class="brand-header">
        <div class="brand-logo">
            <img src="<?= $site_logo ?>" alt="Logo">
        </div>
        <div class="brand-title"><?= $site_name ?></div>
        <div style="height: 35px;"></div>
    </div>

    <div class="trx-box">
        <input type="number" name="sender_num" class="input-field" placeholder="আপনার <?= $method_name ?> নাম্বার" required>
        <input type="text" name="trx_id" class="input-field" placeholder="TrxID (ট্রানজেকশন আইডি)" required>
    </div>

    <div class="instructions">
        <b>কিভাবে পেমেন্ট করবেন?</b><br>
        ১. নিচের নাম্বারটি কপি করুন।<br>
        ২. আপনার অ্যাপ থেকে <b>Send Money</b> করুন।<br>
        ৩. সফলভাবে টাকা পাঠানোর পর TrxID এখানে দিন।
    </div>

    <div class="details-box">
        <div class="detail-row">
            <span>প্রাপক নাম্বার (Personal):</span>
            <div style="display:flex; align-items:center; gap:8px;">
                <span id="pNumber" style="font-weight:700; color:<?= $color ?>;"><?= $number ?></span>
                <button type="button" class="copy-btn" onclick="copyText('pNumber')"><i class="fas fa-copy"></i> Copy</button>
            </div>
        </div>
        <div class="detail-row">
            <span>টাকার পরিমাণ:</span>
            <b style="color:<?= $color ?>; font-size:16px;">৳ <?= number_format($amount, 2) ?></b>
        </div>
    </div>

    <button type="submit" class="verify-btn">Confirm Payment</button>
</form>

<script>
// নাম্বার কপি করার পপ-আপ
function copyText(id) {
    var text = document.getElementById(id).innerText;
    navigator.clipboard.writeText(text).then(function() {
        Swal.fire({
            icon: 'success',
            title: 'নাম্বার কপি হয়েছে!',
            text: text,
            timer: 1500,
            showConfirmButton: false,
            toast: true,
            position: 'top-end'
        });
    });
}

// সাবমিশন সাকসেস বা এরর পপ-আপ
<?php if($success): ?>
    Swal.fire({
        icon: 'success',
        title: 'সফলভাবে জমা হয়েছে!',
        text: 'আপনার পেমেন্ট রিকোয়েস্টটি পেন্ডিং আছে। এডমিন চেক করে এপ্রুভ করবেন।',
        confirmButtonText: 'ড্যাশবোর্ডে যান',
        confirmButtonColor: '<?= $color ?>',
        allowOutsideClick: false
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = '../dashboard.php';
        }
    });
<?php endif; ?>

<?php if($error_msg != ""): ?>
    Swal.fire({
        icon: 'error',
        title: 'দুঃখিত!',
        text: '<?= $error_msg ?>',
        confirmButtonColor: '#d33'
    });
<?php endif; ?>
</script>

</body>
</html>