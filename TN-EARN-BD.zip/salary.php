<!DOCTYPE html>
<html lang="bn">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title> আপডেট হচ্ছে</title>
<link rel="icon" href="https://cdn-icons-png.flaticon.com/512/3135/3135715.png">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
  body {
    margin: 0;
    padding: 0;
    height: 100vh;
    font-family: 'Poppins', sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #667eea, #764ba2);
    color: #fff;
  }

  .update-box {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(15px);
    border-radius: 25px;
    padding: 50px 30px;
    text-align: center;
    box-shadow: 0 0 50px rgba(0,0,0,0.3);
    max-width: 500px;
    width: 90%;
    animation: fadeIn 1s ease-in-out;
  }

  .update-box h1 {
    font-size: 32px;
    font-weight: 700;
    margin-bottom: 20px;
  }

  .update-box p {
    font-size: 18px;
    color: #e0e0e0;
    margin-bottom: 30px;
  }

  .loader {
    border: 6px solid rgba(255,255,255,0.2);
    border-top: 6px solid #fff;
    border-radius: 50%;
    width: 60px;
    height: 60px;
    margin: 0 auto 30px auto;
    animation: spin 1s linear infinite;
  }

  .update-box a {
    display: inline-block;
    padding: 12px 25px;
    background: linear-gradient(45deg, #667eea, #764ba2);
    color: #fff;
    font-weight: 600;
    border-radius: 12px;
    text-decoration: none;
    transition: 0.3s;
  }
  .update-box a:hover {
    transform: scale(1.05);
    box-shadow: 0 0 25px rgba(255,255,255,0.3);
  }

  @keyframes spin {
    0% { transform: rotate(0deg);}
    100% { transform: rotate(360deg);}
  }

  @keyframes fadeIn {
    0% {opacity: 0; transform: translateY(-20px);}
    100% {opacity: 1; transform: translateY(0);}
  }

  @media(max-width: 576px){
    .update-box h1 { font-size: 26px; }
    .update-box p { font-size: 16px; }
    .loader { width: 50px; height: 50px; border-width: 5px; }
  }
</style>
</head>
<body>

<div class="update-box">
  <div class="loader"></div>
  <h1><i class="fa-solid fa-spinner fa-spin"></i> আমাদের ওয়েবসাইট আপডেট হচ্ছে</h1>
  <p>কাজ চলছে, খুব শীঘ্রই এটি পুনরায় চালু হবে। ধন্যবাদ আপনার ধৈর্যের জন্য।</p>
  <a href="dashboard.php"><i class="fa-solid fa-arrow-left"></i> ফিরে যান হোমে</a>
</div>

</body>
</html>