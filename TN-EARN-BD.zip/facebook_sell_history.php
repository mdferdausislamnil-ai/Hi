<?php
session_start();
include "config.php";

if(!isset($_SESSION['fullname'])){
    exit;
}

$user = $_SESSION['fullname'];
$stmt = $conn->prepare("SELECT id FROM users WHERE fullname=?");
$stmt->bind_param("s",$user);
$stmt->execute();
$res = $stmt->get_result();
$userRow = $res->fetch_assoc();
$user_id = $userRow['id'];

$history = $conn->prepare("SELECT * FROM facebook_sales WHERE user_id=? ORDER BY id DESC");
$history->bind_param("i",$user_id);
$history->execute();
$res = $history->get_result();

if($res->num_rows > 0){
    while($row = $res->fetch_assoc()){
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['uid']}</td>
            <td>{$row['gmail']}</td>
            <td>{$row['rate']}</td>
            <td>{$row['status']}</td>
            <td>{$row['created_at']}</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No history found.</td></tr>";
}